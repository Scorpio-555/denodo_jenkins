/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;
import org.mvel2.MVEL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.datasource.HikariDataSourceFactory;
import com.denodo.connect.testing.engine.TestExecutor;
import com.denodo.connect.testing.engine.directive.ContextDirective;
import com.denodo.connect.testing.engine.directive.DescriptionDirective;
import com.denodo.connect.testing.engine.directive.ExecutionDirective;
import com.denodo.connect.testing.engine.directive.IDirective;
import com.denodo.connect.testing.engine.directive.NameDirective;
import com.denodo.connect.testing.engine.directive.ResultsDirective;
import com.denodo.connect.testing.engine.directive.SetUpDirective;
import com.denodo.connect.testing.engine.directive.TearDownDirective;
import com.denodo.connect.testing.engine.directive.TraceDirective;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.matching.IDataSetMatcher;
import com.denodo.connect.testing.matching.StandardDataSetMatcher;
import com.denodo.connect.testing.reporter.ITestReporter;
import com.denodo.connect.testing.reporter.MultipleTestReporter;
import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.resolver.DefaultTestResourceResolver;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.testable.ITestable;
import com.denodo.connect.testing.testable.parser.ITestParser;
import com.denodo.connect.testing.testable.parser.TestParser;
import com.denodo.connect.testing.testable.resolver.ITestableResolver;
import com.denodo.connect.testing.testable.resolver.TestableResolver;
import com.denodo.connect.testing.trace.matcher.ITraceMatcher;
import com.denodo.connect.testing.trace.matcher.TraceMatcher;
import com.denodo.connect.testing.trace.parser.ITraceParser;
import com.denodo.connect.testing.trace.parser.TraceParser;
import com.denodo.connect.testing.util.FailedTests;
import com.denodo.connect.testing.ws.rest.IRESTClient;
import com.denodo.connect.testing.ws.rest.RESTClient;
import com.denodo.connect.testing.ws.rest.RESTParsersRegister;

/**
 * The test runner will be started (using a shell script) by providing to it: 
 * - A configuration, specifying several context parameters. 
 * - A test locator pointing to the test resource by which execution should start.
 *
 */
public class TestRunner {

    private static final Logger LOG = LoggerFactory.getLogger(TestRunner.class);
    
    private static final String PROPERTIES_FORMAT_ENCODING = "ISO-8859-1";
    private static final String FAILED_TESTS = "--failed-resumable";



    public static void main(final String[] args) {

        if ((args.length != 2 && args.length != 3) || (args.length == 3 && !args[2].equals(FAILED_TESTS))) {
            System.out.println("Required parameters: [config_resource] [test_resource]");
            System.out.println("Resources must be specified like \"file:path\" or \"classpath:path\"");
            System.out.println("Optional parameters: [--failed-resumable]    Only failed tests in previous execution are launched.");
            System.exit(0);
        }
        
        LOG.debug("Denodo Testing Engine is starting.");
        
        final String configLocator = args[0];
        final String testLocator = args[1];
        boolean failedTests = false;
        if(args.length == 3){
            final String failedTestsString= args[2];
            if(failedTestsString != null && failedTestsString.equals(FAILED_TESTS)){
                failedTests = true;
            }
        }

        final boolean allOK = run(configLocator, testLocator, failedTests);

        System.exit(allOK? 0 : 1);

    }



    public static boolean run(final String configLocator, final String testLocator, final boolean requiredFailedTests) {

        Validate.notEmpty(configLocator, "Configuration file locator cannot be null or empty");
        Validate.notEmpty(testLocator, "Test locator cannot be null or empty");

        final Configuration configuration = loadConfiguration(configLocator);

        final String characterEncoding = configuration.getCharacterEncoding();
        final ITestResourceResolver testResourceResolver = new DefaultTestResourceResolver(characterEncoding);
        final ITestResource testResource = testResourceResolver.resolveResource(testLocator);
        final HikariDataSourceFactory dataSourceFactory = new HikariDataSourceFactory(configuration);
        final DataSourceLocator dataSourceLocator = new DataSourceLocator(dataSourceFactory);
        final IDataSetMatcher dataSetMatcher = new StandardDataSetMatcher(configuration);

        final ITestParser parser = new TestParser();
        final ITraceParser traceParser = new TraceParser();
        final ITraceMatcher traceMatcher = new TraceMatcher(traceParser);
        
        final RESTParsersRegister restParsersRegister = new RESTParsersRegister();
        final IRESTClient restClient = new RESTClient(restParsersRegister);
        
        final Map<String, IDirective> directives = buildDirectives(configuration, testResourceResolver, dataSourceLocator, dataSetMatcher,
                traceMatcher, restClient);
        List<String> failedTests=null;
        boolean optionFailedTests= requiredFailedTests;
        if(requiredFailedTests && testResource.isDirectory()){//if it is a file, the option failedtests does not apply
            failedTests = FailedTests.readFailedTestsLastExecution(testResource.getName());
        }else{
            optionFailedTests=false;
        }
        final ITestableResolver testableResolver = new TestableResolver(parser, directives);
        final ITestable testable = testableResolver.resolve(testResource, failedTests); 

        final ITestReporter reporter = getTestReporter(configuration);
        TestExecutor testExecutor;
        if(optionFailedTests){
            testExecutor = new TestExecutor(testable, directives, reporter, testResource.getName());
        }else{
            testExecutor = new TestExecutor(testable, directives, reporter, null);
        }
        try {

            return testExecutor.execute();

        } finally {
            dataSourceLocator.shutdown();
        }

    }


    private static Configuration loadConfiguration(final String configLocator) {
        
        Reader reader = null;
        try {
            final ITestResourceResolver configResourceResolver = new DefaultTestResourceResolver(PROPERTIES_FORMAT_ENCODING);

            // .properties files have to be encoded in ISO-8859-1
            final ITestResource configResource = configResourceResolver.resolveResource(configLocator);
            reader = configResource.readFile();
            return new Configuration(reader);

        } finally {
            IOUtils.closeQuietly(reader);
        }
        
    }

    private static Map<String, IDirective> buildDirectives(final Configuration configuration, final ITestResourceResolver testResourceResolver,
            final DataSourceLocator dataSourceLocator, final IDataSetMatcher dataSetMatcher, final ITraceMatcher traceMatcher,
            final IRESTClient restClient) {
        
        final Map<String, IDirective> directives = new LinkedHashMap<>();
        
        final NameDirective nameDirective = new NameDirective();
        directives.put(nameDirective.getName(), nameDirective);

        final DescriptionDirective descriptionDirective = new DescriptionDirective();
        directives.put(descriptionDirective.getName(), descriptionDirective);
        
        final ContextDirective contextDirective = new ContextDirective(configuration);
        directives.put(contextDirective.getName(), contextDirective);
        
        final SetUpDirective setUpDirective = new SetUpDirective(testResourceResolver, dataSourceLocator);
        directives.put(setUpDirective.getName(), setUpDirective);
        
        final ExecutionDirective executionDirective = new ExecutionDirective(testResourceResolver, dataSourceLocator, restClient);            
        directives.put(executionDirective.getName(), executionDirective);
        
        final ResultsDirective resultsDirective = new ResultsDirective(testResourceResolver, dataSourceLocator, dataSetMatcher, restClient);            
        directives.put(resultsDirective.getName(), resultsDirective);

        final TraceDirective traceDirective = new TraceDirective(traceMatcher);
        directives.put(traceDirective.getName(), traceDirective);
        
        final TearDownDirective tearDownDirective = new TearDownDirective(testResourceResolver, dataSourceLocator);
        directives.put(tearDownDirective.getName(), tearDownDirective);
        
        return directives;
    }

    private static ITestReporter getTestReporter(final Configuration configuration) {
        
        String reporterClassName = null;
        Map<String, String> reporterKeyNameMap = null;
        try {
            reporterClassName = configuration.getReporter();
        } catch (IllegalArgumentException e) {
            // It may have multiple reporters
            reporterKeyNameMap = configuration.getReporters();
        }

        try {
            if (reporterClassName != null) {
                final Class<?> implClass = Class.forName(reporterClassName);
                return (ITestReporter) implClass.getDeclaredConstructor().newInstance();
            } else if (reporterKeyNameMap != null) {
                List<ITestReporter> testReporterList = new ArrayList<>(reporterKeyNameMap.size());
                for (Entry<String, String> reporter : reporterKeyNameMap.entrySet()) {
                    reporterClassName = reporter.getValue();
                    final Class<?> implClass = Class.forName(reporterClassName);
                    Object instance = implClass.getDeclaredConstructor().newInstance();
                    
                    setReporterProperties(configuration, reporter.getKey(), instance);
                    
                    testReporterList.add((ITestReporter) instance);
                } 
                
                return new MultipleTestReporter(testReporterList);
            }
            
        } catch (final Exception e) {
            throw new TestExecutionException("Error instantiating test reporter '" +  reporterClassName + "'", e);
        }
        return null;
    }

    private static void setReporterProperties(final Configuration configuration, final String reporterKey, Object instance) {
        Map<String, String> reporterProperties = configuration.getReporterProperties(reporterKey);
        if (reporterProperties != null) {
            
            Map<String, Object> map = new HashMap<>();
            map.put("obj", instance);
            
            for (Entry<String, String> property : reporterProperties.entrySet()) {
                // Remove the opening double quote and the closing double quote
                String propertyValue = property.getValue().replaceAll("^\"|\"$", "");
                String expression = "obj." + property.getKey() + " = '" + propertyValue + "'";
                
                MVEL.eval(expression, map);
            }
        }
    }
    
}
