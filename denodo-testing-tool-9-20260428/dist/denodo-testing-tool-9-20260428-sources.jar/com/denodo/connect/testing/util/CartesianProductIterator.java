package com.denodo.connect.testing.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CartesianProductIterator <T> implements Iterator <List<T>> {
    
    private final List<List<T>> originalValues;
    private int current = 0;
    private final long last;

    public CartesianProductIterator(final List<List<T>> values) {
        this.originalValues = values;
        long product = 1;
        for (List<T> v : this.originalValues) {
            product = product * v.size();
        }
        this.last = product;
    }

    @Override
    public boolean hasNext() {
        return this.current != this.last;
    }

    @Override
    public List<T> next() {
        ++this.current;
        return get(this.current - 1, this.originalValues);
    }

    @Override
    public void remove() {
        ++this.current;
    }

    private List<T> get(final int n, final List<List<T>> values) {
        if (!values.isEmpty()) {
            List<T> inner = values.get (0);
            List<T> localList = new ArrayList<>();
            localList.add (inner.get(n % inner.size ()));
            localList.addAll(get(n / inner.size (), values.subList (1, values.size ())));
            return localList;
        } else {
            return new ArrayList<>();
        }
    }
    
}
