/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2018, Denodo Technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.util.Calendar;
import java.util.Date;

public final class DateUtils {

    
    /*
     * Convert Calendars to the local time zone to be able to compare them later
     * in their string representation. Default time zone is used for preventing
     * that dates without time and time zone information, (that will be
     * considered to be 00:00 AM) could change their day info when converting them to
     * another time zone, e.g. 2006-02-15 will be considered CET in a spanish
     * local machine and when normalized to UTC will be 2006-02-14.
     */
    public static Calendar normalizeToDefaultTimeZone(final Calendar date) {
        
        if (date == null) {
            return null;
        }
        final Calendar zCal = Calendar.getInstance();
        zCal.setTimeInMillis(date.getTimeInMillis());
        
        return zCal;
    }

    /*
     * Convert Dates to the local time zone to be able to compare them later in
     * their string representation. Default time zone is used for preventing
     * that dates without time and time zone information, (that will be
     * considered to be 00:00 AM) could change their day info when converting them to
     * another time zone, e.g. 2006-02-15 will be considered CET in a spanish
     * local machine and when normalized to UTC will be 2006-02-14.
     */
    public static Calendar normalizeToDefaultTimeZone(final Date date) {
        
        if (date == null) {
            return null;
        }
        final Calendar zCal = Calendar.getInstance();
        zCal.setTimeInMillis(date.getTime());
        
        return zCal;
    }
}
