package com.denodo.connect.testing.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.denodo.connect.testing.engine.TestExecutorResult;
import com.denodo.connect.testing.engine.TestExecutorResult.TestInformation;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.LocalFolderTestResource;

public class FailedTests {

    public static final String DENODO_FAILED_FILES_METAFILE = "#denodo-failed-tests-execution.metafile";
    public static List<String> readFailedTestsLastExecution(String path) {
        List<String> tests= new ArrayList<>();

        try{
            File file =new File(path);
           
            if(file.isDirectory()){
                file = new File(path+"/"+DENODO_FAILED_FILES_METAFILE);
                if(file.exists()){
                    FileReader fileReader = new FileReader(file);

                    try (BufferedReader br = new BufferedReader(fileReader)) {
                        String line;
                        // if no more lines the readLine() returns null
                        while ((line = br.readLine()) != null) {
                            // reading lines until the end of the file
                            tests.add(line);
                        }
                        if (tests.isEmpty()) {
                            tests = null;
                        }
                    }
                }else{
                    return null;
                }
            }else{
                return null;
            }
        }catch(IOException e){
            throw new TestExecutionException("Error read file: "+ path);
        }
        return tests;
    }

   
    
    public static Boolean isFailedTests(List<String> failedTests, String pathTest){
        if(pathTest.endsWith(LocalFolderTestResource.FIRST_TEST_FILENAME)||pathTest.endsWith(LocalFolderTestResource.LAST_TEST_FILENAME) ){
            return true;
        }
        for(String pathFailedTest: failedTests){
            if(pathFailedTest.equals(pathTest)){
                return true;
            }
        }
        return false;
    }
    
    public static void deleteMetafileFailedTests(String path){
        try{
            File file = new File(path+"/"+DENODO_FAILED_FILES_METAFILE);
            file.delete();
        }catch(Exception e){
            throw new TestExecutionException("Error deleting file:" + path+".",e);
        }

    }
    
    public static void writeFailedFiles(final TestExecutorResult result,  String path){

        try{

            File file = new File (path+"/"+DENODO_FAILED_FILES_METAFILE);
            FileWriter fw = new FileWriter(file);
            PrintWriter writer = new PrintWriter(fw);
            for(TestInformation testResult: result.getFailedTests()){
                writer.println(testResult.getResource());
            }

            writer.close();
        } catch (IOException e) {
            throw new TestExecutionException("Error writing metafile of failed tests", e);
        }

    }

    public static String getMetafileFailedTestsIfExists(String locationMetafilePath){

        File file = new File(locationMetafilePath+"/"+DENODO_FAILED_FILES_METAFILE);
        if(file.exists()){ 
            return locationMetafilePath+"/"+FailedTests.DENODO_FAILED_FILES_METAFILE;}
        else{
            return null;
        }

    }
}
