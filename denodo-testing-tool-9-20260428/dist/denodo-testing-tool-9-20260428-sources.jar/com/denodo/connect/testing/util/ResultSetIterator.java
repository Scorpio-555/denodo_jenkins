/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.exception.TestExecutionException;

public class ResultSetIterator implements Iterator<List<Object>> {
    
    private static final Logger LOG = LoggerFactory.getLogger(ResultSetIterator.class);

    private final ResultSetMetaData resultSetMetaData;
    private final int columnCount;
    private final ResultSet resultSet;
    private final Connection connection;
    private final List<Object> header;
    private String trace;
    private boolean first;
    
    /**
     * Flag indicating whether the ResultSet is currently positioned at a row for which we have not yet returned an element in the iteration.
     */
    private boolean currentRow;
    
    /**
     * Flag indicating whether the ResultSet has indicated there are no further rows.
     */
    private boolean eof;
    
    private boolean closed;

    /**
     * @param connection receives the Connection because ResultSetIterator is in charge of releasing the Connection after iterating over the results.
     *                   We could get the Connection invoking {@link ResultSet#getStatement()} and {@link Statement#getConnection()}
     *                   but this Connection is the original obtained from the driver and not the wrapped one by the connection pool. 
     *                   We need the wrapped Connection from the connection pool that is in charge, when {@link Connection#close()} is invoked,
     *                   of returning the Connection to the pool.
     */
    public ResultSetIterator(final ResultSet resultSet, final Connection connection, final boolean traceEnabled) {
        
        try {

            Validate.notNull(resultSet, "Result set cannot be null.");
            Validate.notNull(connection, "Connection cannot be null.");
            
            this.resultSet = resultSet;
            this.connection = connection;
            this.first = true;
            this.currentRow = false;
            this.eof = false;
            this.closed = false;
        
            this.resultSetMetaData = resultSet.getMetaData();
            this.columnCount = this.resultSetMetaData.getColumnCount();

            this.header = new ArrayList<>();
            for (int i = 1; i <= this.columnCount; i++) {
                this.header.add(this.resultSetMetaData.getColumnLabel(i).toLowerCase());
            }

            if (traceEnabled) {
                this.trace = getTrace(resultSet);
            }
            
            releaseResourcesIfNoResults();  
            
        } catch (final Exception e) {
            close();
            throw new TestExecutionException("Error accessing ResultSet", e); 
        }
    }

    private void releaseResourcesIfNoResults() {
        
        if (!hasNext()) {
            close();
        }
    }
    
    private static String getTrace(final ResultSet resultSet)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, SQLException {
        
        String vdpTrace = null;
        ResultSet rs = resultSet;
      //  if (rs instanceof HikariResultSetProxy) {
            rs = rs.unwrap(ResultSet.class);
        //}
        //  Obtains the VDP implementation of ResultSet to access the non-standard method getExecutionPlan
        if ("VDBJDBCAsyncResultSet".equals(rs.getClass().getSimpleName())) {
            final Object executionPlan = MethodUtils.invokeExactMethod(rs, "getExecutionPlan", null);
        
            if (executionPlan != null) {
                vdpTrace = executionPlan.toString();
            }
        }
        
        return vdpTrace;
    }
    
    @Override
    public boolean hasNext() {
        
            if (this.closed) {
                return false;
            }
            if (first && header != null && !header.isEmpty()){
                return true;
            }
            try {
                advance();
                return !this.eof;
            } catch (final SQLException e) {
                close();
                throw new TestExecutionException("Error accessing ResultSet", e); 
            }
    }

    /**
     * Each element of the iterator is a List of Objects containing the values from the next row of the database table. When the
     * returned result is the last element, the iterator closes the resultSet and the preparedStatement.
     * 
     * @return a List of Objects. The First result returned contains the column names.
     */
    @Override
    public List<Object> next() {
        
            if (this.closed) {
                return null;
            }

            try {
                if (this.first && hasNext()) {
                    this.first = false; // the first row is always the header
                    return this.header;
                }

                advance();
                if (this.eof) {
                    throw new NoSuchElementException();
                }
                this.currentRow = false;

                final List<Object> row = new ArrayList<>();
                for (int i = 1; i <= this.columnCount; i++) {
                    final Object value = getObject(i);
                    row.add(value);
                }

                return row;

            } catch (final SQLException e) {
                close();
                throw new TestExecutionException("Error accessing ResultSet", e); 

            } finally {
                releaseResourcesIfNoResults();
            }
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
        
    }
    
    /**
     * Advance the result set to the next row, if there is not a current row (and if we are not already at eof).
     * 
     */
    private void advance() throws SQLException {

        if (!this.currentRow && !this.eof) {
            if (this.resultSet.next()) {
                this.currentRow = true;
                this.eof = false;
            } else {
                this.currentRow = false;
                this.eof = true;
            }
        }
    }
    
    /*
     * To avoid retrieving specific database objects, as oracle.sql.Timestamp, using resultSet.getObject()
     */
    private Object getObject(final int index) throws SQLException {

        return switch (this.resultSetMetaData.getColumnType(index)) {
            case Types.BLOB -> this.resultSet.getBytes(index);
            case Types.CLOB,
                // As getObject for VDP intervals return longs, we retrieve the string format to easily compare
                // VDP intervals with other db intervals that have a string representation for
                // their custom objects, e.g. oracle.sql.INTERVALYM
                VDPJDBCTypes.INTERVAL_YEAR_MONTH, VDPJDBCTypes.INTERVAL_DAY_SECOND -> this.resultSet.getString(index);
            case Types.DATE -> this.resultSet.getDate(index);
            case Types.TIMESTAMP -> this.resultSet.getTimestamp(index);
            default -> this.resultSet.getObject(index);
        };
    }
    

    private void close() {

        /*
         * Note that, when profiled with YourKit, it looks as is Hikari is not correctly closing Statements
         * (even if connections ARE being correctly closed). This is most likely an issue in how YourKit inspects
         * these statements, as it has been checked via debugging that the current code ends up calling .close()
         * on every Statement created for these ResultSetIterator objects, both with VDP and MySQL (the fact that
         * MySQL was also tested is important so that we make sure it is not a VDP statement issue).
         */

        if (!this.closed && this.resultSet != null) {
            try {
                final Statement statement = this.resultSet.getStatement();
                
                this.resultSet.close();
                
                if (statement != null) {
                    statement.close();
                }
                
            } catch (final SQLException e) {
                LOG.debug("Could not close JDBC resources", e);
            }
            
            try {
                
                if (this.connection != null) {
                    this.connection.close();
                }

            } catch (final SQLException e) {
                LOG.debug("Could not close connection", e);
            }

            this.closed = true;
        }
    }


    public ResultSetMetaData getResultSetMetadata(){

        return this.resultSetMetaData;
    }

    public String getTrace() {
        return this.trace;
    }
    
}
