/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

public final class ClassLoaderUtils {

    
    public static ClassLoader getClassLoader(final Class<?> clazz) {
        // Context class loader can be null
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        if (contextClassLoader != null) {
            return contextClassLoader;
        }
        if (clazz != null) {
            // The class loader for a specific class can also be null
            final ClassLoader clazzClassLoader = clazz.getClassLoader();
            if (clazzClassLoader != null) {
                return clazzClassLoader;
            }
        }
        // The only class loader we can rely on for not being null is the system one
        return ClassLoader.getSystemClassLoader();
    }

    private ClassLoaderUtils() {
        super();
    }
}
