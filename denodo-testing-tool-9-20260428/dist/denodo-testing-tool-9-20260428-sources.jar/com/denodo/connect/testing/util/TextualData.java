/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;


import java.io.Serial;
import java.io.Serializable;

/**
 * 
 * Convenience class for data represented as text which type is not known and might need to be parsed as number/boolean.
 * <p>
 * CSVIterator returns TextualData instead of String for convenience when matching test results. 
 * For instance, is 23 equals to "23"?
 * It depends on the data source, if "23" comes from CSV (TextualData) objects are equals,
 * otherwise if "23" comes from DB objects are not the same.
 * 
 */
public final class TextualData implements Serializable {

    @Serial
    private static final long serialVersionUID = 4446456002487123008L;
    
    /**
     * Value used by VDP, when exports its results to a CSV file, to indicate a null value.
     */
    private static final String VDP_NULL = "NULL";

    private final String value;
    private final Class<?> knownType;


    public TextualData(final String value) {
        this(value, null);
    }

    public TextualData(final String value, final Class<?> knownType) {
        super();
        this.value = value;
        this.knownType = knownType;
    }


    public String getValue() {
        return this.value;
    }
    
    public boolean isEmpty() {
        return this.value.isEmpty();
    }
    
    /* There is no difference between empty string and null in CSV format. */
    public boolean isNull() {
        return VDP_NULL.equalsIgnoreCase(this.value) || this.value == null || isEmpty();
    }

    public boolean hasKnownType() {
        return this.knownType != null;
    }

    public Class<?> getKnownType() {
        return this.knownType;
    }
    
    @Override
    public int hashCode() {
        
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.knownType == null) ? 0 : this.knownType.getName().hashCode());
        result = prime * result + ((this.value == null) ? 0 : this.value.hashCode());
        
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        TextualData other = (TextualData) obj;
        if (this.knownType == null) {
            if (other.knownType != null) {
                return false;
            }
        } else if (!this.knownType.getName().equals(other.knownType.getName())) {
            return false;
        }
        if (this.value == null) {
            return other.value == null;
        } else {
            return this.value.equals(other.value);
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

}
