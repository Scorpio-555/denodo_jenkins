/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.Validate;

/**
 * 
 * This code is originally based on the algorithm found at
 * org.springframework.jdbc.datasource.init.ScriptUtils#splitSqlScript(...),
 * part of the Spring Framework.
 *
 */
public final class ScriptUtils {
    
    private static final char LITERAL_CHAR = '\'';

    private static final char MYSQL_ESCAPE_CHAR = '\\';

    /**
     * Default statement separator within SQL scripts: {@code ";"}.
     */
    private static final String DEFAULT_STATEMENT_SEPARATOR = ";";

    /**
     * Default prefix for single-line comments within SQL scripts: {@code "--"}.
     */
    private static final String DEFAULT_COMMENT_PREFIX = "--";
    
    /**
     * Default prefix for single-line comments within VDP scripts: {@code "#"}.
     */
    private static final String DEFAULT_VDP_COMMENT_PREFIX = "#";

    /**
     * Default start delimiter for block comments within SQL scripts: {@code "/*"}.
     */
    private static final String DEFAULT_BLOCK_COMMENT_START_DELIMITER = "/*";

    /**
     * Default end delimiter for block comments within SQL scripts: <code>"*&#47;"</code>.
     */
    private static final String DEFAULT_BLOCK_COMMENT_END_DELIMITER = "*/";

    private static final String[] CREATE_VQL_PROCEDURE = {"CREATE VQL PROCEDURE", "CREATE OR REPLACE VQL PROCEDURE"};
    private static final String CREATE_VQL_PROCEDURE_END_STATEMENT = "END;";


    public static List<String> splitSqlScript(final String script) throws ParseException {
        return splitSqlScript(script, DEFAULT_STATEMENT_SEPARATOR, DEFAULT_COMMENT_PREFIX, DEFAULT_VDP_COMMENT_PREFIX,
                DEFAULT_BLOCK_COMMENT_START_DELIMITER, DEFAULT_BLOCK_COMMENT_END_DELIMITER);
    }

    public static List<String> splitSqlScript(final String script, final String separator) throws ParseException {
        return splitSqlScript(script, separator, DEFAULT_COMMENT_PREFIX, DEFAULT_VDP_COMMENT_PREFIX, DEFAULT_BLOCK_COMMENT_START_DELIMITER,
            DEFAULT_BLOCK_COMMENT_END_DELIMITER);
    }
    
    /**
     * Split an SQL script into separate statements delimited by the provided
     * separator string.
     * Each statement will be added to the provided
     * {@code List}.
     * <p>Within the script, the provided {@code commentPrefix} will be honored:
     * any text beginning with the comment prefix and extending to the end of the
     * line will be omitted from the output.
     * Similarly, the provided
     * {@code blockCommentStartDelimiter} and {@code blockCommentEndDelimiter}
     * delimiters will be honored: any text enclosed in a block comment will be
     * omitted from the output.
     * In addition, multiple adjacent whitespace characters
     * will be collapsed into a single space.
     * @param script the SQL script; never {@code null} or empty
     * @param separator text separating each statement &mdash; typically an ';' or
     * newline character; never {@code null}
     * @param commentPrefix the prefix that identifies SQL line comments &mdash;
     * typically "--"; never {@code null} or empty
     * @param blockCommentStartDelimiter the <em>start</em> block comment delimiter;
     * never {@code null} or empty
     * @param blockCommentEndDelimiter the <em>end</em> block comment delimiter;
     * never {@code null} or empty
     * @return statements the list that will contain the individual statements
     * @throws ParseException if an error occurred while splitting the SQL script
     */
    public static List<String> splitSqlScript(final String script, final String separator, final String commentPrefix,
            final String vdpCommentPrefix, final String blockCommentStartDelimiter, final String blockCommentEndDelimiter) throws ParseException {

        Validate.notNull(script, "Script cannot be null.");
        Validate.notNull(separator, "Separator cannot be null.");
        Validate.notNull(commentPrefix, "Comment prefix cannot be null.");
        Validate.notNull(vdpCommentPrefix, "Comment prefix for VDP cannot be null.");
        Validate.notNull(blockCommentStartDelimiter, "Block comment start delimiter cannot be null.");
        Validate.notNull(blockCommentEndDelimiter, "Block comment end delimiter cannot be null.");

        final List<String> statements = new ArrayList<>();
        
        StringBuilder sb = new StringBuilder();
        boolean inLiteral = false;
        boolean inEscape = false;
        final char[] content = script.toCharArray();
        for (int i = 0; i < script.length(); i++) {
            char c = content[i];
            if (inEscape) {
                inEscape = false;
                sb.append(c);
                continue;
            }

            if (c == MYSQL_ESCAPE_CHAR) {
                inEscape = true;
                sb.append(c);
                continue;
            }
            if (c == LITERAL_CHAR) {
                inLiteral = !inLiteral;
            }
            if (!inLiteral) {
                if (script.startsWith(separator, i)) {
                    // we've reached the end of the current statement
                    if (!sb.isEmpty()) {
                        if (!isVqlProcedureBlockEnded(sb)) {
                            // See com.denodo.connect.testing.util.ScriptUtils.isVqlProcedureBlockEnded
                            continue;
                        } else {
                            final String statement = sb.toString();
                            if (!statement.trim().isEmpty()) {
                                statements.add(statement);
                            }
                            sb = new StringBuilder();
                        }
                    }
                    i += separator.length() - 1;
                    continue;
                }
                else if (script.startsWith(commentPrefix, i) || script.startsWith(vdpCommentPrefix, i)) {
                    // skip over any content from the start of the comment to the EOL
                    final int indexOfNextNewline = script.indexOf('\n', i);
                    if (indexOfNextNewline > i) {
                        i = indexOfNextNewline;
                        continue;
                    }
                    // if there's no EOL, we must be at the end
                    // of the script, so stop here.
                    break;
                }
                else if (script.startsWith(blockCommentStartDelimiter, i)) {
                    // skip over any block comments
                    int indexOfCommentEnd = script.indexOf(blockCommentEndDelimiter, i);
                    if (indexOfCommentEnd > i) {
                        i = indexOfCommentEnd + blockCommentEndDelimiter.length() - 1;
                        continue;
                    }
                    throw new ParseException("Missing block comment end delimiter " + blockCommentEndDelimiter, i);
                }
                else if (c == ' ' || c == '\t') {
                    // avoid multiple adjacent whitespace characters
                    if (!sb.isEmpty() && sb.charAt(sb.length() - 1) != ' ') {
                        c = ' ';
                    }
                    else {
                        continue;
                    }
                }
            }
            sb.append(c);
        }
        
        final String statement = sb.toString();
        if (!statement.trim().isEmpty()) {
            statements.add(statement);
        }
        
        return statements;
    }

    /***
     * VQL Procedures are a special case of VQL statements because they might have several places with ";", which
     * could be the separator used to split the statements.
     * This method avoids splitting the CREATE VQL PROCEDURE block, so it can be executed as a whole.
     *
     * @param sb the fragment of VQL statement
     * @return true if the sb does not contain a VQL PROCEDURE statement or if it does contain a
     * VQL PROCEDURE, and it has reached the end of the CREATE VQL PROCEDURE structure.
     * Returns false otherwise
     */
    private static boolean isVqlProcedureBlockEnded(StringBuilder sb) {

        if (Arrays.stream(CREATE_VQL_PROCEDURE).noneMatch(sb.toString().toUpperCase()::contains)
            || Arrays.stream(CREATE_VQL_PROCEDURE).anyMatch(sb.toString().toUpperCase()::contains)
                && sb.toString().contains(CREATE_VQL_PROCEDURE_END_STATEMENT)) {
            return true;
        }

        // At this point we have an unfinished CREATE VQL PROCEDURE, so we need to append a semicolon
        // to continue with the rest of the statements until "END" is reached
        sb.append(DEFAULT_STATEMENT_SEPARATOR);
        return false;
    }

    private ScriptUtils() {
        super();
    }
}
