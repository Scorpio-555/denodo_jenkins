/*
 *
 * Copyright (c) 2022. DENODO Technologies.
 * http://www.denodo.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of DENODO
 * Technologies ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with DENODO.
 *
 */
package com.denodo.connect.testing.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.denodo.connect.testing.exception.TestExecutionException;

public class MetadataDataSetUtils {


    public static Map<String,Class<?>> getClassObjectFromMetadata(ResultSetMetaData resultSetMetadata) {
        Map<String,Class<?>> metadataTypes = new HashMap<>();
        int type;
        try {
            for (int i = 0; i < resultSetMetadata.getColumnCount(); i++) {

                type = resultSetMetadata.getColumnType(i+1);

                Class<?> classObject = switch (type) {
                    case Types.BOOLEAN, Types.BIT -> Boolean.class;
                    case Types.TINYINT, Types.INTEGER, Types.SMALLINT -> Integer.class;
                    case Types.DECIMAL -> BigDecimal.class;
                    case Types.NUMERIC, Types.DOUBLE, Types.REAL -> Double.class;
                    case Types.BIGINT -> BigInteger.class;
                    case Types.FLOAT -> Float.class;
                    case Types.TIME, Types.TIMESTAMP -> Timestamp.class;
                    case Types.DATE -> Date.class;
                    default -> String.class;
                };

                metadataTypes.put(resultSetMetadata.getColumnName(i+1),classObject);
            }
        } catch (SQLException e) {
            throw new TestExecutionException("Error accessing type of CSV data", e);
        }
        return metadataTypes;
    }
}
