/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.io.Serial;
import java.sql.Array;
import java.sql.SQLException;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.matching.ComplexTree;
import com.denodo.connect.testing.matching.ComplexTree.ComplexTreeNode;
import com.denodo.connect.testing.matching.DatePatterns;

public final class ComplexTypeUtils {
    
    private static final char ARRAY_START_DELIMITER = '[';
    private static final char ARRAY_END_DELIMITER = ']';
    private static final char STRUCT_START_DELIMITER = '{';
    private static final char STRUCT_END_DELIMITER = '}';
    private static final char SIMPLE_START_DELIMITER = '\'';
    private static final char SIMPLE_END_DELIMITER = '\'';
    private static final char ESCAPE_CHARACTER = '\'';

    /**
     * Gets the string which represents the array in VDP format.
     * 
     * @param sqlArray array
     * @return a string representing the array in VDP format.
     */
    public static String sqlArrayToString(final Array sqlArray) { 
        List<String> arrayList;
        
        try {
            final Object[] values = (Object[])sqlArray.getArray();
            
            arrayList = new ArrayList<>(values.length);

            for (final Object value : values) {
                arrayList.add(getStringValue(value, true));
            }
        } catch (final SQLException e) {
            throw new TestExecutionException("Error getting array values. ", e);
        }
        
        return arrayList.toString();
    }
    
    /**
     * Gets the string which represents the struct in VDP format.
     * 
     * @param sqlStruct struct
     * @return a string representing the struct in VDP format.
     */
    public static String sqlStructToString(final Struct sqlStruct) {
        List<String> list;
        
        try {
            final Object[] attributes = sqlStruct.getAttributes();
            list = new ArrayList<>(attributes.length);
            
            for (final Object attribute : attributes) {
                final String stringAttribute = getStringValue(attribute, false);
                list.add(stringAttribute);
            }

        } catch (final SQLException e) {
            throw new TestExecutionException("Error getting struct values. ", e);
        }
        final StringBuilder values = new StringBuilder(list.toString());
        values.setCharAt(0, '{');
        values.setCharAt(values.length()-1, '}');
        return values.toString();
    }
    
    /**
     * Gets the string which represents the List (obtained from a REST array) in VDP format.
     */
    public static String arrayToString(final List<Object> values) {
                
        final List<String> arrayList = new ArrayList<>(values.size());
        for (final Object value : values) {
            arrayList.add(getStringValue(value, true));
        }
        
        return arrayList.toString();
    }

    /**
     * Gets the string which represents the Object[] (obtained from a REST record) in VDP format.
     */
    public static String recordToString(final Object[] values) {
                
        List<String> list;
        
        list = new ArrayList<>(values.length);
            
        for (final Object attribute : values) {
            final String stringAttribute = getStringValue(attribute, false);
            list.add(stringAttribute);
        }

        final StringBuilder recordValues = new StringBuilder(list.toString());
        recordValues.setCharAt(0, '{');
        recordValues.setCharAt(recordValues.length()-1, '}');
        return recordValues.toString();
    }
    
    @SuppressWarnings("unchecked")
    private static String getStringValue(final Object value, final boolean isArrayValue) {
        
        final StringBuilder sb = new StringBuilder();

        final String simpleValueMark = "'";
        if (value instanceof Struct) {
            sb.append(sqlStructToString((Struct) value));
        } else if (value instanceof Array) {
            sb.append(sqlArrayToString((Array) value));
        } else if (value instanceof List) {
            sb.append(arrayToString((List<Object>) value));
        } else if (value instanceof Object[]) {
            sb.append(recordToString((Object[]) value));
        } else if (value == null) {
            sb.append("null");
        } else {
            // In VDP every element of an array is a struct
            if (isArrayValue) {
                sb.append("{");
            }
            sb.append(simpleValueMark);
            sb.append(value);
            sb.append(simpleValueMark);
            if (isArrayValue) {
                sb.append("}");
            }
        }
        return sb.toString();
    }


    /*
     * Gets the complex tree which has all simple elements as leaves
     */
    public static ComplexTree convertComplexStringToComplexTree(final String str, final boolean complexOrdered, final DatePatterns datePatterns) {

        final ComplexTree complexTree = new ComplexTree(str, datePatterns, complexOrdered);
        addStringElementsToComplexTree(complexTree.getRoot());
        
        return complexTree;
    }
    
    private static void addStringElementsToComplexTree(final ComplexTreeNode parent) {
        
        final List<String> elements = getElementsOfComplexNode(parent);
        for (final String element : elements) {
            if (isComplexRepresentation(element)) {
                final ComplexTreeNode complexTreeNode = parent.addChild(element);
                addStringElementsToComplexTree(complexTreeNode);
            } else if (isSimpleRepresentation(element)) {
                final TextualData newElementAsTextualData = new TextualData(getSimpleElement(element));
                parent.addChild(newElementAsTextualData);
            } else {
                throw new BadComplexFormatException(element);
            }
        }
    }
    
    private static List<String> getElementsOfComplexNode(final ComplexTreeNode node) {
        final List<String> elements = new ArrayList<>();
        final String nodeValue = (String) node.getValue();
        
        if (!isComplexRepresentation(nodeValue)) {
            throw new BadComplexFormatException(nodeValue);
        }
        
        StringBuilder element = new StringBuilder();
        
        char c;
        int n = nodeValue.length() - 1;
        int i = 1;
        int simpleQuotationCounter = 0;
        final char startMark = nodeValue.charAt(0);
        boolean startedSimple = false;
        boolean startedArray = false;
        boolean startedStruct = false;
        
        while (n-- != 0) {
            c = nodeValue.charAt(i++);
            
            // Skip whitespaces between elements
            if (c == ' ' && !startedSimple && !startedArray && !startedStruct) {
                continue;
            }
            
            if (isDelim(c, startedSimple, startedArray, startedStruct)) {
                elements.add(element.toString());
                element = new StringBuilder();
                startedSimple = false;
                startedArray = false;
                startedStruct = false;
                continue;
            }
            
            if (n == 0) {
                if (isEndMark(c, startMark, startedSimple, startedArray, startedStruct)) {
                    if (!element.toString().isEmpty()) {
                        elements.add(element.toString());
                    }
                    continue;
                }
                throw new BadComplexFormatException(nodeValue);
            }
            
            if (isEscapedSimpleDelimiter(c, simpleQuotationCounter)) {
                simpleQuotationCounter = 0;
                //leave only one
                continue;
            } 
            
            if (c == ESCAPE_CHARACTER && startedSimple) {
                simpleQuotationCounter++;
            }

            element.append(c);
            
            if (isNullElement(element.toString(), startedSimple, startedArray, startedStruct)) {
                elements.add(element.toString());
                element = new StringBuilder();
                startedSimple = false;
                startedArray = false;
                startedStruct = false;
                continue;
            }
            
            if (isSimpleEnd(c, nodeValue.charAt(i), startedSimple, startedArray, startedStruct, simpleQuotationCounter)) {
                startedSimple = false;
                simpleQuotationCounter = 0;
                continue;
            }
            if (isArrayEnd(c, startedSimple, startedArray, startedStruct)) {
                startedArray = false;
                continue;
            }
            if(isStructEnd(c, startedSimple, startedArray, startedStruct)) {
                startedStruct = false;
                continue;
            }
            
            if(!startedSimple && !startedArray && !startedStruct) {
                startedSimple = isSimpleStart(c, startedSimple);
                startedArray = isArrayStart(c, startedArray);
                startedStruct = isStructStart(c, startedStruct);
            }
            
        }
        
        return elements;
    }
    
    private static boolean isComplexRepresentation(final String str) {
        return ((str.startsWith(String.valueOf(ARRAY_START_DELIMITER)) && str.endsWith(String.valueOf(ARRAY_END_DELIMITER))) ||
                str.startsWith(String.valueOf(STRUCT_START_DELIMITER)) && str.endsWith(String.valueOf(STRUCT_END_DELIMITER)));
    }
    
    private static boolean isSimpleRepresentation(final String str) {
        return (str.startsWith(String.valueOf(SIMPLE_START_DELIMITER)) && str.endsWith(String.valueOf(SIMPLE_END_DELIMITER))) 
                || str.equals("null");
    }
    
    
    private static boolean isSimpleStart(final char c, final boolean startedSimple) {
        return !startedSimple && c == SIMPLE_START_DELIMITER;
    }
    
    private static boolean isArrayStart(final char c, final boolean startedArray) {
        return !startedArray && c == ARRAY_START_DELIMITER;
    }
    
    private static boolean isStructStart(final char c, final boolean startedStruct) {
        return !startedStruct && c == STRUCT_START_DELIMITER;
    }
    
    private static boolean isSimpleEnd(final char c, final char nextCharacter, final boolean startedSimple, 
            final boolean startedArray, final boolean startedStruct, final int simpleQuotationCounter) {
        return c == SIMPLE_END_DELIMITER && nextCharacter != SIMPLE_END_DELIMITER 
                && simpleQuotationCounter == 1 && startedSimple && !startedArray && !startedStruct;
    }
    
    private static boolean isArrayEnd(final char c, final boolean startedSimple, 
            final boolean startedArray, final boolean startedStruct) {
        return c == ARRAY_END_DELIMITER && startedArray && !startedSimple && !startedStruct;
    }
    
    private static boolean isStructEnd(final char c, final boolean startedSimple, 
            final boolean startedArray, final boolean startedStruct) {
        return c == STRUCT_END_DELIMITER && startedStruct && !startedSimple && !startedArray;
    }
    
    private static boolean isDelim(final char c, final boolean startedSimple, final boolean startedArray, final boolean startedStruct) {
        final char delim = ',';
        return c == delim && !startedSimple && !startedArray && !startedStruct;
    }
    
    private static boolean isEscapedSimpleDelimiter(final char c, final int simpleQuotationCounter) {
        return c == SIMPLE_END_DELIMITER && simpleQuotationCounter == 1;
    }
    
    private static boolean isEndMark(final char c, final char startMark, final boolean startedSimple, 
            final boolean startedArray, final boolean startedStruct) {
        return !startedSimple && !startedArray && !startedStruct && 
                ((startMark == ARRAY_START_DELIMITER && c == ARRAY_END_DELIMITER) 
                        || (startMark == STRUCT_START_DELIMITER && c == STRUCT_END_DELIMITER)); 
    }
    
    private static boolean isNullElement(final String element, final boolean startedSimple, 
            final boolean startedArray, final boolean startedStruct) {
        return element.equals("null") && !startedSimple && !startedArray && !startedStruct;
    }

    public static ComplexTree convertComplexToComplexTree(final Object obj, final boolean complexOrdered, final DatePatterns datePatterns) {

        if (obj instanceof ComplexTree) {
            final ComplexTree complexTree = (ComplexTree) obj;
            
            complexTree.updateDatePatterns(datePatterns); // as datepattern is different for sorting and comparing operations
            return complexTree;
            
        }
        
        final ComplexTree complexTree = new ComplexTree(convertComplexToString(obj), datePatterns, complexOrdered);
        addElementsToComplexTree(complexTree.getRoot(), obj);
        
        return complexTree;
    }
    
    @SuppressWarnings("unchecked")
    public static String convertComplexToString(final Object obj) {
      
        if (obj instanceof Array) {
            return ComplexTypeUtils.sqlArrayToString((Array) obj);
        }
    
        if (obj instanceof Struct) {
            return ComplexTypeUtils.sqlStructToString((Struct) obj);
        }
          
        // REST arrays are transformed into List
        if (obj instanceof List) {
            return ComplexTypeUtils.arrayToString((List<Object>) obj);
        }
          
        // REST records are transformed into Object[]
        if (obj instanceof Object[]) {
            return ComplexTypeUtils.recordToString((Object[]) obj);
        }

        // This should never happen anyway, unless we consider a new class as "complex" and don't update this part
        // of the code properly.
        return obj.toString();
    }
    
    @SuppressWarnings("unchecked")
    private static void addElementsToComplexTree(final ComplexTreeNode parent, final Object obj) {
            
        boolean areArrayValues = false;

        List<Object> objList = new ArrayList<>();
        if (obj instanceof Array) {
            // All elements of an array are structs in VDP, so we represent them
            // as complex
            try {
                objList = new ArrayList<>(Arrays.asList((Object[]) ((Array) obj).getArray()));
                areArrayValues = true;
            } catch (final SQLException e) {
                throw new TestExecutionException("Error getting Array values. ", e);
            }
        } else if (obj instanceof Struct) {
            try {
                objList = new ArrayList<>(Arrays.asList(((Struct) obj).getAttributes()));
            } catch (final SQLException e) {
                throw new TestExecutionException("Error getting Struct values. ", e);
            }
        } else if (obj instanceof List) {
            objList = (List<Object>) obj;
        } else if (obj instanceof Object[]) {
            objList = new ArrayList<>(Arrays.asList((Object[]) obj));
        }

        buildComplexTree(parent, objList, areArrayValues);

    }
    
    private static boolean isComplexObject(final Object obj) {
        return obj instanceof Array || obj instanceof Struct || obj instanceof List
                || obj instanceof Object[];
    }
    
    
    
    private static void buildComplexTree(final ComplexTreeNode parent, final List<Object> elements, final boolean areArrayValues) {
        
        for (final Object obj : elements) {
            if (isComplexObject(obj)) {
                final String value = getStringValue(obj, false);
                final ComplexTreeNode complexTreeNode = parent.addChild(value);
                addElementsToComplexTree(complexTreeNode, obj);            
            } else if (areArrayValues) {
                // All elements of an array are structs in VDP, so we represent them as complex
                // Add the object as a complex and as a simple value
                final String value = getStringValue(obj, true);
                final ComplexTreeNode complexTreeNode = parent.addChild(value);
                complexTreeNode.addChild(obj);
            } else {
                parent.addChild(obj);
            }
        }
    }
    
    private static String removeFirstAndLastCharacter(final String str) {
        return str.substring(1, str.length()-1);
    }
    
    private static String getSimpleElement(final String str) {
        if (str.equals("null")) {
            return str;
        }
        return removeFirstAndLastCharacter(str);
    }
    
    
    public static class BadComplexFormatException extends TestExecutionException {

        @Serial
        private static final long serialVersionUID = 3452776321222200242L;

        public BadComplexFormatException(final String complexString) {
            super("Error getting elements in a complex type: " + complexString);
        }

    }
}
