/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

public final class VariableUtils {
    
    /*
     * Uses negative lookbehind: (?<!\)$ matches a "$" that is not preceded by an "\". Values like ${value} that
     * are not context variables should be written \${value} in the test file.
     */
    private static final Pattern CONTEXT_VARIABLE_PATTERN = Pattern.compile(".*?(?<!\\\\)(\\$\\{\\s*)(.*?)(\\s*\\})");
    private static final int CONTEXT_PREFIX_GROUP = 1;
    private static final int CONTEXT_VARIABLE_GROUP = 2;
    private static final int CONTEXT_SUFFIX_GROUP = 3;

    public static String extractValue(final Pattern pattern, final int group, final String input) {

        if (input == null) {
            return null;
        }

        final Matcher matcher = pattern.matcher(input);
        if (!matcher.matches()) {
            return null;
        }

        final String property = matcher.group(group);
        if (StringUtils.isBlank(property)) {
            return null;
        }

        // Replace multiple spaces by one.
        return property.replaceAll("( )+", " ").trim();
    }
   
    public static String replaceVariables(final String value, final Map<String, Object> contextVariables) {
        return replaceVariables(CONTEXT_VARIABLE_PATTERN, CONTEXT_VARIABLE_GROUP,
                CONTEXT_PREFIX_GROUP, CONTEXT_SUFFIX_GROUP, value, contextVariables);
    }
    
    public static String replaceVariables(final Pattern pattern, final int variableGroup, final int prefixGroup, final int suffixGroup,
            final String value, final Map<String, Object> contextVariables) {

        if (value == null) {
            return null;
        }

        final Matcher matcher = pattern.matcher(value);
        if (!matcher.find()) {
            return unescapeNonVariables(value);
        }

        Validate.notNull(contextVariables, "'" + value + "' contains variables so context variables cannot be null.");
        matcher.reset();
        final StringBuilder sb = new StringBuilder();
        int index = 0;
        while (matcher.find()) {

            final int start = matcher.start(prefixGroup);  
            final int end = matcher.end(suffixGroup);  
            final String contextVariable = matcher.group(variableGroup);
            final Object valueToReplace = contextVariables.get(contextVariable);
            Validate.notNull(valueToReplace, "Missing context variable '" + contextVariable + "'");
            sb.append(value, index, start);
            sb.append(valueToReplace);

            index = end;
        }
        sb.append(value.substring(index));

        return unescapeNonVariables(sb.toString());
    }
    
    public static List<String> findVariables(final String value) {
        return findVariables(CONTEXT_VARIABLE_PATTERN, CONTEXT_VARIABLE_GROUP, value);
    }
    
    public static List<String> findVariables(final Pattern pattern, final int variableGroup, final String value) {
        
        List<String> variables = new ArrayList<>();
        
        if (value == null) {
            return variables;
        }
        
        final Matcher matcher = pattern.matcher(value);
        if (!matcher.find()) {
            return variables;
        }
        matcher.reset();
        while (matcher.find()) {
            final String contextVariable = matcher.group(variableGroup);
            variables.add(contextVariable);
        }
        
        return variables;
    }

    /*
     * Unescape strings of the form \${value} to ${value} when the variables replacing have finished.
     */
    public static String unescapeNonVariables(final String value) {
        return value.replaceAll("\\\\\\$", "\\$");
    }
    
    public static List<String> extractContextVariables(final String contextVariable, final String input) {
        
        List<String> values = new ArrayList<>();
        if (input == null) {
            return values;
        }
        
        // negative lookbehind: split on each "," that is not escaped, that is, preceded by a "\".
        final String[] vars = input.split("\\s*(?<!\\\\),\\s*");
        String contextValue;
        for (final String var : vars) {
            final String[] pair = var.split("\\s*" + contextVariable + "\\s*:");
            if (pair.length == 2) {
                contextValue = pair[1];
                contextValue = contextValue.replaceAll("( )+", " ").trim();  // Replace multiple spaces by one.
                contextValue = unescapeSeparatorVariables(contextValue);
                values.add(contextValue);
            }
        }

        return values;
    }
    
    public static String extractContextVariable(final String contextVariable, final String input) {
        
        List<String> values = extractContextVariables(contextVariable, input);
        return values.isEmpty() ? null : values.get(0);
    }
    
    /*
     * Unescape strings of the form "datepattern:MMM d\\, yyyy h:mm:ss" to "datepattern:MMM d, yyyy h:mm:ss" when the context variables have been extracted
     */
    private static String unescapeSeparatorVariables(final String value) {
        return value.replaceAll("\\\\,", ",");
    }
   
    
    private VariableUtils() {
        super();
    }
}
