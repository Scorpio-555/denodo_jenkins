/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * To execute tests that involve two different versions or updates of
 * the Denodo Platform, we should be able to create VDP datasources with
 * different versions of the JDBC driver.
 * <p>
 * For this scenario, we need the opposite behavior of usual Java classloading,
 * we need a child-delegation model: first checks this classloader for the JDBC
 * driver classes then delegates to the parent classloader.
 * <p>
 * From <a href="http://tech.puredanger.com/2001/11/09/classloader/">...</a> (Alex Miller)
 */
public class PostDelegationClassLoader extends URLClassLoader {

    public PostDelegationClassLoader(final URL[] urls) {
        super(urls);
    }
    
    @Override
    public Class<?> loadClass(final String name) throws ClassNotFoundException {
        // First check whether it's already been loaded, if so use it
        Class<?> loadedClass = findLoadedClass(name);
        
        if (loadedClass == null) {
            try {
                //  Try to load locally, ignore parent delegation
                loadedClass = findClass(name);
            } catch (ClassNotFoundException e) {
                // Ignore exception - does not exist locally
            }
            
            // If not found locally, use normal parent delegation in URLClassloader
            if (loadedClass == null) {
                loadedClass = super.loadClass(name);
            }
        } 

        return loadedClass;
    }

}
