/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.denodo.connect.testing.exception.TestExecutionException;

/**
 * 
 * Comma separated iterator for reading format defined by <a href="http://tools.ietf.org/html/rfc4180">RFC 4180</a>
 */
public class CSVIterator implements Iterator<List<Object>> {

    private final CSVParser parser;
    private final Iterator<CSVRecord> iterator;
    private final List<Object> header;
    private boolean first;
    private Map<String,Class<?>> classObjectMetadata;
    
    public CSVIterator(final Reader reader, final Map<String,Class<?>> classObjectMetadata) throws IOException {

        this.parser = CSVFormat.RFC4180.parse(reader);
        
        this.iterator = this.parser.iterator();
        this.classObjectMetadata = classObjectMetadata;
        if (hasNext()) {
            this.header = toList(this.iterator.next());
        } else {
            throw new IOException("No CSV header available.");
        }
        this.first = true;
        
    }

    public CSVIterator(final Reader reader) throws IOException {

        this.parser = CSVFormat.RFC4180.parse(reader);

        this.iterator = this.parser.iterator();
        if (hasNext()) {
            this.header = toList(this.iterator.next());
        } else {
            throw new IOException("No CSV header available.");
        }
        this.first = true;

    }
    
    @Override
    public boolean hasNext() {
        try {
            if( first && this.header != null && !header.isEmpty() ){
                return true;
            }
            return this.iterator.hasNext();
        } catch (Exception e) {
            close();
            throw new TestExecutionException("Error accessing CSV data", e); 
        }
    }
    
    /**
     * Each element of the iterator is a List of Strings containing the values from the next row of the CSV data. When the
     * returned result is the last element the iterator closes the reader.
     * 
     * @return a List of String. First result returned contains the column names.
     */
    @Override
    public List<Object> next() {
        
        try {
            if (this.first && hasNext()) {
                this.first = false; // first row is always the header
                return this.header;
            }
            return toList(this.iterator.next());
        } catch (Exception e) {
            close();
            throw new TestExecutionException("Error accessing CSV data", e); 
        } finally {
            if (!this.iterator.hasNext()) {
                close();
            }
        }
    }
    
    public void close() {
        
        try {
            this.parser.close();
        } catch (final IOException e) {
            // ignore
        }
    }
    
    private List<Object> toList(final CSVRecord record) {
        
        final List<Object> asList = new ArrayList<>(record.size());
        if (this.classObjectMetadata!=null) {
            for (final String item : record) {
                Class<?> classObject = this.classObjectMetadata.get(item);
                asList.add(new TextualData(item, classObject));
            }
        } else {
            for (final String item : record) {
                asList.add(new TextualData(item));
            }
        }

        return asList;
    }


    @Override
    public void remove() {
        throw new UnsupportedOperationException();        
    }
}
