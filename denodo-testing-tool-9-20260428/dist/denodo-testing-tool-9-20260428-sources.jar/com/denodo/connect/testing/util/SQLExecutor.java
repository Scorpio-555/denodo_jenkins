/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.exception.TestExecutionException;


public final class SQLExecutor {

    private static final Logger LOG = LoggerFactory.getLogger(SQLExecutor.class);
    
    
    /**
     * Executes the given SQL statement.
     * @return an Iterator over the results if the result is a ResultSet object; null if it is an update count or there are no results
     */
    public static Iterator<List<Object>> executeQuery(final DataSource dataSource, final String sql, final boolean traceEnabled) throws SQLException {
        
        Validate.notNull(dataSource, "Data source cannot be null.");
        Validate.notNull(sql, "SQL statement cannot be null.");
        
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            
            String sqlStatement = sql;
            if (traceEnabled) {
                sqlStatement = addTraceClause(sqlStatement);
            }
            
            final boolean hasResults = statement.execute(sqlStatement);
            if (hasResults) {
                LOG.debug("'" + sqlStatement + "' returned results");
                resultSet = statement.getResultSet();
            } else {
                final int rowsAffected = statement.getUpdateCount();
                LOG.debug(rowsAffected + " returned as updateCount for SQL: " + sqlStatement);
            }
            
            if (resultSet != null) {
                return new ResultSetIterator(resultSet, connection, traceEnabled);
            }
            return null;
            
        } finally {
            
            if (resultSet == null) {   // otherwise, ResultSetIterator is in charge of releasing resources after iterating over the results
                try {
                    if (statement != null) {
                        statement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    LOG.debug("Could not close JDBC resources", e);
                }
            }
        }
    }

    /**
     * Executes the given SQL script.
     * @return an Iterator over the results if the result is a ResultSet object; null if it is an update count or there are no results
     */
    public static Iterator<List<Object>> executeScript(final DataSource dataSource, final String script,
            final boolean continueOnError, final boolean ignoreErrors, final boolean traceEnabled) throws SQLException {
        
        Validate.notNull(dataSource, "Data source cannot be null.");
        Validate.notNull(script, "SQL script cannot be null.");

        boolean exceptionThrown = false;

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();

            final List<String> sqlStatements = ScriptUtils.splitSqlScript(script);
            int lineNumber = 0;
            for (String sql : sqlStatements) {
                lineNumber++;
                try {
                    if (traceEnabled) {
                        sql = addTraceClause(sql);
                    }
                    
                    final boolean hasResults = statement.execute(sql);
                    if (hasResults) {
                        LOG.debug("'" + sql + "' returned results");
                        resultSet = statement.getResultSet();
                    } else {
                        final int rowsAffected = statement.getUpdateCount();
                        LOG.debug(rowsAffected + " returned as updateCount for SQL: " + sql);
                    }

                } catch (SQLException e) {
                    if (ignoreErrors) {
                        LOG.debug("Error executing SQL script statement at statement " + lineNumber + ": " + sql, e);
                    } else {
                        LOG.error("Error executing SQL script statement at statement " + lineNumber + ": " + sql, e);
                    }
                    if (!continueOnError) {
                        exceptionThrown = true;
                        throw e;
                    }
                }
            }
            
            if (resultSet != null) {
                return new ResultSetIterator(resultSet, connection, traceEnabled);
            }
            return null;
            
        } catch (ParseException e) {
            throw new TestExecutionException("Error splitting SQL script", e); 
        } finally {
            if (resultSet == null || exceptionThrown) {
                // otherwise, ResultSetIterator is in charge
                // of releasing resources after iterating over the results
                try {
                    if (statement != null) {
                        statement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException e) {
                    LOG.debug("Could not close JDBC resources", e);
                }
            }
        }
    }
    
    /*
     * Adds TRACE clause to VDP SELECT queries.
     * 
     * Adding the TRACE clause to every statement is discarded because not all the VDP statements support the trace mode. And for the ones
     * that support it, like INSERT and DROP, this could lead to a performance overhead, and this tool is focused on testing VDP results,
     * that is, SELECT queries.
     */
    private static String addTraceClause(final String statement) {
        
        final String statementUpperCase = statement.toUpperCase().trim();
        if (statementUpperCase.startsWith("SELECT") && !statementUpperCase.contains(" TRACE")) {
            final String query = StringUtils.removeEnd(statement, ";");
            return query + " TRACE";
        }
        
        return statement;
    }
    
    
    private SQLExecutor() {
        super();
    }
}
