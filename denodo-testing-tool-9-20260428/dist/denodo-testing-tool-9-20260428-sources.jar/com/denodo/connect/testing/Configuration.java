/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing;

import java.io.IOException;
import java.io.Reader;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.Validate;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.exceptions.EncryptionInitializationException;
import org.jasypt.exceptions.EncryptionOperationNotPossibleException;
import org.jasypt.properties.EncryptableProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.exception.TestExecutionException;

/**
 * 
 * General configuration class, containing all the configuration items for the Testing Tool.
 * <p>
 * It can decrypt property values if they are encrypted. A value is considered "encrypted" when it appears surrounded by ENC(...),
 * like: 
 * <p>
 * datasource.password=ENC(!"DGAS24FaIO$)
 * <p>
 * Decryption is performed on-the-fly when the get(String) is called. Encryption password for decrypt properties should be set as 
 * a system property or an environment variable named DENODO_TEST_ENCRYPTION_PASSWORD.
 * 
 */
public class Configuration {
    
    private static final Logger LOG = LoggerFactory.getLogger(Configuration.class);
    

    private static final String ENCRYPTION_PASSWORD = "DENODO_TEST_ENCRYPTION_PASSWORD";

    private static final String ENCODING_PARAMETER = "encoding";
    private static final String REPORTER_PARAMETER = "reporter";
    private static final String MAX_ROWS_IN_MEMORY_PARAMETER = "maxRowsInMemoryForMatching";
    private static final int DEFAULT_MAX_ROWS_IN_MEMORY = 10000;
    private static final String RESULTS_DATE_PATTERN_PARAMETER = "resultsDatePattern";
    public static final String DEFAULT_RESULTS_DATE_PATTERN = "ISO8601";
    
    private final Properties properties;
    
    
    public Configuration(final Reader reader) {
        
        try {
            
            Validate.notNull(reader, "Reader cannot be null.");
            this.properties = getEncryptableProperties();
            this.properties.load(reader);
            
        } catch (IOException e) {
            throw new TestExecutionException("Could not load resource as a property list.", e);
        }
    }

    private static Properties getEncryptableProperties() {

        final StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        String encryptionPassword = System.getProperty(ENCRYPTION_PASSWORD);
        if (encryptionPassword == null) {
            encryptionPassword = System.getenv(ENCRYPTION_PASSWORD);
        }
        if (encryptionPassword != null) {
            encryptor.setPassword(encryptionPassword);
        }

        return new EncryptableProperties(encryptor);
    }
    
    public String get(final String key) {
        
        Validate.notNull(key, "Key property cannot be null.");
        try {
            final String value = this.properties.getProperty(key);
            if (value == null) {
                throw new IllegalArgumentException("Missing configuration parameter '" + key + "'");
            }

            return value;
        
        } catch (EncryptionInitializationException e) {
            throw new TestExecutionException("Could not read the encrypted variable '" +  key + "'. Encryption password for decrypt it"
                    + " should be set as a system property or an environment variable named '" + ENCRYPTION_PASSWORD + "'", e);
        } catch (EncryptionOperationNotPossibleException e) {
                throw new TestExecutionException("Could not read the encrypted variable '" +  key
                        + "'. Has been the variable encrypted with the given encryption password?", e);
            
        }
    }
    
    public Map<String, String> getReporters() {
        String key = REPORTER_PARAMETER;
        Map<String, String> reporters = getReporterKeyNameMap(key);
        if (reporters == null) {
            throw new IllegalArgumentException("Missing configuration parameter '" + key + "'");
        }

        return reporters;
    }
    
    private Map<String, String> getReporterKeyNameMap(String reporterParameter) {
        Pattern pattern = Pattern.compile("\\b"+reporterParameter+".(\\w+)");
        boolean hasReporters = false;
        Map<String, String> reporterMap = new HashMap<>();
        
        for (Enumeration<?> e = this.properties.propertyNames(); e.hasMoreElements(); ) {
          String key = (String) e.nextElement();

          Matcher matcher = pattern.matcher(key);
          if (matcher.matches()) {
              hasReporters = true;
              String value = this.properties.getProperty(key);
              reporterMap.put(key, value);
          }
        }
        return hasReporters ? reporterMap : null;
    }
    
    public Map<String, String> getReporterProperties(String reporterKey) {
        Pattern pattern = Pattern.compile("\\b"+reporterKey+".(\\w+)");
        boolean hasReporters = false;
        Map<String, String> reporterProperties = new HashMap<>();
        
        for (Enumeration<?> e = this.properties.propertyNames(); e.hasMoreElements(); ) {
            String key = (String) e.nextElement();
            
            Matcher matcher = pattern.matcher(key);
            if (matcher.matches()) {
                hasReporters = true;
                String value = this.properties.getProperty(key);
                int beginIndex = key.lastIndexOf(".") + 1;
                String propertyName = key.substring(beginIndex);
                reporterProperties.put(propertyName, value);
            }
        }
        return hasReporters ? reporterProperties : null;
    }
    
    // Convenience methods
    
    public String getCharacterEncoding() {
        return get(ENCODING_PARAMETER);
    }
    
    public String getReporter() {
        return get(REPORTER_PARAMETER);
    }
    
    /*
     * Required parameter for limiting chances of OutOfMemory exceptions being raised when matching expected and actual test results.
     * 
     * The ideal should be working with chunks of bytes, but libraries for measuring memory are extremely inefficient.
     * Therefore, the matcher will handle rows that could have a highly variable length.
     */
    public int getMaxRowsInMemory() {
        
        final String maxRowsInMemoryAsString = get(MAX_ROWS_IN_MEMORY_PARAMETER);
        int maxRowsInMemory;
        try {
            maxRowsInMemory = Integer.parseInt(maxRowsInMemoryAsString);
        } catch (NumberFormatException e) {
            maxRowsInMemory = DEFAULT_MAX_ROWS_IN_MEMORY;
            LOG.warn("'" + MAX_ROWS_IN_MEMORY_PARAMETER + "' does not contain a valid number, using '" + DEFAULT_MAX_ROWS_IN_MEMORY + "' instead", e);
        }
        
        return maxRowsInMemory;
    }
    
    public String getResultsDatePattern() {
        
        String resultsDatePattern;
        try {
            resultsDatePattern = get(RESULTS_DATE_PATTERN_PARAMETER);
        } catch (IllegalArgumentException e) {
            resultsDatePattern = DEFAULT_RESULTS_DATE_PATTERN;
        }
        
        return resultsDatePattern;
    }
    
    ////
}
