/*
 * Copyright (c) 2026. DENODO Technologies.
 * http://www.denodo.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of DENODO
 * Technologies ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with DENODO.
 */
package com.denodo.connect.testing.io;

import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * ObjectOutputStream wrapper that resets the stream cache after a certain number of writes to avoid memory leaks during
 * the serialization of large datasets.
 */
public class MemorySafeObjectOutputStream implements AutoCloseable {

    private static final int DEFAULT_RESET_THRESHOLD = 10000;

    private final ObjectOutputStream delegate;
    private final int resetThreshold;
    private int writeCount;

    /**
     * Creates a MemorySafeObjectOutputStream with the default reset threshold.
     *
     * @param delegate The underlying ObjectOutputStream to be wrapped.
     */
    public MemorySafeObjectOutputStream(final ObjectOutputStream delegate) {
        this(delegate, DEFAULT_RESET_THRESHOLD);
    }

    /**
     * Creates a MemorySafeObjectOutputStream with a custom reset threshold
     *
     * @param delegate The underlying ObjectOutputStream to be decorated.
     * @param resetThreshold The number of writes after which the stream cache will be reset.
     */
    public MemorySafeObjectOutputStream(final ObjectOutputStream delegate, final int resetThreshold) {
        this.delegate = delegate;
        this.resetThreshold = resetThreshold;
        this.writeCount = 0;
    }

    public void writeObject(final Object obj) throws IOException {
        this.delegate.writeObject(obj);
        this.writeCount++;

        // We must periodically reset the stream and clear this cache to prevent exhausting the JVM heap space
        if (this.writeCount >= this.resetThreshold) {
            this.delegate.reset();
            this.writeCount = 0;
        }
    }

    @Override
    public void close() throws IOException {
        this.delegate.close();
    }
}