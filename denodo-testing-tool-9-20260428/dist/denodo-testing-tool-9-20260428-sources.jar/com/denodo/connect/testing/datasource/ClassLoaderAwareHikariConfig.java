/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.datasource;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.reflect.FieldUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.ClassLoaderUtils;
import com.denodo.connect.testing.util.PostDelegationClassLoader;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.util.PropertyElf;

public class ClassLoaderAwareHikariConfig extends HikariConfig {
    
    private static final Logger LOG = LoggerFactory.getLogger(ClassLoaderAwareHikariConfig.class);
    
    private static final String DRIVERS_FOLDER_PROPERTY = "DENODO_TEST_DRIVERS_FOLDER";

    private static final String DRIVER_FOLDER = "drivers";
    private static final String JAR_EXTENSION = ".jar";

    /*
     * Map of drivers registered in the system. Each driver has its own classLoader.
     */
    private static final Map<String, ClassLoader> driversClassLoaders = new ConcurrentHashMap<>();

    private final String dbAdapter;
    

    public ClassLoaderAwareHikariConfig(final Properties properties, final String dbAdapter) {
        
        /*
         * We could use the constructor super(properties) but we need to set the dbAdapter property before the superclass sets its fields
         * using the Properties: dbAdapter is needed in the setDriverClassName method.
         * So we replicate the code of super(properties) constructor in this constructor. 
         */
        super();
        this.dbAdapter = dbAdapter;
        
        try {
            PropertyElf.setTargetFromProperties(this, properties);
        } catch (RuntimeException e) {
            final Throwable cause = e.getCause();
            if (cause instanceof InvocationTargetException) {
                final Throwable targetException = ((InvocationTargetException) cause).getTargetException();
                if (targetException instanceof TestExecutionException) {
                    throw (TestExecutionException) targetException;
                }
            }
            throw e;
        }
    }
    
    /**
     * Override this method for loading the driver in an isolated ClassLoader, so we can execute tests that involve
     * two different versions or updates of the Denodo Platform: each driver version in a different classloader.
     * <p>
     * As driverClassName is a private field we must force the access by reflection for setting its value.
     */
    @Override
    public void setDriverClassName(final String driverClassName) {
       try {

          loadDriver(driverClassName);
          setPrivateProperty(driverClassName);
       } catch (TestExecutionException e) {
           throw e;
       } catch (Exception e) {
          throw new TestExecutionException("driverClassName specified class '" + driverClassName + "' could not be loaded", e);
       }
    }
    
    private void setPrivateProperty(final String driverClassName) throws SecurityException, IllegalAccessException {
        
        final Field driverClassNameField = FieldUtils.getField(this.getClass(), "driverClassName", true);
        FieldUtils.writeField(driverClassNameField, this, driverClassName, true);
    }


    private void loadDriver(final String driverClassName)
        throws ClassNotFoundException, InstantiationException, IllegalAccessException,
        IOException, SQLException, NoSuchMethodException, InvocationTargetException {

        ClassLoader classLoader;
        if (this.dbAdapter == null) {
            classLoader = ClassLoaderUtils.getClassLoader(this.getClass());
            LOG.debug(driverClassName + " loaded by the application classloader");
        } else {
            classLoader = driversClassLoaders.get(this.dbAdapter);
            if (classLoader == null) {
                final File driverFolder = getDriverFolder();
                classLoader = new PostDelegationClassLoader(getDriverJars(driverFolder));
                LOG.debug("A new PostDelegationClassLoader was created for loading jars in '" + driverFolder + "'");
                driversClassLoaders.put(this.dbAdapter, classLoader);
            }
            LOG.debug(driverClassName + " loaded by an PostDelegationClassLoader");
        }

        final Driver driver = (Driver) classLoader.loadClass(driverClassName).getDeclaredConstructor().newInstance();
        
        DriverManager.registerDriver(new DriverWrapper(driver, this.dbAdapter));
    }
    
    private File getDriverFolder() {
        
        // Hack for testing classloaders in denodo-test submodule:
        // the path for the drivers folder can be set as a system property or environment variable instead of searching the drivers
        // in a relative path from the executing jar.
        String driverFolderProperty = System.getProperty(DRIVERS_FOLDER_PROPERTY);
        if (driverFolderProperty == null) {
            driverFolderProperty = System.getenv(DRIVERS_FOLDER_PROPERTY);
        }
        
        File driversFolder;
        if (driverFolderProperty != null) {
            driversFolder = new File(driverFolderProperty);
        } else {
            final String jarFile = ClassLoaderAwareHikariConfig.class.getProtectionDomain().getCodeSource().getLocation().getPath();
            final String decodedJarFile = URLDecoder.decode(jarFile, StandardCharsets.UTF_8);
            final File libFolder = new File(decodedJarFile).getParentFile();
            final File appFolder = libFolder.getParentFile();
            driversFolder = new File(appFolder, DRIVER_FOLDER);
        }
        final File driverFolder = new File(driversFolder, this.dbAdapter);
        if (!driverFolder.exists()) {
            throw new TestExecutionException("Driver type '" + this.dbAdapter + "' has no jars in location '" + driverFolder
                    + "'. Please place driver jars in the previous location.");
        }
        
        return driverFolder;
    }
    
    private static URL[] getDriverJars(final File driverFolder) throws MalformedURLException {
        
        final File[] jars = driverFolder.listFiles((dir, name) -> name.endsWith(JAR_EXTENSION));

        assert jars != null;
        final URL[] urls = new URL[jars.length];
        int i = 0;
        for (final File jar : jars) {
            urls[i++] = jar.toURI().toURL();
        }
        
        return urls;
    }
    
 }
