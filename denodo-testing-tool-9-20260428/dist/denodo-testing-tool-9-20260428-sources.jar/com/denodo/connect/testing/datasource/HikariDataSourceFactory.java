/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.datasource;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.Configuration;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class HikariDataSourceFactory {

    private static final Logger LOG = LoggerFactory.getLogger(HikariDataSourceFactory.class);
    
    private static final String DB_ADAPTER_PROPERTY = "dbAdapter";
    
    private static final String HIKARI_DRIVER_PROPERTY = "driverClassName";
    private static final String HIKARI_JDBC_URL_PROPERTY = "jdbcUrl";
    private static final String HIKARI_USER_PROPERTY = "username";
    private static final String HIKARI_PASSWORD_PROPERTY = "password";
    private static final String HIKARI_TEST_QUERY_PROPERTY = "connectionTestQuery";
    private static final String HIKARI_INITIALIZATION_FAIL_FAST_PROPERTY = "initializationFailFast";

    
    private final Configuration configuration;
    
    public HikariDataSourceFactory(final Configuration configuration) {
        this.configuration = configuration;
    }

    public HikariDataSource createDataSource(final String dataSourceId) {
        
        try {
            Validate.notNull(dataSourceId, "Data source identifier cannot be null.");

            String dbAdapter = null;
            try {
                dbAdapter = this.configuration.get(dataSourceId + "." + DB_ADAPTER_PROPERTY);
            } catch (IllegalArgumentException e) {
                // ignore exeception: property not mandatory
            }

            final Properties properties = new Properties();
            properties.setProperty(HIKARI_INITIALIZATION_FAIL_FAST_PROPERTY, "true");
            properties.setProperty(HIKARI_DRIVER_PROPERTY, this.configuration.get(dataSourceId + "." + HIKARI_DRIVER_PROPERTY));
            String jdbcUrl = this.configuration.get(dataSourceId + "." + HIKARI_JDBC_URL_PROPERTY);
            if (dbAdapter != null) {
                // When dbAdapter is not null, the driver will be loaded in a different classloader.
                // In order for DriverManager to find the right driver  , the one associated to the dbAdapter, the dbAdapter is prepend to the URL.
                // Otherwise the DriverManager will choose the first driver that accepts the URL, and could be any version of the driver (if there are many versions)
                // and not the one denoted by dbAdapter.
                jdbcUrl = dbAdapter + jdbcUrl;
            }
            properties.setProperty(HIKARI_JDBC_URL_PROPERTY, jdbcUrl);
            properties.setProperty(HIKARI_USER_PROPERTY, this.configuration.get(dataSourceId + "." + HIKARI_USER_PROPERTY));
            try {
                properties.setProperty(HIKARI_PASSWORD_PROPERTY, this.configuration.get(dataSourceId + "." + HIKARI_PASSWORD_PROPERTY));
            } catch (IllegalArgumentException e) {
                LOG.warn(dataSourceId + "." + HIKARI_PASSWORD_PROPERTY + " not found. Are you sure the server does not require a password at all for connecting as '"
                        + this.configuration.get(dataSourceId + "." + HIKARI_USER_PROPERTY) + "'?");
            }
            
            boolean foundTestQuery = true;
            try {
                final String testQuery = this.configuration.get(dataSourceId + "." + HIKARI_TEST_QUERY_PROPERTY);
                properties.setProperty(HIKARI_TEST_QUERY_PROPERTY, testQuery);
            } catch (IllegalArgumentException e) {
                foundTestQuery = false;
            }

                
            final HikariConfig hikariConfiguration = new ClassLoaderAwareHikariConfig(properties, dbAdapter);
            final HikariDataSource dataSource = new HikariDataSource(hikariConfiguration);
            if (!foundTestQuery) {
                try {
                    checkIsValidMethod(dataSourceId, dataSource.getConnection());
                } catch (SQLException e) {
                    throw new TestExecutionException("Error creating data source '" + dataSourceId + "'", e);
                }
            }
            
            return dataSource;
            
        } catch (IllegalArgumentException e) {
            throw new TestExecutionException("Error creating data source '" + dataSourceId + "'", e);
        }
    }

    private static void checkIsValidMethod(final String dataSourceId, final Connection connection) {
       
            try {
                connection.isValid(0);
            } catch (AbstractMethodError e) {
                throw new TestExecutionException("Property '" + HIKARI_TEST_QUERY_PROPERTY + "' must be specified for data source '" + dataSourceId 
                        + "'.\nThis property is the query that will be executed just before a connection is given to you from the pool to validate that the connection "
                        + "to the database is still alive.\n'" + HIKARI_TEST_QUERY_PROPERTY + "' is for drivers that do not support the JDBC4 Connection.isValid() API.", e);
            } catch (Exception e) {
                // ignore
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    LOG.debug("Could not close JDBC connection", e);
                }
            }
            
    }

}
