/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.datasource;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.commons.lang.StringUtils;

/**
 * DriverWrapper is a convenience class because, for security reasons, the
 * DriverManager will use only drivers that come from the local file system or
 * from the same class loader as the code issuing the request for a connection.
 *
 */
public class DriverWrapper implements Driver {
    
    private final Driver driver;
    private final String dbAdapter;
    
    
    public DriverWrapper(final Driver driver, final String dbAdapter) {
        this.driver = driver;
        this.dbAdapter = dbAdapter;
    }

    @Override
    public Connection connect(final String url, final Properties info) throws SQLException {

        // When dbAdapter is not null, the driver will be loaded in a different classloader.
        // In order for DriverManager to find the right driver,
        // the one associated to the dbAdapter, the dbAdapter is prepended to the URL.
        // Otherwise, the DriverManager will choose the first driver that accepts the URL,
        // and could be any version of the driver (if there are many versions)
        // and not the one denoted by dbAdapter.
        final String originalUrl = StringUtils.removeStart(url, this.dbAdapter);
        return this.driver.connect(originalUrl, info);
    }

    @Override
    public boolean acceptsURL(final String url) throws SQLException {
        
        // When dbAdapter is not null, the driver will be loaded in a different classloader.
        // In order for DriverManager to find the right driver,
        // the one associated to the dbAdapter, the dbAdapter is prepended to the URL.
        // Otherwise, the DriverManager will choose the first driver that accepts the URL,
        // and could be any version of the driver (if there are many versions)
        // and not the one denoted by dbAdapter.
        final String originalUrl = StringUtils.removeStart(url, this.dbAdapter);
        return (this.dbAdapter == null || url.startsWith(this.dbAdapter)) && this.driver.acceptsURL(originalUrl);
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(final String url, final Properties info) throws SQLException {

        // When dbAdapter is not null, the driver will be loaded in a different classloader.
        // In order for DriverManager to find the right driver,
        // the one associated to the dbAdapter, the dbAdapter is prepended to the URL.
        // Otherwise, the DriverManager will choose the first driver that accepts the URL,
        // and could be any version of the driver (if there are many versions)
        // and not the one denoted by dbAdapter.
        final String originalUrl = StringUtils.removeStart(url, this.dbAdapter);
        return this.driver.getPropertyInfo(originalUrl, info);
    }

    @Override
    public int getMajorVersion() {
        return this.driver.getMajorVersion();
    }

    @Override
    public int getMinorVersion() {
        return this.driver.getMinorVersion();
    }

    @Override
    public boolean jdbcCompliant() {
        return this.driver.jdbcCompliant();
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        
        return this.driver.getParentLogger();
    }
    
   
}
