/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.datasource;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.Validate;

import com.zaxxer.hikari.HikariDataSource;

public class DataSourceLocator {

    private final HikariDataSourceFactory factory;
    private final Map<String, HikariDataSource> dataSources;
    
    public DataSourceLocator(final HikariDataSourceFactory factory) {
        this.factory = factory;
        this.dataSources = new ConcurrentHashMap<>();
    }
    
    public HikariDataSource get(final String dataSourceId) {
        
        Validate.notNull(dataSourceId, "Datasource identifier cannot be null");
        
        HikariDataSource dataSource = this.dataSources.get(dataSourceId);
        if (dataSource == null) {
            dataSource = this.factory.createDataSource(dataSourceId);
            this.dataSources.put(dataSourceId, dataSource);
        }
        
        return dataSource;
    }
    
    public void shutdown() {
        
        for (final HikariDataSource dataSource : this.dataSources.values()) {
            dataSource.close();
        }
    }
}
