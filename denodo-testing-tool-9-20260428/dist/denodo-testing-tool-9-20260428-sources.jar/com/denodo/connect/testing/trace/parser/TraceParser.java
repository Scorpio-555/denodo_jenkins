/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.trace.parser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.trace.Trace;

public class TraceParser implements ITraceParser {
    
    private static final String PLAN_START_DELIMITER = "(";
    private static final String PLAN_END_DELIMITER = ")";
    private static final String PROPERTY_VALUE_DELIMITER = "=";

    @Override
    public Trace parse(final String trace) {

        BufferedReader br = null;
        try {

            final LinkedList<Trace> stackPlanTrace = new LinkedList<>();
            Trace planTrace = new Trace();
            
            br = new BufferedReader(new StringReader(trace));
            String line = br.readLine();
            while (line != null) {

                if (StringUtils.isBlank(line)) {
                    line = br.readLine();
                    continue;
                }
                
                if (beginsPlanTrace(line)) {
                    
                    final String subPlanName = line.substring(0, line.length() - 1).trim();
                    final Trace subPlanTrace = new Trace();
                    planTrace.put(subPlanName, subPlanTrace);
                    stackPlanTrace.add(planTrace);
                    
                    planTrace = subPlanTrace;
                    
                } else if (isPropertyLine(line)) {
                    final int delimiterIndex = line.indexOf(PROPERTY_VALUE_DELIMITER);
                    final String propertyName = line.substring(0, delimiterIndex);
                    final String propertyValue = line.substring(delimiterIndex + 1);
                    
                    planTrace.put(propertyName.trim(), propertyValue.trim());
                
                // end of Plan must be the last check, because some property lines contain PLAN_END_DELIMITER 
                // like bug #21292 with property line: "joinCondition = company_code = replace(code, 'ENT', 'COM')"
                } else if (endsPlanTrace(line)) { 
                    planTrace = stackPlanTrace.removeLast();
                }
                
                line = br.readLine(); 
            }

            return planTrace;
            
        } catch (IOException e) {
            throw new TestExecutionException("Error reading trace '" + trace + "'", e);
        } finally {
            IOUtils.closeQuietly(br);
        }
        
    }

    private static boolean beginsPlanTrace(final String line) {
        return line.endsWith(PLAN_START_DELIMITER);
    }
    
    private static boolean endsPlanTrace(final String line) {
        return line.endsWith(PLAN_END_DELIMITER);
    }
    
    private static boolean isPropertyLine(final String line) {
        return line.contains(PROPERTY_VALUE_DELIMITER);
    }

}
