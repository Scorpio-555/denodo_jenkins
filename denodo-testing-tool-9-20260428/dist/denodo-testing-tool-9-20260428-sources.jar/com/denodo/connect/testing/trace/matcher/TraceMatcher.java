/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.trace.matcher;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.mvel2.MVEL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestResult;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.trace.Trace;
import com.denodo.connect.testing.trace.parser.ITraceParser;

public class TraceMatcher implements ITraceMatcher {
    
    private static final Logger LOG = LoggerFactory.getLogger(TraceMatcher.class);

    private static final char SINGLE_QUOTE = '\'';
    private static final char DOUBLE_QUOTE = '"';
    private static final char ESCAPE = '\\';

    private final ITraceParser traceParser;
    
    public TraceMatcher(final ITraceParser traceParser) {
    
        Validate.notNull(traceParser, "Trace parser cannot be null.");
        this.traceParser = traceParser;
    }
    
    @Override
    public ITestResult match(final String traceText, final String expression) {
        
        Validate.notNull(expression, "Trace expression cannot be null");
        
        if (traceText == null) {
            return new TestResult(false, "Obtained trace was null, the MVEL expression \"" + expression + "\" could not be evaluated.", null);
        }
        
        final Trace trace = this.traceParser.parse(traceText);
        return match(trace, expression);
    }
    
    @Override
    public ITestResult match(final String traceText, final List<String> expressions) {
        
        Validate.notEmpty(expressions, "Trace expressions cannot be empty");
        
        if (traceText == null) {
            if (expressions.size() == 1) {
                return new TestResult(false, "Obtained trace was null, the MVEL expression \"" + expressions.get(0) + "\" could not be evaluated.", null);
            }
            return new TestResult(false, "Obtained trace was null, the MVEL expressions \"" + expressions + "\" could not be evaluated.", null);
        }
        
        final Trace trace = this.traceParser.parse(traceText);
        
        final List<ITestResult> results = new ArrayList<>();
        for (final String expression : expressions) {
            results.add(match(trace, expression));
        }
        
        return mergeResults(results);
    }
    
    private static ITestResult match(final Trace trace, final String expression) {
        
        try {
            // If the class whose property is being accessed is a map,
            // the key of that map is the property name, so no blanks are allowed.
            // For simplicity,
            // all blanks are removed from the MVEL expression unless literals between single quotes or double quotes.
            final String expressionWithoutBlanks = removeBlanksUnlessQuoted(expression);
            final Boolean result = MVEL.evalToBoolean(expressionWithoutBlanks, trace);

            if (result) {
                return new TestResult(true, "Obtained and expected traces match.", null);
            }
            return new TestResult(false, "Obtained trace do NOT match the MVEL expression \"" + expression + "\".", null);

        } catch (Exception e) {
            LOG.error("Error evaluating expression '" + expression + "'", e);
            throw new TestExecutionException("Error in MVEL expression '" + expression + "': " + e.getMessage(), e);
        }
    }

    private static ITestResult mergeResults(final List<ITestResult> results) {
        
        boolean ok = true;
        final StringBuilder sb = new StringBuilder();
        for (final ITestResult result : results) {
            ok = ok && result.isOK();
            if (!result.isOK() && result.hasMessage()) { // Only appends messages for failed matches since they contain hints for the user.
                if (!sb.isEmpty()) {
                    sb.append('\n');
                }
                sb.append(result.getMessage());
            }
        }
        
        final String message = ok? "Obtained and expected traces match." : sb.toString();
        
        return new TestResult(ok, message, null);
    }
    
    /*
     *  Notice this method handles also escaped quotes.
     */
    private static String removeBlanksUnlessQuoted(String expression) {
        
        StringBuilder sb = new StringBuilder();
        char c;
        char previousChar = ' ';
        char quote = ' ';
        int n = expression.length();
        int i = 0;
        boolean withinQuotes = false;
        while (n-- != 0) {
            c = expression.charAt(i);
            if (i != 0) {
                previousChar = expression.charAt(i - 1);
            }
            i++;
            
            if (beginQuotes(c, previousChar, withinQuotes)) {
                withinQuotes = true;
                quote = c;
                sb.append(c);
                continue;
            }
                               
            if (Character.isSpaceChar(c)) {
                if (withinQuotes) {
                    sb.append(c);
                }
            } else {
                sb.append(c);
            }
            
            if (endQuotes(c, previousChar, quote, withinQuotes)) {
                withinQuotes = false;
                quote = ' ';
            }
        }
        
        return sb.toString();

    }

    private static boolean beginQuotes(char c, char previousChar, boolean withinQuotes) {
        return !withinQuotes && (c == SINGLE_QUOTE || c == DOUBLE_QUOTE) && previousChar != ESCAPE;
    }

    private static boolean endQuotes(char c, char previousChar, char quote, boolean withinQuotes) {
        return withinQuotes && (c == quote) && previousChar != ESCAPE;
    }

}
