/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.trace;

import java.io.Serial;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * This class represents the VDP execution trace. The root plan is a Map that can contain:
 * - String properties: key and value.
 * - A subplan: Trace class.
 * - A list of subplans.
 * <p>
 * This representation is easily navigable using an expression language like MVEL, OGNL...
 */
public class Trace extends LinkedHashMap<String, Object>{

    @Serial
    private static final long serialVersionUID = -8411193034018945373L;

    private final Map<String, Object> properties;
    
    public Trace() {
        super();
        this.properties = new LinkedHashMap<>();
    }
    
    @Override
    public Object get(final Object key) {
        final String keyWithoutBlanks = normalizeKey(key); 
        return this.properties.get(keyWithoutBlanks);
    }

    @Override
    public boolean containsKey(final Object key) {
        return get(key) != null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object put(final String key, Object value) {
        
        final String keyWithoutBlanks = normalizeKey(key); 
        
        if (this.properties.containsKey(keyWithoutBlanks)) {
            final Object previousValue = this.properties.get(keyWithoutBlanks);
            if (previousValue instanceof Trace) {
                final List<Trace> list = new ArrayList<>();
                list.add((Trace) previousValue);
                list.add((Trace) value);
                this.properties.put(keyWithoutBlanks, list);
                
                return previousValue;
                
            } else if (previousValue instanceof List) {
                final List<Trace> list = (List<Trace>) previousValue;
                list.add((Trace) value);
                
                return previousValue;
            }
        }
        
        this.properties.put(keyWithoutBlanks, value);
        return null;
        
    }
    
    /*
     * Remove blanks: The key of the map is the name of each property of the VDP trace,
     * and no blanks are allowed in it when using MVEL.
     * Lower case.
     */
    private static String normalizeKey(final Object key) {
        return StringUtils.deleteWhitespace((String) key).toLowerCase();
    }
    
    
    @Override
    public String toString() {
        return this.properties.toString();
    }
    
}
