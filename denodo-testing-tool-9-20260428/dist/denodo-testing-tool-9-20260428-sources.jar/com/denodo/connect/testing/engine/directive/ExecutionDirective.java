/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;


import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.ChildDirectiveCombiner;
import com.denodo.connect.testing.engine.qualifier.QueryProcessor;
import com.denodo.connect.testing.engine.qualifier.ScriptProcessor;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers;
import com.denodo.connect.testing.engine.qualifier.WebServiceProcessor;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.ws.rest.IRESTClient;

public class ExecutionDirective extends AbstractQualifiedDirective {

    private static final Logger LOG = LoggerFactory.getLogger(ExecutionDirective.class);
    
    
    public ExecutionDirective(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator,
            final IRESTClient restClient) {
        
        super(true, new ChildDirectiveCombiner());
        initQualifierProcessors(testResourceResolver, dataSourceLocator, restClient);
    }

    @Override
    public String getName() {
        return "EXECUTION";
    }

    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {
        
        LOG.debug("Starting to process directive '" + getName() + "'");
        
        final long startTimeNanos = System.nanoTime();
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");
        
        final IDataSet actualDataSet = processQualifier(testName, field, context);
        if (actualDataSet == null) {
            throw new TestExecutionException("Directive '" + getName() + "' returns no results. Current configuration is " + field);
        }
        
        context.setActualDataSet(actualDataSet);
        
        final long endTimeNanos = System.nanoTime();
        final long executionTimeNanos = endTimeNanos - startTimeNanos;
        context.setExecutionTimeNanos(executionTimeNanos);
        
        LOG.debug("Test actual data set is: " + actualDataSet);
        
    }
    
    protected void initQualifierProcessors(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator,
            final IRESTClient restClient) {
        
        final boolean ignoreErrors = true; 
        final boolean supportTracing = true;
        addQualifierProcessor(StandardQualifiers.QUERY, new QueryProcessor(dataSourceLocator, ignoreErrors, supportTracing));
        addQualifierProcessor(StandardQualifiers.SCRIPT, new ScriptProcessor(testResourceResolver, dataSourceLocator, ignoreErrors, supportTracing));
        addQualifierProcessor(StandardQualifiers.WS, new WebServiceProcessor(restClient, ignoreErrors));

    }

}
