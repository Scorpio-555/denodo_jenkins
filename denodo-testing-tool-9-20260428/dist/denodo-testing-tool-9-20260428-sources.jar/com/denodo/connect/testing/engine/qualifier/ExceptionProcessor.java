/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.io.Serial;

import com.denodo.connect.testing.engine.DataSet;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.testable.FieldValue;

public class ExceptionProcessor extends AbstractQualifierProcessor {

    
    @Override
    public IDataSet process(final String testName, final FieldValue fieldValue, final TestExecutorContext context) {

        final String text = fieldValue.getText();
        final Class<? extends Throwable> clazz = tryConvertToThrowableClass(text);

        if (clazz != null) {
            return new DataSet(new ClassContainerException(clazz));
        }

        return new DataSet(new MessageContainerException(text));
    }



    @SuppressWarnings("unchecked")
    private static Class<? extends Throwable> tryConvertToThrowableClass(final String text) {
        final Class<?> clazz;
        try {
            clazz = Thread.currentThread().getContextClassLoader().loadClass(text);
        } catch (final ClassNotFoundException e) {
            return null;
        }
        return (Class<? extends Throwable>) clazz;
    }





    public interface TestEngineSyntheticException {
        // Just a marker interface
    }


    /**
     * <p>
     *   Specialized exception implementation meant not to be thrown as such, but merely to act as a container of
     *   an expected exception message, suitable for being used in DataSet matching operations.
     * </p>
     */
    public static final class MessageContainerException extends Exception implements TestEngineSyntheticException {

        @Serial
        private static final long serialVersionUID = -3641762666430036580L;

        MessageContainerException(final String message) {
            super(message);
        }

    }

    /**
     * <p>
     *   Specialized exception implementation meant not to be thrown as such, but merely to act as a container of
     *   an expected exception class, suitable for being used in DataSet matching operations.
     * </p>
     */
    public static final class ClassContainerException extends Exception implements TestEngineSyntheticException {

        @Serial
        private static final long serialVersionUID = -1641762661430236580L;

        private final Class<? extends Throwable> clazz;

        ClassContainerException(final Class<? extends Throwable> clazz) {
            super(createMessage(clazz));
            this.clazz = clazz;
        }


        private static String createMessage(final Class<? extends Throwable> clazz) {
            if (clazz == null) {
                throw new IllegalArgumentException("Contained class cannot be null");
            }
            return "Class container exception for class \"" + clazz.getName() + "\"";
        }

        public Class<? extends Throwable> getContainedClass() {
            return this.clazz;
        }

    }

}
