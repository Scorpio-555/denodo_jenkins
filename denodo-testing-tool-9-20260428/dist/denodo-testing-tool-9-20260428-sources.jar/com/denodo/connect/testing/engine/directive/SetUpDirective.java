/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.AddValuesCombiner;
import com.denodo.connect.testing.engine.qualifier.QueryProcessor;
import com.denodo.connect.testing.engine.qualifier.ScriptProcessor;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.testable.Field;

public class SetUpDirective extends AbstractQualifiedDirective {

    private static final Logger LOG = LoggerFactory.getLogger(SetUpDirective.class);
    
    /*
     * This constant is public because com.denodo.connect.testing.testable.parser.TestParser needs to validate first.denodotest files. 
     */
    public static final String SETUP_DIRECTIVE_FIELD = "SETUP";
    
    public SetUpDirective(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator) {
        super(false, new AddValuesCombiner());
        initQualifierProcessors(testResourceResolver, dataSourceLocator);
    }

    @Override
    public String getName() {
        return SETUP_DIRECTIVE_FIELD;
    }

    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {
    
        LOG.debug("Starting to process directive '" + getName() + "'");
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");

        processMultipleQualifiers(testName, field, context);

    }

    private void initQualifierProcessors(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator) {
        
        final boolean ignoreErrors = true;
        final boolean supportTracing = false;
        
        addQualifierProcessor(StandardQualifiers.QUERY, new QueryProcessor(dataSourceLocator, ignoreErrors, supportTracing));
        addQualifierProcessor(StandardQualifiers.SCRIPT, new ScriptProcessor(testResourceResolver, dataSourceLocator, ignoreErrors, supportTracing));
    }

}
