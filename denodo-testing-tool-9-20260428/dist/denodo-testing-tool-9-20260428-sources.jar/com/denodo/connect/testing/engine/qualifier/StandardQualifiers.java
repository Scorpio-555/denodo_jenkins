/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;



public enum StandardQualifiers {
    
    SCRIPT,
    
    QUERY,
    
    CSV,
    
    DATA,
    
    EXCEPTION,
    
    WS;
    
    
    public static StandardQualifiers fromName(final String name) {
        return StandardQualifiers.valueOf(name.toUpperCase());
    }

    public String lowerCase() {
        return name().toLowerCase();
    }
    
    @Override
    public String toString() {
        return lowerCase();
    }
    
    
    
    public enum StandardContextValues {
        DS,
        
        TYPE,
        
        ORDERED, 
        
        DATEPATTERN,
        
        USER,
        
        PASSWORD,
        
        MAPPINGS,
        
        COMPLEX_ORDERED;
        
        
        public String lowerCase() {
            return name().toLowerCase();
        }
        
        @Override
        public String toString() {
            return lowerCase();
        }
    }
    
    public enum StandardSetTypes {
        FULL,
        
        SUBSET,
        
        SUPERSET;
        
        
        public String lowerCase() {
            return name().toLowerCase();
        }
        
        @Override
        public String toString() {
            return lowerCase();
        }
    }
}
