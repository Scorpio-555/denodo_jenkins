/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import java.util.Collection;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.IDirectiveCombiner;
import com.denodo.connect.testing.engine.qualifier.IQualifierProcessor;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;

public abstract class AbstractQualifiedDirective extends AbstractDirective {

    private static final Logger LOG = LoggerFactory.getLogger(AbstractQualifiedDirective.class);
    
    private final Map<StandardQualifiers, IQualifierProcessor> processorByQualifier;
    
   
    public AbstractQualifiedDirective(final boolean required, final IDirectiveCombiner combinationAction) {
        super(required, combinationAction);
        this.processorByQualifier = new EnumMap<>(StandardQualifiers.class);
    }
    
    
    public Collection<StandardQualifiers> getQualifiers() {
        return this.processorByQualifier.keySet();
    }
    
    public IQualifierProcessor getQualifierProcessor(final String qualifierName) {

        try {

            final StandardQualifiers qualifier = StandardQualifiers.fromName(qualifierName);
            if (this.processorByQualifier.containsKey(qualifier)) {
                return this.processorByQualifier.get(qualifier);
            }
            
            throw new TestExecutionException("Qualifier '" + qualifierName + "' cannot be specified for the directive " + getName());

        } catch (IllegalArgumentException e) {
            throw new TestExecutionException("Unknown value '" + qualifierName + "' for a directive qualifier");
        }

    }
    
    public void addQualifierProcessor(final StandardQualifiers qualifier, final IQualifierProcessor processor) {
        this.processorByQualifier.put(qualifier, processor);
    }
    
    private IDataSet processQualifiers(final String testName, final Field field, final TestExecutorContext context, final boolean processMultipleQualifiers,
            final boolean reportError) {
        
        IDataSet dataSet = null;

        boolean qualifierFound = false;
        for (final Iterator<FieldValue> it = field.getValues().iterator(); it.hasNext() && (processMultipleQualifiers || !qualifierFound);) {
            
            final FieldValue fieldValue = it.next();
            final String qualifierName = fieldValue.getQualifier();
            if (qualifierName != null) {
                final IQualifierProcessor qualifierProcessor = getQualifierProcessor(qualifierName);
                LOG.debug("Starting to process qualifier '" + qualifierName + "'");
                qualifierFound = true;
                dataSet = qualifierProcessor.process(testName, fieldValue, context);
                if (reportError) {
                    propagateError(dataSet);
                }
            }
        }

        if (!qualifierFound) {
            throw new TestExecutionException("Directive '" + getName() + "' requires a qualifier. Supported qualifiers are: "
                    + getQualifiers());
        }
        
        return dataSet;
    }


    private static void propagateError(final IDataSet dataSet) {
        
        if (dataSet != null && dataSet.getThrowable() != null) {
            throw new TestExecutionException(dataSet.getThrowable());
        }
    }

    public IDataSet processQualifier(final String testName, final Field field, final TestExecutorContext context) {        
        return processQualifiers(testName, field, context, false, false);
    }
    
    public void processMultipleQualifiers(final String testName, final Field field, final TestExecutorContext context) {
        processQualifiers(testName, field, context, true, true);
    }
}
