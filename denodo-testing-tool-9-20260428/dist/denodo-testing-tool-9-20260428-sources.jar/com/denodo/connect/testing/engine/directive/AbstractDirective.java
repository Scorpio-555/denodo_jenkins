/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.IDirectiveCombiner;
import com.denodo.connect.testing.testable.Field;


public abstract class AbstractDirective implements IDirective {

    private final boolean required;
    private final IDirectiveCombiner combinationAction;

    
    public AbstractDirective(final boolean required, final IDirectiveCombiner combinationAction) {
        this.required = required;
        this.combinationAction = combinationAction;
    }
    
    @Override
    public boolean isRequired() {
        return this.required;
    }

    @Override
    public Field combine(final Field childField, final Field parentField) {
        return this.combinationAction.combine(childField, parentField);
    }

    @Override
    public void process(final String testName, final Field field, final TestExecutorContext context) {

        field.replaceVariables(context.getContextVariables());        
        doProcess(testName, field, context);
    }
    
    public abstract void doProcess(final String testName, final Field field, final TestExecutorContext context);
}
