/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.DataSet;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardContextValues;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.ws.rest.IRESTClient;

public class WebServiceProcessor extends AbstractQualifierProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(WebServiceProcessor.class);
    
    /**
     * Date Pattern used by date VDP type in their web services.
     */
    private static final String REST_DATE_PATTERN = "ISO8601";
    
    /**
     * Date Pattern used by timestamp VDP type in their web services.
     */
    private static final String REST_TIMESTAMP_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";

    
    /**
     * Dates in RSS conform to RFC 822.
     */
    private static final String RSS_RFC822_PATTERN = "E, d MMM yyyy H:mm:ss z";
  
    private final IRESTClient restClient;
        
    /**
     * Whether errors are considered errors or not. When they are not considered errors (ignored):
     * - There are not logged with ERROR level, because they could be the expected result of a test, and they just clutter the log.
     * - The exception is not thrown, it is stored in the DataSet for comparing it later with the expected result that can be an exception
     * (qualifier exception) or not.
     */
    protected final boolean ignoreErrors;
    
    
    public WebServiceProcessor(final IRESTClient restClient, final boolean ignoreErrors) {
        super();
        
        Validate.notNull(restClient, "REST client cannot be null");
        
        this.restClient = restClient;
        this.ignoreErrors = ignoreErrors;
    }
    
    @Override
    public IDataSet process(final String testName, final FieldValue fieldValue, final TestExecutorContext context) {

        IDataSet dataSet;
        try {
            
            final Iterator<List<Object>> dataSetIterator = executeRESTRequest(fieldValue);
            final boolean ordered = false; // VDP web services data sets are unordered by default
            dataSet = buildDataSet(dataSetIterator, fieldValue, ordered);
            addVDPWebServiceDatePatterns(dataSet);
        
        } catch (final Exception e) {
            if (this.ignoreErrors) {
                LOG.debug("Error calling URI '" + fieldValue.getText() + "'", e);
                dataSet = new DataSet(e);
            } else {
                throw new TestExecutionException("Error calling URI  '" + fieldValue.getText() + "': " + e.getLocalizedMessage(), e);
            }

        } finally {
            this.restClient.cleanup();
        }
        
        return dataSet;
    }

    private void addVDPWebServiceDatePatterns(final IDataSet dataSet) {
        dataSet.addDatePattern(REST_DATE_PATTERN);
        dataSet.addDatePattern(REST_TIMESTAMP_PATTERN);
        dataSet.addDatePattern(RSS_RFC822_PATTERN);
    }

    private Iterator<List<Object>> executeRESTRequest(final FieldValue fieldValue) throws IOException {
        
        final String uri = fieldValue.getText();
        setRESTCredentials(fieldValue);
        setRESTParameters(fieldValue);
        return this.restClient.get(uri);
    }

    private void setRESTCredentials(final FieldValue fieldValue) {
        
        final String user = extractContextVariable(StandardContextValues.USER, fieldValue);
        final String password = extractContextVariable(StandardContextValues.PASSWORD, fieldValue);
        this.restClient.setCredentials(user, password);
    }
    
    private void setRESTParameters(final FieldValue fieldValue) {
        
        final String mappings = extractContextVariable(StandardContextValues.MAPPINGS, fieldValue);
        this.restClient.addParameter(StandardContextValues.MAPPINGS.name(), mappings);
    }
    

}
