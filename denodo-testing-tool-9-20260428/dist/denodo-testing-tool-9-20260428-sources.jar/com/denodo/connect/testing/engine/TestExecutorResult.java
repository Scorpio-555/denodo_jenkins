/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;

import java.util.ArrayList;
import java.util.List;

public class TestExecutorResult {

    private int okTests;
    private int totalTests;
    private long executionTimeNanos;
    private long totalTuples;
    private int zeroTuplesTests;
    private final List<TestInformation> failedTests = new ArrayList<>();
    private final List<TestInformation> allTests = new ArrayList<>();
    
    public TestExecutorResult() {
        super();
    }
    
    public TestExecutorResult(final boolean ok, final long executionTime, final int totalTuples, final TestInformation testInformation) {
        super();
        
        this.okTests += ok ? 1 : 0;
        this.executionTimeNanos += executionTime;
        this.totalTests ++;
        this.totalTuples += totalTuples;
        this.zeroTuplesTests += totalTuples == 0 ? 1 : 0;

        this.allTests.add(testInformation);
        if (!ok) {
            this.failedTests.add(testInformation);
        }
    }
        
    public void addResults(final TestExecutorResult result) {
        
        this.okTests += result.getOkTests();
        this.executionTimeNanos += result.getExecutionTimeNanos();
        this.totalTests += result.getTotalTests();
        this.totalTuples += result.getTotalTuples();
        this.zeroTuplesTests += result.getZeroTuplesTests();
        this.failedTests.addAll(result.getFailedTests());
        this.allTests.addAll(result.getAllTests());
    }
    
    public int getOkTests() {
        return this.okTests;
    }

    public int getTotalTests() {
        return this.totalTests;
    }

    public long getExecutionTimeNanos() {
        return this.executionTimeNanos;
    }

    public List<TestInformation> getFailedTests() {
        return this.failedTests;
    }
    
    public List<TestInformation> getAllTests() {
        return this.allTests;
    }

    public long getTotalTuples() {
        return this.totalTuples;
    }

    public int getZeroTuplesTests() {
        return this.zeroTuplesTests;
    }


    public static class TestInformation {

        private final String name;
        private final String resource;
        private final String msg;
        private final long executionTimeNanos;
        private final boolean ok;
        private final int totalTuples;


        public TestInformation(final String name, final String resource, final String msg,
            final long executionTimeNanos, final boolean ok, final int totalTuples) {
            this.name = name;
            this.resource = resource;
            this.msg = msg;
            this.executionTimeNanos = executionTimeNanos;
            this.ok = ok;
            this.totalTuples = totalTuples;
        }


        public String getName() {
            return this.name;
        }

        public String getResource() {
            return this.resource;
        }

        public String getMsg() {
            return this.msg;
        }

        public long getExecutionTimeNanos() {
            return this.executionTimeNanos;
        }

        public boolean isOk() {
            return this.ok;
        }

        public int getTotalTuples() {
            return this.totalTuples;
        }


    }

}
