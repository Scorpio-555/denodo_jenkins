/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;


public class TestResult implements ITestResult {
    
    private final boolean ok;
    private final String message;
    private final Throwable throwable;


    public TestResult(final boolean ok, final String message, final Throwable throwable) {

        super();

        if (message == null) {
            throw new IllegalArgumentException("Test Result message cannot be null");
        }

        this.ok = ok;
        this.message = message;
        this.throwable = throwable;

    }

    @Override
    public boolean isOK() {
        return this.ok;
    }

    @Override
    public boolean hasMessage() {
        return this.message != null;
    }

    @Override
    public String getMessage() {
        return this.message;
    }

    @Override
    public boolean hasThrowable() {
        return this.throwable != null;
    }

    @Override
    public Throwable getThrowable() {
        return this.throwable;
    }

    @Override
    public String toString() {
        return "OK=" + this.ok + ", message=" + this.message + ", throwable=" + this.throwable + "]";
    }

    
}
