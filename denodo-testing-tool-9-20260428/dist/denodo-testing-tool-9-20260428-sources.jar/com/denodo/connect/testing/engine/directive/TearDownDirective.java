/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;

public class TearDownDirective extends SetUpDirective {
    
    /*
     * This constant is public because com.denodo.connect.testing.testable.parser.TestParser needs to validate last.denodotest files. 
     */
    public static final String TEARDOWN_DIRECTIVE_FIELD = "TEARDOWN";

    public TearDownDirective(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator) {
        super(testResourceResolver, dataSourceLocator);
    }
    
    @Override
    public String getName() {
        return TEARDOWN_DIRECTIVE_FIELD;
    }
    

}
