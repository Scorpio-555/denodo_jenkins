/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.qualifier.CSVFileProcessor;
import com.denodo.connect.testing.engine.qualifier.CSVProcessor;
import com.denodo.connect.testing.engine.qualifier.ExceptionProcessor;
import com.denodo.connect.testing.engine.qualifier.QueryProcessor;
import com.denodo.connect.testing.engine.qualifier.ScriptProcessor;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers;
import com.denodo.connect.testing.engine.qualifier.WebServiceProcessor;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.matching.IDataSetMatcher;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.ws.rest.IRESTClient;

public class ResultsDirective extends ExecutionDirective {

    private static final Logger LOG = LoggerFactory.getLogger(ResultsDirective.class);
    
    private final IDataSetMatcher dataSetMatcher;
    
    public ResultsDirective(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator,
            final IDataSetMatcher dataSetMatcher, final IRESTClient restClient) {
        
        super(testResourceResolver, dataSourceLocator, restClient);
        
        Validate.notNull(dataSetMatcher, "Data set matcher cannot be null.");
        this.dataSetMatcher = dataSetMatcher;
    }
    
    @Override
    public String getName() {
        return "RESULTS";
    }
    
    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {
        
        LOG.debug("Starting to process directive '" + getName() + "'");
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");
        
        final IDataSet expectedDataSet = processQualifier(testName, field, context);
        if (expectedDataSet == null) {
            throw new TestExecutionException("Directive '" + getName() + "' returns no results. Current configuration is " + field);
        }
        
        LOG.debug("Test expected data set is: " + expectedDataSet);
        context.setExpectedDataSet(expectedDataSet);

        final ITestResult testResult = this.dataSetMatcher.match(context.getActualDataSet(), context.getExpectedDataSet());
        context.setTestResult(testResult);

        LOG.debug("Test result after matching is: " + testResult);
    }
    
    @Override
    protected void initQualifierProcessors(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator,
            final IRESTClient restClient) {
        
        final boolean ignoreErrors = false;
        final boolean supportTracing = false;
        
        addQualifierProcessor(StandardQualifiers.QUERY, new QueryProcessor(dataSourceLocator, ignoreErrors, supportTracing));
        addQualifierProcessor(StandardQualifiers.SCRIPT, new ScriptProcessor(testResourceResolver, dataSourceLocator, ignoreErrors, supportTracing));
        addQualifierProcessor(StandardQualifiers.CSV, new CSVFileProcessor(testResourceResolver, ignoreErrors));
        addQualifierProcessor(StandardQualifiers.DATA, new CSVProcessor(ignoreErrors));
        addQualifierProcessor(StandardQualifiers.EXCEPTION, new ExceptionProcessor());
        addQualifierProcessor(StandardQualifiers.WS, new WebServiceProcessor(restClient, ignoreErrors));
    }

}
