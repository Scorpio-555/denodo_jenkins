/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.AddValuesCombiner;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.trace.matcher.ITraceMatcher;

public class TraceDirective extends AbstractDirective {

    private static final Logger LOG = LoggerFactory.getLogger(TraceDirective.class);
    
    /*
     * This constant is public because com.denodo.connect.testing.engine.TestExecutor needs to access TRACE directive to
     * determine VQL execution is in trace mode or not. 
     */
    public static final String TRACE_DIRECTIVE_FIELD = "TRACE";
    
    private final ITraceMatcher traceMatcher;
    
    
    public TraceDirective(final ITraceMatcher traceMatcher) {
        
        super(false, new AddValuesCombiner());
        
        Validate.notNull(traceMatcher, "Trace matcher cannot be null.");
        
        this.traceMatcher = traceMatcher;
    }

    
    @Override
    public String getName() {
        return TRACE_DIRECTIVE_FIELD;
    }

    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {
        
        LOG.debug("Starting to process directive '" + getName() + "'");
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");
        
        final List<FieldValue> fieldValues = field.getValuesWithoutQualifier();
        if (!fieldValues.isEmpty()) {
            final List<String> traceExpressions = new ArrayList<>();
            for (final FieldValue fieldValue : fieldValues) {
                traceExpressions.add(fieldValue.getText());
            }

            final ITestResult traceResult = this.traceMatcher.match(context.getActualTrace(), traceExpressions);
            context.addTraceResult(traceResult);
            LOG.debug("Trace result after matching is: "  + traceResult);
        }
    }

}
