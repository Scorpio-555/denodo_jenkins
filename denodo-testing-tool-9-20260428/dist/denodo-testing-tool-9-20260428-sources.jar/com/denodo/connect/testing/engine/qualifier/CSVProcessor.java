/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.DataSet;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.util.CSVIterator;
import com.denodo.connect.testing.util.MetadataDataSetUtils;

public class CSVProcessor extends AbstractQualifierProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(CSVProcessor.class);
    
    /**
     * Whether errors are considered errors or not. When they are not considered errors (ignored):
     * - There are not logged with ERROR level, because they could be the expected result of a test, and they just clutter the log.
     * - The exception is not thrown, it is stored in the DataSet for comparing it later with the expected result that can be an exception
     * (qualifier exception) or not.
     */
    private final boolean ignoreErrors;
    
    
    public CSVProcessor(final boolean ignoreErrors) {
        super();
        this.ignoreErrors = ignoreErrors;
    }
    
    @Override
    public IDataSet process(final String testName, final FieldValue fieldValue, final TestExecutorContext context) {

        IDataSet dataSet;
        try {
            final boolean ordered = true; // CSV based data sets are ordered by default
            final Iterator<List<Object>> dataSetIterator;
            if(context.getActualDataSet()!=null && context.getActualDataSet().getResultSetMetadata()!=null){
                dataSetIterator = readCSV(testName, fieldValue.getText(),
                    MetadataDataSetUtils.getClassObjectFromMetadata(context.getActualDataSet().getResultSetMetadata()));
                dataSet = buildDataSet(dataSetIterator, fieldValue, ordered,context.getActualDataSet()
                    .getResultSetMetadata());
            }else{
                dataSetIterator = readCSV(testName, fieldValue.getText());
                dataSet = buildDataSet(dataSetIterator, fieldValue, ordered);
            }
            
        } catch (IOException e) {
            if (this.ignoreErrors) {
                LOG.debug("Error reading CSV data '" + fieldValue.getText() + "'", e);
                dataSet = new DataSet(e);
            } else {
                throw new TestExecutionException("Error reading CSV data '" + fieldValue.getText() + "': " + e.getLocalizedMessage(), e);
            }
        }
        
        return dataSet;
    }
    
    protected Iterator<List<Object>> readCSV(final String testName, final String text, final Map<String,Class<?>> classObjectsMetadata) throws IOException {
        return new CSVIterator(new StringReader(text), classObjectsMetadata);
   }

    protected Iterator<List<Object>> readCSV(final String testName, final String text) throws IOException {
        return new CSVIterator(new StringReader(text));
    }
    
}
