/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.engine.DataSet;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardContextValues;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.util.ResultSetIterator;
import com.denodo.connect.testing.util.SQLExecutor;

public class QueryProcessor extends AbstractQualifierProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(QueryProcessor.class);
  
    
    private final DataSourceLocator dataSourceLocator;
    
    /**
     * Whether errors are considered errors or not. When they are not considered errors (ignored):
     * - There are not logged with ERROR level, because they could be the expected result of a test, and they just clutter the log.
     * - The exception is not thrown, it is stored in the DataSet for comparing it later with the expected result that can be an exception
     * (qualifier exception) or not.
     */
    protected final boolean ignoreErrors;
    
    /**
     * Whether tracing is supported in the execution of the SQL statements.
     */
    private final boolean supportTracing;
    
    
    public QueryProcessor(final DataSourceLocator dataSourceLocator, final boolean ignoreErrors, final boolean supportTracing) {
        super();
        
        Validate.notNull(dataSourceLocator, "Data source locator cannot be null");
        this.dataSourceLocator = dataSourceLocator;
        this.ignoreErrors = ignoreErrors;
        this.supportTracing = supportTracing;
    }
    
    @Override
    public IDataSet process(final String testName, final FieldValue fieldValue, final TestExecutorContext context) {

        IDataSet dataSet;
        try {
            
            final String dataSourceId = extractDataSource(fieldValue);
            LOG.debug("Data source is: '" + dataSourceId + "'");
            final DataSource dataSource = this.dataSourceLocator.get(dataSourceId);
            
            final boolean traceEnabled = this.supportTracing && context.isExecutionTraceEnabled();
            
            final Iterator<List<Object>> dataSetIterator = execute(testName, dataSource, fieldValue.getText(), traceEnabled);
            final boolean ordered = false; // SQL based data sets are unordered by default
            if(dataSetIterator!=null && ((ResultSetIterator) dataSetIterator).getResultSetMetadata()!=null){
                dataSet = buildDataSet(dataSetIterator, fieldValue, ordered, ((ResultSetIterator) dataSetIterator).getResultSetMetadata());
            }else {
                dataSet = buildDataSet(dataSetIterator, fieldValue, ordered);
            }
        } catch (SQLException e) {
            if (this.ignoreErrors) {
                LOG.debug("Error executing SQL '" + fieldValue.getText() + "'", e);
                dataSet = new DataSet(e);
            } else {
                throw new TestExecutionException("Error executing SQL '" + fieldValue.getText() + "': " + e.getLocalizedMessage(), e);
            }
        }   
        
        return dataSet;
    }

    private static String extractDataSource(final FieldValue fieldValue) {
        
        final String dataSource = extractContextVariable(StandardContextValues.DS, fieldValue);
        if (dataSource == null) {
            throw new TestExecutionException("Missing data source in '" + fieldValue + "'");
        }
        
        return dataSource;
    }
    
    protected Iterator<List<Object>> execute(final String testName, final DataSource dataSource, final String sqlStatement,
            final boolean traceEnabled) throws SQLException {
        
        return SQLExecutor.executeQuery(dataSource, sqlStatement, traceEnabled);
    }

}
