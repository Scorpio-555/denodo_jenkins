/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;

import java.io.IOException;
import java.io.Reader;
import java.io.Serial;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.Configuration;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.VariableUtils;

public class ContextVariables extends HashMap<String, Object> {

    @Serial
    private static final long serialVersionUID = -3124261399204042155L;

    private static final Pattern GLOBAL_VARIABLE_PATTERN = Pattern.compile("#\\{\\s*(.*)\\s*\\}"); 
    private static final int GLOBAL_VARIABLE_GROUP = 1;
    
    // The global configuration for delegation
    private final Configuration configuration;
    
    
    public ContextVariables(final Reader reader, final Configuration configuration) {
        
        super();
        try {
            
            Validate.notNull(reader, "Reader cannot be null.");
            loadVariables(reader);
            
            this.configuration = configuration;
            
        } catch (IOException e) {
            throw new TestExecutionException("Could not load resource as a property list.", e);
        }
    }

    private void loadVariables(final Reader reader) throws IOException {
        
        final ContextVariablesProperties properties = new ContextVariablesProperties();
        properties.load(reader);

        for (final Map.Entry<Object, Object> entry : properties.entrySet()) {
            put((String) entry.getKey(), entry.getValue());
        }
    }

    /**
     * Searches for the variable with the specified key in this variable context.
     * If the key is not found in this variable context, an exception is thrown.
     * <p>
     * If the value of the variable is of the form #{variable}, it searches for
     * the variable on the global configuration.
     */
    @Override
    public Object get(final Object key) {
        
        Validate.notNull(key, "Variable name cannot be null.");
        Object value = super.get(key);
        if (value == null) {
            throw new IllegalArgumentException("Missing configuration parameter '" + key + "'");
        }
        
        final String globalVariable = extractGlobalVariable(value.toString());
        if (globalVariable != null && this.configuration != null) {
            value = this.configuration.get(globalVariable);
        }
        
        return value;
    }
    
    private static String extractGlobalVariable(final String value) {
        return VariableUtils.extractValue(GLOBAL_VARIABLE_PATTERN, GLOBAL_VARIABLE_GROUP, value);
    }
    
    static class ContextVariablesProperties extends Properties {

        @Serial
        private static final long serialVersionUID = -2452350367125131955L;
        
        private static final String MULTI_VALUED_VARIABLE_SIGN = "[]";

        private static final String DOUBLE_MULTI_VALUED_VARIABLE_SIGN = "[][]";

        private final List<String> keys = new ArrayList<>();
        
        @Override
        public synchronized Object put(Object key, Object value) {
            // There could be the same variable with or without sign of multivalued,
            // and we have to leave only the last one (the value of the child)
            StringBuilder sb = new StringBuilder();
            if (((String) key).endsWith(DOUBLE_MULTI_VALUED_VARIABLE_SIGN)) {
                sb.append(((String) key), 0, ((String) key).length()-DOUBLE_MULTI_VALUED_VARIABLE_SIGN.length());
            } else if (((String) key).endsWith(MULTI_VALUED_VARIABLE_SIGN)) {
                sb.append(((String) key), 0, ((String) key).length()-MULTI_VALUED_VARIABLE_SIGN.length());
            } else {
                sb.append(key).append(MULTI_VALUED_VARIABLE_SIGN);
            }
            String possibleKey = sb.toString();
            
            if (this.keys.contains(possibleKey)) {
                // This existing key is from an ancestor. We must delete it and add the new one
                remove(possibleKey);
                this.keys.remove(possibleKey);
            } 
            
            this.keys.add((String) key);
            return super.put(key, value);
        }
        
    }
    
}
