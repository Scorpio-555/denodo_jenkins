/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.datasource.DataSourceLocator;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.util.SQLExecutor;

public class ScriptProcessor extends QueryProcessor {
    
    private final ITestResourceResolver testResourceResolver;
    
    
    public ScriptProcessor(final ITestResourceResolver testResourceResolver, final DataSourceLocator dataSourceLocator,
            final boolean ignoreErrors, final boolean supportTracing) {
        
        super(dataSourceLocator, ignoreErrors, supportTracing);
        
        Validate.notNull(testResourceResolver, "Test resource resolver cannot be null");
        Validate.notNull(dataSourceLocator, "Data source locator cannot be null");
        
        this.testResourceResolver = testResourceResolver;
    }
    
    @Override
    protected Iterator<List<Object>> execute(final String testName, final DataSource dataSource, final String locator, final boolean traceEnabled)
            throws SQLException {
        
        final ITestResource scriptResource = this.testResourceResolver.resolveResource(testName, locator);
        Reader reader = null;
        try {
            
            reader = scriptResource.readFile();
            final String scriptContent = IOUtils.toString(reader);
            return executeScript(dataSource, scriptContent, traceEnabled);
            
        } catch (IOException e) {
            throw new TestExecutionException("Error reading file.", e);
        } finally {
            IOUtils.closeQuietly(reader);
        }
    }
        
    private Iterator<List<Object>> executeScript(final DataSource dataSource, final String sqlScript, final boolean traceEnabled) throws SQLException {
        return SQLExecutor.executeScript(dataSource, sqlScript, false, this.ignoreErrors, traceEnabled);
    }
    
}
