/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.ChildDirectiveCombiner;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;

public class DescriptionDirective extends AbstractDirective {
    
    private static final Logger LOG = LoggerFactory.getLogger(DescriptionDirective.class);
    
    public DescriptionDirective() {
        super(false, new ChildDirectiveCombiner());
    }
    
    @Override
    public String getName() {
        return "DESCRIPTION";
    }

    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {

        LOG.debug("Starting to process directive '" + getName() + "'");
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");
        
        final FieldValue fieldValue = field.getValueWithoutQualifier();
        if (fieldValue != null) {
            context.setDescription(fieldValue.getText());
            LOG.debug("Test description is: " + fieldValue.getText());
        }
    }


}
