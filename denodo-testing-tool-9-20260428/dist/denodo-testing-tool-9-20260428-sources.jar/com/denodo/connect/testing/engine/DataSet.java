/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;

import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Consumer;

import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardSetTypes;
import com.denodo.connect.testing.util.ResultSetIterator;

public class DataSet implements IDataSet {

    private final HeaderReaderIteratorWrapper iterator;
    private boolean ordered;
    private StandardSetTypes setType;
    private List<String> datePatterns = new ArrayList<>();
    private Throwable throwable;
    private boolean complexOrdered;
    private ResultSetMetaData resultSetMetadata;

    public DataSet(final Iterator<List<Object>> iterator) {
        super();
        this.ordered = false;
        this.iterator = new HeaderReaderIteratorWrapper(iterator);
    }

    public DataSet(final Iterator<List<Object>> iterator, final boolean ordered, final StandardSetTypes setType,
        final List<String> datePatterns,
        final boolean complexOrdered) {

        this(iterator);
        this.ordered = ordered;
        this.setType = setType;
        this.datePatterns = datePatterns;
        this.complexOrdered = complexOrdered;

    }

    public DataSet(final Iterator<List<Object>> iterator, final boolean ordered, final StandardSetTypes setType, final List<String> datePatterns,
        final boolean complexOrdered, final ResultSetMetaData resultSetMetadata) {

        this(iterator);
        this.ordered = ordered;
        this.setType = setType;
        this.datePatterns = datePatterns;
        this.complexOrdered = complexOrdered;
        this.resultSetMetadata = resultSetMetadata;
    }

    @SuppressWarnings("unchecked")
    public DataSet(final Throwable throwable) {
        this((Iterator<List<Object>>)(Iterator<?>)Collections.emptyIterator());
        this.throwable = throwable;
    }

    @Override
    public List<String> getHeader() {
        return this.iterator.getHeaders();
    }

    @Override
    public Iterator<List<Object>> getData() {
        return this.iterator;
    }

    @Override
    public String getTrace() {
        return this.iterator.getTrace();
    }

    @Override
    public boolean isOrdered() {
        return this.ordered;
    }

    @Override
    public StandardSetTypes getSetType() {
        return this.setType;
    }

    @Override
    public List<String> getDatePatterns() {
        return this.datePatterns;
    }

    @Override
    public void addDatePattern(final String datePattern) {
        this.datePatterns.add(datePattern);
    }

    @Override
    public boolean isComplexOrdered() {
        return this.complexOrdered;
    }

    @Override
    public Throwable getThrowable() {
        return this.throwable;
    }

    public void setException(final Exception exception) {
        this.throwable = exception;
    }

    @Override
    public int getTotalTuples() {
        return this.iterator.getTotalTuples();
    }

    @Override
    public ResultSetMetaData getResultSetMetadata(){
        return this.resultSetMetadata;
    }

    @Override
    public void close() {
        // We end up all iterations in order for final computations to be made available
        while (this.iterator.hasNext()) {
            this.iterator.next();
        }
    }


    @Override
    public String toString() {

        if (this.throwable != null) {
            return "Exception : " + this.throwable;
        }

        return "Headers: " + this.iterator.getHeaders() + ", ordered: " + this.ordered + ", type: " +  this.setType;
    }



    /*
     * NOTE This class is NOT thread-safe
     */
    private static class HeaderReaderIteratorWrapper implements Iterator<List<Object>> {

        private final Iterator<List<Object>> iterator;
        private final List<String> headers;
        private boolean finished;
        private String trace;
        private int totalTuples;

        HeaderReaderIteratorWrapper(final Iterator<List<Object>> iterator) {

            super();

            this.iterator = iterator;
            this.headers = new ArrayList<>();

            final List<Object> firstRow = (this.iterator.hasNext()) ? this.iterator.next() : null;
            if (firstRow != null) {
                for (final Object item : firstRow) {
                    this.headers.add((item != null) ? item.toString() : "");
                }
            }

            this.finished = false;
            this.trace = null;
            this.totalTuples = 0;

        }

        List<String> getHeaders() {
            return this.headers;
        }


        String getTrace() {
            if (!this.finished) {
                throw new IllegalStateException("Cannot retrieve trace at this time: Iterator has not finished");
            }
            if (this.trace == null && this.iterator instanceof ResultSetIterator) {
                this.trace = ((ResultSetIterator) iterator).getTrace();
            }
            return this.trace;
        }


        int getTotalTuples() {
            if (!this.finished) {
                throw new IllegalStateException("Cannot retrieve total tuples at this time: Iterator has not finished");
            }
            return this.totalTuples;
        }


        @Override
        public void remove() {
            // This is not supported in ResultSetIterator, will throw exception
            this.iterator.remove();
        }

        @Override
        public void forEachRemaining(final Consumer<? super List<Object>> action) {
            this.iterator.forEachRemaining(action);
        }

        @Override
        public boolean hasNext() {
            if (this.finished) {
                return false;
            }
            final boolean result = this.iterator.hasNext();
            if (!result) {
                this.finished = true;
            }
            return result;
        }

        @Override
        public List<Object> next() {
            if (this.finished) {
                throw new NoSuchElementException();
            }
            final List<Object> result = this.iterator.next();
            this.totalTuples++; // .next() will throw an exception if there are no more results
            return result;
        }

    }


}
