/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.engine.TestExecutorResult.TestInformation;
import com.denodo.connect.testing.engine.directive.IDirective;
import com.denodo.connect.testing.engine.directive.TraceDirective;
import com.denodo.connect.testing.exception.TestConfigurationException;
import com.denodo.connect.testing.reporter.ITestReporter;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.testable.ITestable;
import com.denodo.connect.testing.testable.Test;
import com.denodo.connect.testing.testable.TestSequence;
import com.denodo.connect.testing.testable.variables.processor.TestVariablesProcessor;
import com.denodo.connect.testing.util.FailedTests;

public class TestExecutor {
    
    private static final String DIRECTIVE_CONTEXT = "CONTEXT";
    
    private final ITestable testable;
    private final Map<String, IDirective> directives;
    private final ITestReporter reporter;
    private final String locationMetafilePath;
    
    
    public TestExecutor(final ITestable testable, final Map<String, IDirective> directives, final ITestReporter reporter, final String locationMetafilePath) {
        
        Validate.notNull(testable, "Testable cannot be null");
        Validate.notNull(directives, "Directives cannot be null");
        Validate.notNull(reporter, "Reporter cannot be null");
        
        this.testable = testable;
        this.directives = directives;
        this.reporter = reporter;
        this.locationMetafilePath= locationMetafilePath;
        
    }
    
    public boolean execute() {
        String   failedTestsMetafilePath= FailedTests.getMetafileFailedTestsIfExists(this.locationMetafilePath);
        this.reporter.engineStart(this.testable.getResourceName(), failedTestsMetafilePath);
        
        final TestExecutorResult result = execute(this.testable, 0);
        
        String createdMetafilePath=null;
        if(this.locationMetafilePath!=null && !this.locationMetafilePath.isEmpty() ){
            FailedTests.deleteMetafileFailedTests(locationMetafilePath);
            if(!result.getFailedTests().isEmpty()){
                FailedTests.writeFailedFiles(result, locationMetafilePath);
                createdMetafilePath=locationMetafilePath+"/"+FailedTests.DENODO_FAILED_FILES_METAFILE;
            }
        }
        this.reporter.engineEnd(result, createdMetafilePath);
        return result.getOkTests() == result.getTotalTests();

    }

    private TestExecutorResult execute(final ITestable t, final int nestingLevel) {

        if (t instanceof Test) {
            try {
                return execute((Test) t, nestingLevel);
            } catch (TestConfigurationException e){
                ITestResult   testResult = new TestResult(false, "Test FAILED. Error in the Context: " + e.getClass().getName() + ": " + e.getMessage(), e);
                return (new TestExecutorResult(testResult.isOK(), 0, 0,
                    new TestInformation(((Test)t).getName(), t.getResourceName(), testResult.getMessage(),
                        0, testResult.isOK(), 0)));



            }

        } else if (t instanceof TestSequence) {

            return execute((TestSequence) t, nestingLevel);
        }
        
        throw new IllegalArgumentException("ITestable " + t.getClass() + " not supported");
    }

    private TestExecutorResult execute(final TestSequence testSequence, final int nestingLevel) {
        
        this.reporter.sequenceStart(nestingLevel, testSequence.getResourceName());
        final TestExecutorResult result = new TestExecutorResult();
        
        final int childNestingLevel = nestingLevel + 1;
        for (final ITestable child : testSequence.getTestables()) {
            try {
                result.addResults(execute(child, childNestingLevel));
            } catch (TestConfigurationException e){
                ITestResult   testResult = new TestResult(false, "Test FAILED. Error in the Context: " + e.getClass().getName() + ": " + e.getMessage(), e);
                result.addResults(new TestExecutorResult(testResult.isOK(), 0, 0,
                    new TestInformation(((Test)child).getName(), child.getResourceName(), testResult.getMessage(),
                        0, testResult.isOK(), 0)));



            }

        }
        
        this.reporter.sequenceEnd(nestingLevel, testSequence.getResourceName(), result);
        
        return result;
    }

    public TestExecutorResult execute(final Test test, final int nestingLevel) {

        TestVariablesProcessor testVariablesProcessor = new TestVariablesProcessor();
        List<List<TestExecutorContext>> processedTestsContexts = testVariablesProcessor.process(test, this.directives);

        final TestExecutorResult result = new TestExecutorResult();
        if (processedTestsContexts.size() == 1) {
            for (TestExecutorContext processedTest : processedTestsContexts.get(0)) {
                result.addResults(executeTest(test, nestingLevel, processedTest));
            }
        } else {
            //Multithread
            ExecutorService executor = Executors.newFixedThreadPool(processedTestsContexts.size());

            List<CompletableFuture<TestExecutorResult>> futures =
                processedTestsContexts.stream().map(processedTestContext -> {
                        List<TestExecutorContext> threadContextList = List.copyOf(processedTestContext);
                        return CompletableFuture.supplyAsync(() -> {
                            TestExecutorResult partialResult = new TestExecutorResult();
                            Test localtest = copyTest(test);// The Test object is copied to be safely used between threads.
                            for (TestExecutorContext processedExecutor : threadContextList) {
                                partialResult.addResults(executeTest(localtest, nestingLevel, processedExecutor));
                            }
                            return partialResult;
                        }, executor);
                    })
                    .toList();

            List<TestExecutorResult> results =
                futures.stream()
                    .map(CompletableFuture::join)
                    .toList();

            for (TestExecutorResult testExecutorContext : results) {
                result.addResults(testExecutorContext);
            }

        }

        return result;

    }



    private Test copyTest(Test test) {

        Map<String, Field> fieldsByName = new HashMap<>();
        test.getFieldsByName().forEach((k, v) -> {

            List<FieldValue> newListValues = new ArrayList<>();
            v.getValues().forEach((fieldValue1) -> {
                newListValues.add(
                    new FieldValue(fieldValue1.getQualifier(), fieldValue1.getContext(), fieldValue1.getText()));
            });
            Field newContext = new Field(v.getName(), newListValues);
            fieldsByName.put(k, newContext);

        });
        Test newTest = new Test(test.getResourceName(), fieldsByName);
        return newTest;

    }

    private TestExecutorResult executeTest(final Test test, final int nestingLevel, final TestExecutorContext context) {
        
        // enable trace for VQL execution if Trace directive is present in the test file
        final Field traceField = test.getField(TraceDirective.TRACE_DIRECTIVE_FIELD);
        context.setExecutionTraceEnabled(traceField != null);
        
        // Append the suffix name because it may be a test with multivalued properties
        this.reporter.testStart(nestingLevel, test.getResourceName(), test.getName()+context.getSuffixName());
        
        ITestResult testResult;
        try {
            for (final Map.Entry<String, IDirective> entry : this.directives.entrySet()) {
                if (entry.getKey().compareTo(DIRECTIVE_CONTEXT) != 0) { // It is processed in TestVariablesProcessor
                    final String directiveName = entry.getKey();
                    final IDirective directive = entry.getValue();
                    final Field directiveField = test.getField(directiveName);
                    if (directiveField != null) {
                        directive.process(test.getResourceName(), directiveField, context);
                    }
                }
            }
            
            testResult = context.getTestResult();
        } catch (Throwable t) {
            testResult = new TestResult(false, "Test FAILED. Test raised an unexpected " + t.getClass().getName() + ": " + t.getMessage(), t);
        } finally {
            try {
                context.close();
            } catch (Throwable t) { /* ignored */ }
        }


        this.reporter.testEnd(nestingLevel, test.getResourceName(), context.getName(), context.getDescription(), testResult,
                context.getExecutionTimeNanos(), context.getTotalTuples());
        
        if (testResult == null) {
            return new TestExecutorResult();
        }
        
        // At this point context.getTotalTuples() should be not null because it is null when testResult is null
        int totalTuples = context.getTotalTuples() != null ? context.getTotalTuples() : 0;
        
        return new TestExecutorResult(testResult.isOK(), context.getExecutionTimeNanos(), totalTuples,
            new TestInformation(context.getName(), test.getResourceName(), testResult.getMessage(),
                context.getExecutionTimeNanos(), testResult.isOK(), totalTuples));
    }
    
}
