/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine;

import org.apache.commons.lang.StringUtils;


public class TestExecutorContext {

    private String name;
    private String description;
    private ContextVariables contextVariables;
    private IDataSet actualDataSet;
    private IDataSet expectedDataSet;
    private long executionTimeNanos;
    private ITestResult testResult;
    private boolean executionTraceEnabled;

    private String suffixName = StringUtils.EMPTY;
    
    private static final String MULTIPLE_TEST_NAME = "MultiTest";
    
    public TestExecutorContext() {
        super();
    }

    public String getName() {
        if (this.name == null && !this.suffixName.isEmpty()) {
            return MULTIPLE_TEST_NAME
                + this.suffixName;
        }
        
        return this.name;
    }

    public void setName(final String name) {
        this.name = name + this.suffixName;
    }

    public String getSuffixName() {
        return this.suffixName;
    }

    public void setSuffixName(String suffix) {
        this.suffixName = suffix;
    }
    
    public String getDescription() {
        return this.description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public ContextVariables getContextVariables() {
        return this.contextVariables;
    }

    public void setContextVariables(final ContextVariables contextVariables) {
        this.contextVariables = contextVariables;
    }

    public IDataSet getActualDataSet() {
        return this.actualDataSet;
    }

    public IDataSet getExpectedDataSet() {
        return this.expectedDataSet;
    }
    
    public String getActualTrace() {
        return this.actualDataSet.getTrace();
    }

    public void setActualDataSet(final IDataSet actualDataSet) {
        this.actualDataSet = actualDataSet;
    }

    public void setExpectedDataSet(final IDataSet expectedDataSet) {
        this.expectedDataSet = expectedDataSet;
    }

    public long getExecutionTimeNanos() {
        return this.executionTimeNanos;
    }

    public void setExecutionTimeNanos(final long executionTimeNanos) {
        this.executionTimeNanos = executionTimeNanos;
    }

    public ITestResult getTestResult() {
        return this.testResult;
    }

    public void setTestResult(final ITestResult testResult) {
        this.testResult = testResult;
    }
    
    public void addTraceResult(final ITestResult traceResult) {
        
        final boolean ok = this.testResult.isOK() && traceResult.isOK();
        String message = this.testResult.getMessage();
        if (traceResult.hasMessage()) {
            message += '\n' + traceResult.getMessage();
        }
        this.testResult = new TestResult(ok, message, this.testResult.getThrowable());
    }

    public boolean isExecutionTraceEnabled() {
        return this.executionTraceEnabled;
    }

    public void setExecutionTraceEnabled(final boolean traceMode) {
        this.executionTraceEnabled = traceMode;
    }

    public Integer getTotalTuples() {
        return this.actualDataSet != null ? this.actualDataSet.getTotalTuples() : null;
    }

    public void close() {
        if (this.actualDataSet != null) {
            this.actualDataSet.close();
        }

        if (this.expectedDataSet != null) {
            this.expectedDataSet.close();
        }
    }

}
