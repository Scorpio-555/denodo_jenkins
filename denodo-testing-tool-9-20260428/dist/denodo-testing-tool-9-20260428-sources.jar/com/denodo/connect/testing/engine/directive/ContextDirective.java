/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.directive;

import java.io.StringReader;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.Configuration;
import com.denodo.connect.testing.engine.ContextVariables;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.combiner.AddValuesCombiner;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;

public class ContextDirective extends AbstractDirective {

    private static final Logger LOG = LoggerFactory.getLogger(ContextDirective.class);
    
    private final Configuration configuration;
    
    public ContextDirective(final Configuration configuration) {
        
        super(false, new AddValuesCombiner());

        Validate.notNull(configuration, "Configuration cannot be null");
        this.configuration = configuration;
    }

    @Override
    public String getName() {
        return "CONTEXT";
    }

    @Override
    public void doProcess(final String testName, final Field field, final TestExecutorContext context) {
     
        LOG.debug("Starting to process directive '" + getName() + "'");
        
        Validate.notNull(field, "Field " + getName() + " cannot be null");
        
        final List<FieldValue> fieldValues = field.getValuesWithoutQualifier();
        final String propertyList = join(fieldValues);
        if (StringUtils.isNotBlank(propertyList)) {
            final StringReader reader = new StringReader(propertyList);
            try {
                final ContextVariables contextVariables = new ContextVariables(reader, this.configuration);
                context.setContextVariables(contextVariables);
                LOG.debug("Test context variables are: " + contextVariables);
            } catch (Exception e) {
                throw new TestExecutionException("Could not load '" + getName() + "' directive as a property list.", e);
            }
        }
    }
    
    private static String join(final List<FieldValue> fieldValues) {
        
        final StringBuilder sb = new StringBuilder();
        for (final FieldValue fieldValue : fieldValues) {
            sb.append(fieldValue.getText()).append('\n');
        }
        
        return sb.toString();
    }
    
}
