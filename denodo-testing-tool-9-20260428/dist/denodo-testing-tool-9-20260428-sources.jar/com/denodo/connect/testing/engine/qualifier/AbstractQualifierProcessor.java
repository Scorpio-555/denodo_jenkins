/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.sql.ResultSetMetaData;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.BooleanUtils;

import com.denodo.connect.testing.engine.DataSet;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardContextValues;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardSetTypes;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.util.VariableUtils;

public abstract class AbstractQualifierProcessor implements IQualifierProcessor {

    
    protected static IDataSet buildDataSet(final Iterator<List<Object>> dataSetIterator, final FieldValue fieldValue, final boolean orderedByDefault) {
        
        IDataSet dataSet = null;
        if (dataSetIterator != null) {
            final boolean ordered = extractOrderCondition(fieldValue, orderedByDefault);
            final StandardSetTypes setType = extractSetType(fieldValue);
            final List<String> datePatterns = extractDatePatterns(fieldValue);
            final boolean complexOrdered = extractComplexOrderCondition(fieldValue);
            dataSet = new DataSet(dataSetIterator, ordered, setType, datePatterns, complexOrdered);
        }
        
        return dataSet;
    }

    protected static IDataSet buildDataSet(final Iterator<List<Object>> dataSetIterator, final FieldValue fieldValue, final boolean orderedByDefault, final ResultSetMetaData resulSetMetadata) {

        IDataSet dataSet = null;
        if (dataSetIterator != null) {
            final boolean ordered = extractOrderCondition(fieldValue, orderedByDefault);
            final StandardSetTypes setType = extractSetType(fieldValue);
            final List<String> datePatterns = extractDatePatterns(fieldValue);
            final boolean complexOrdered = extractComplexOrderCondition(fieldValue);
            dataSet = new DataSet(dataSetIterator, ordered, setType, datePatterns, complexOrdered, resulSetMetadata);
        }

        return dataSet;
    }

    protected static String extractContextVariable(final StandardContextValues contextVariable, final FieldValue fieldValue) {
        return VariableUtils.extractContextVariable(contextVariable.lowerCase(), fieldValue.getContext());
    }

    private static boolean extractOrderCondition(final FieldValue fieldValue, final boolean orderedByDefault) {
        
        boolean ordered = orderedByDefault;
        final String orderedAsString = extractContextVariable(StandardContextValues.ORDERED, fieldValue);
        if (orderedAsString != null) {
            ordered = BooleanUtils.toBoolean(orderedAsString);
        }
        
        return ordered;
    }
    
    private static StandardSetTypes extractSetType(final FieldValue fieldValue) {
        
        StandardSetTypes setType = StandardSetTypes.FULL;
        
        final String setTypeAsString = extractContextVariable(StandardContextValues.TYPE, fieldValue);        
        if (setTypeAsString != null) {
            setType = StandardSetTypes.valueOf(setTypeAsString.toUpperCase());
        }
        
        return setType;
    }
    
    private static List<String> extractDatePatterns(FieldValue fieldValue) {
        return VariableUtils.extractContextVariables(StandardContextValues.DATEPATTERN.lowerCase(), fieldValue.getContext());
        
    }
    
    private static boolean extractComplexOrderCondition(final FieldValue fieldValue) {
        
        boolean complexOrdered = true; //Default value
        final String complexOrderedAsString = extractContextVariable(StandardContextValues.COMPLEX_ORDERED, fieldValue);
        if (complexOrderedAsString != null) {
            complexOrdered = BooleanUtils.toBoolean(complexOrderedAsString);
        }
        
        return complexOrdered;
    }
}
