/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.engine.qualifier;

import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.resolver.ITestResourceResolver;
import com.denodo.connect.testing.util.CSVIterator;

public class CSVFileProcessor extends CSVProcessor {
    
    
    private final ITestResourceResolver testResourceResolver;
    

    public CSVFileProcessor(final ITestResourceResolver testResourceResolver, final boolean ignoreErrors) {
        super(ignoreErrors);
        
        Validate.notNull(testResourceResolver, "Test resource resolver cannot be null");
        
        this.testResourceResolver = testResourceResolver;
    }
    
    @Override
    protected Iterator<List<Object>> readCSV(final String testName, final String locator) throws IOException {

        final ITestResource scriptResource = this.testResourceResolver.resolveResource(testName, locator);
        final Reader reader = scriptResource.readFile();
        return new CSVIterator(reader);
    }

    @Override
    protected Iterator<List<Object>> readCSV(final String testName, final String locator,  Map<String,Class<?>> classObjectsMetadata) throws IOException {

        final ITestResource scriptResource = this.testResourceResolver.resolveResource(testName, locator);
        final Reader reader = scriptResource.readFile();
        return new CSVIterator(reader, classObjectsMetadata);
    }

}
