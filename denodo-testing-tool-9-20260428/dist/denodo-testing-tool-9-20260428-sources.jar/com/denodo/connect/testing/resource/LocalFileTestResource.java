/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.resource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;
import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.exception.TestExecutionException;

public class LocalFileTestResource implements ITestResource {
    
    private static final String TEST_FILE_SUFFIX = ".denodotest";
    private static final String TEST_INDEX_FILE_SUFFIX = ".denodoidx";
    
    private static final ByteOrderMark[] BOMS = new ByteOrderMark[] { ByteOrderMark.UTF_8, ByteOrderMark.UTF_16BE, ByteOrderMark.UTF_16LE,
            ByteOrderMark.UTF_32BE, ByteOrderMark.UTF_32LE };
    
    
    private final File resourceFile;
    private final String name;
    private final String characterEncoding;
    
    public LocalFileTestResource(final File resourceFile, final String characterEncoding) {
        
        super();
        Validate.notNull(resourceFile, "Resource file cannot be null.");
        
        if (!resourceFile.exists()) {
            throw new TestExecutionException("The file: " + resourceFile.getPath() + " does not exist.");
        }
        
        this.resourceFile = resourceFile.getAbsoluteFile();
        try {
            this.name = resourceFile.getCanonicalPath();
        } catch (IOException e) {
            throw new TestExecutionException("Error getting canonical path from file.", e);
        }
        this.characterEncoding = characterEncoding;
    }

    public File getResourceFile() {
        return this.resourceFile;
    }

    @Override
    public String getName() {
        return this.name;
    }
    
    public String getCharacterEncoding() {
        return this.characterEncoding;
    }
    
    @Override
    public boolean isDirectory() {
        return this.resourceFile.isDirectory();
    }
    
    @Override
    public boolean isIndex() {
        return getName().toLowerCase().endsWith(TEST_INDEX_FILE_SUFFIX);
    }
    
    @Override
    public void checkValid() {
        
        if (!getName().toLowerCase().endsWith(TEST_FILE_SUFFIX) && !isIndex()) {
            throw new IllegalArgumentException("'" + getName() + "' is not a valid test resource. Test files should have the '"
                    + TEST_FILE_SUFFIX + "' extension and test index files should have the '" + TEST_INDEX_FILE_SUFFIX + "' extension.");
        }
    }

    @Override
    public List<ITestResource> getContents() {
        throw new TestExecutionException("The resource '" + this.name + "' is not a directory. A file has no contents.");
    }

    @Override
    public ITestResource locateRelative(final String relativeLocator) {
        
        File relativeFile = new File(relativeLocator);
        if (!relativeFile.isAbsolute()) {
            relativeFile = new File(this.resourceFile.getParentFile(), relativeLocator);
        }
        if (relativeFile.isDirectory()) {
            return new LocalFolderTestResource(relativeFile, this.characterEncoding);
        }
        return new LocalFileTestResource(relativeFile, this.characterEncoding);
    }

    @Override
    public Reader readFile() {
        Reader reader;
        try {
            // These readers will be close by parsers.
            // Use BOMInputStream to ignore BOM of for example VQL scripts exported by VDP
            final InputStream fis = new BOMInputStream(new FileInputStream(this.resourceFile), BOMS);
            final InputStreamReader isr = new InputStreamReader(fis, this.characterEncoding);
            reader = new BufferedReader(isr);
            
        } catch (final FileNotFoundException | UnsupportedEncodingException e) {
            throw new TestExecutionException("Error creating Reader from file '" + this.name + "' using encoding '"
                + this.characterEncoding + "'", e);
        }

        return reader;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        LocalFileTestResource other = (LocalFileTestResource) obj;
        if (this.name == null) {
            return other.name == null;
        } else {
            return this.name.equals(other.name);
        }
    }
    
}