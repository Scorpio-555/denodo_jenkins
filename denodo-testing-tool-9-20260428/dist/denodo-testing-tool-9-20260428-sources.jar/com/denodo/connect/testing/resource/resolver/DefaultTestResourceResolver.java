/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.resource.resolver;

import static com.denodo.connect.testing.resource.resolver.ClasspathTestResourceResolver.CLASSPATH_RESOURCE_PREFIX;
import static com.denodo.connect.testing.resource.resolver.FileSystemTestResourceResolver.FILE_RESOURCE_PREFIX;

import java.util.HashMap;
import java.util.Map;

import com.denodo.connect.testing.resource.ITestResource;

public class DefaultTestResourceResolver implements ITestResourceResolver {

    
    private final String characterEncoding;
    private final Map<String, ITestResourceResolver> resourceResolversByPrefix;
    
    public DefaultTestResourceResolver(final String characterEncoding) {
        this.characterEncoding = characterEncoding;
        this.resourceResolversByPrefix = new HashMap<>();
    }
    
    @Override
    public ITestResource resolveResource(final String locator) {
        
        ITestResourceResolver resolver = getTestResourceResolver(locator);
        return resolver.resolveResource(locator);
    }
    
    @Override
    public ITestResource resolveResource(final String parent, final String locator) {
        
        ITestResourceResolver resolver = getTestResourceResolver(locator);
        return resolver.resolveResource(parent, locator);
    }

    private ITestResourceResolver getTestResourceResolver(final String locator) {
        
        ITestResourceResolver resolver;
        if (locator.startsWith(CLASSPATH_RESOURCE_PREFIX)) {
            resolver = this.resourceResolversByPrefix.get(CLASSPATH_RESOURCE_PREFIX);
            if (resolver == null) {
                resolver = new ClasspathTestResourceResolver(this.characterEncoding);
                this.resourceResolversByPrefix.put(CLASSPATH_RESOURCE_PREFIX, resolver);
            }
        } else { // File is the default resource resolver
            resolver = this.resourceResolversByPrefix.get(FILE_RESOURCE_PREFIX);
            if (resolver == null) {
                resolver = new FileSystemTestResourceResolver(this.characterEncoding);
                this.resourceResolversByPrefix.put(FILE_RESOURCE_PREFIX, resolver);
            }
        }
        return resolver;
    }
    

}
