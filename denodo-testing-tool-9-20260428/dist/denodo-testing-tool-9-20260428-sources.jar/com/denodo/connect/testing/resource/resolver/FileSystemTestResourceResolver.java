/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.resource.resolver;

import java.io.File;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.LocalFileTestResource;
import com.denodo.connect.testing.resource.LocalFolderTestResource;

public class FileSystemTestResourceResolver implements ITestResourceResolver {

    public static final String FILE_RESOURCE_PREFIX = "file:";
    
    private final String characterEncoding;
    
    public FileSystemTestResourceResolver(final String characterEncoding) {
        super();
        Validate.notNull(characterEncoding, "Character encoding cannot be null.");
        this.characterEncoding = characterEncoding;
    }

    public String getCharacterEncoding() {
        return this.characterEncoding;
    }

    @Override
    public ITestResource resolveResource(final String locator) {

        Validate.notNull(locator, "Resource locator cannot be null.");
        
        String resourceName = locator;
        if (locator.startsWith(FILE_RESOURCE_PREFIX)) {
            resourceName = locator.substring(FILE_RESOURCE_PREFIX.length());
        }
        
        final File resourceFile = new File(resourceName);
        if (resourceFile.isDirectory()) {
            return new LocalFolderTestResource(resourceFile, this.characterEncoding);
        }
        return new LocalFileTestResource(resourceFile, this.characterEncoding);
        
    }
    
    @Override
    public ITestResource resolveResource(final String parent, final String locator) {
        
        Validate.notNull(parent, "Parent resource locator cannot be null.");
        Validate.notNull(locator, "Resource locator cannot be null.");
        
        String resourceName = locator;
        if (locator.startsWith(FILE_RESOURCE_PREFIX)) {
            resourceName = locator.substring(FILE_RESOURCE_PREFIX.length());
        }
        
        File resourceFile = new File(resourceName);
        if (!resourceFile.exists()) { // try to resolve locator as a relative resource to the parent path
            final File parentFile = new File(parent);
            resourceFile = new File(parentFile.getParent(), resourceName);
        }
        
        if (resourceFile.isDirectory()) {
            return new LocalFolderTestResource(resourceFile, this.characterEncoding);
        }
        return new LocalFileTestResource(resourceFile, this.characterEncoding);
        
    }

}