/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.resource.resolver;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.LocalFileTestResource;
import com.denodo.connect.testing.resource.LocalFolderTestResource;
import com.denodo.connect.testing.util.ClassLoaderUtils;

public class ClasspathTestResourceResolver implements ITestResourceResolver {
    
    public static final String CLASSPATH_RESOURCE_PREFIX = "classpath:";
    
    private final String characterEncoding;
    
    public ClasspathTestResourceResolver(final String characterEncoding) {
        super();
        Validate.notNull(characterEncoding, "Character encoding cannot be null.");
        this.characterEncoding = characterEncoding;
    }

    public String getCharacterEncoding() {
        return this.characterEncoding;
    }

    @Override
    public ITestResource resolveResource(final String locator) {

        Validate.notNull(locator, "Resource locator cannot be null.");
        
        final String resourceName;
        if (locator.startsWith(CLASSPATH_RESOURCE_PREFIX)) {
            resourceName = locator.substring(CLASSPATH_RESOURCE_PREFIX.length());
        } else {
            throw new TestExecutionException("Resource name '" + locator + "' has no recognized prefix, and it has not been declared as relative.");
        }
        
        final ClassLoader cl = ClassLoaderUtils.getClassLoader(ClasspathTestResourceResolver.class);
        
        final URL resourceURL = cl.getResource(resourceName);
        if (resourceURL == null) {
            throw new TestExecutionException("Error while reading classpath resource '" + resourceName + "'. " +
                    "Could not obtain resource as URL.");
        }
        
        try {
            
            final File resourceFile = new File(resourceURL.toURI());
            if (resourceFile.isDirectory()) {
                return new LocalFolderTestResource(resourceFile, this.characterEncoding);
            }
            return new LocalFileTestResource(resourceFile, this.characterEncoding);
            
        } catch (final URISyntaxException e) {
            throw new TestExecutionException("Error getting resource URI.", e); 
        }
        
    }
    
    @Override
    public ITestResource resolveResource(final String parent, final String locator) {
        
        Validate.notNull(locator, "Resource locator cannot be null.");
        
        final String resourceName;
        if (locator.startsWith(CLASSPATH_RESOURCE_PREFIX)) {
            resourceName = locator.substring(CLASSPATH_RESOURCE_PREFIX.length());
        } else {
            throw new TestExecutionException("Resource name '" + locator + "' has no recognized prefix, and it has not been declared as relative.");
        }
        
        final ClassLoader cl = ClassLoaderUtils.getClassLoader(ClasspathTestResourceResolver.class);
        
        URL resourceURL = cl.getResource(resourceName);
        File resourceFile;
        if (resourceURL != null) {
            try {
   
                resourceFile = new File(resourceURL.toURI());
                
            } catch (final URISyntaxException e) {
                throw new TestExecutionException("Error getting resource URI.", e); 
            }
            
        } else {
            final File resourceParent = new File(parent);
            resourceFile = new File(resourceParent.getParent(), resourceName);
        }
        
        if (resourceFile.isDirectory()) {
            return new LocalFolderTestResource(resourceFile, this.characterEncoding);
        }
        return new LocalFileTestResource(resourceFile, this.characterEncoding);
        
        
    }
    


}