/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.resource;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.exception.TestExecutionException;

public class LocalFolderTestResource implements ITestResource {

    
    /*
     * This test file contains the SETUP directive and should be executed only once, at the beginning, for all the tests in the folder
     * it is contained. 
     */
    public static final String FIRST_TEST_FILENAME = "first.denodotest";
    
    /*
     * This test file contains the TEARDOWN directive and should be executed only once, at the end, for all the tests in the folder
     * it is contained. 
     */
    public static final String LAST_TEST_FILENAME = "last.denodotest";
    
    private final File resourceFile;
    private final String name;
    private final String characterEncoding;
    
    public LocalFolderTestResource(final File resourceFile, final String characterEncoding) {
        
        super();
        Validate.notNull(resourceFile, "Resource file cannot be null");
        
        if (!resourceFile.exists()) {
            throw new TestExecutionException("The folder: " + resourceFile.getPath() + " does not exist.");
        }
        
        this.resourceFile = resourceFile.getAbsoluteFile();
        try {
            this.name = resourceFile.getCanonicalPath();
        } catch (IOException e) {
            throw new TestExecutionException("Error getting canonical path from file.", e);
        }
        this.characterEncoding = characterEncoding;
    }

    public File getResourceFile() {
        return this.resourceFile;
    }
    
    @Override
    public String getName() {
        return this.name;
    }

    public String getCharacterEncoding() {
        return this.characterEncoding;
    }
    
    @Override
    public boolean isDirectory() {
        return this.resourceFile.isDirectory();
    }
    
    @Override
    public boolean isIndex() {
        return false;
    }
    
    @Override
    public void checkValid() {
        // nothing to do: folders are always valid test resources
    }

    @Override
    public List<ITestResource> getContents() {
        final List<ITestResource> containedResources = new ArrayList<>();
        final File[] fileList = this.resourceFile.listFiles();
        if (fileList == null) {
            throw new IllegalStateException("List of files returned as null for resource: " + this.resourceFile.getName());
        }
        sort(fileList);
        for (final File containedFile : fileList) {
            final ITestResource containedResource = (containedFile.isDirectory() ? 
                                                        new LocalFolderTestResource(containedFile, this.characterEncoding) : 
                                                        new LocalFileTestResource(containedFile, this.characterEncoding));
            containedResources.add(containedResource);
        }
        return Collections.unmodifiableList(containedResources);
        
    }
    
    /*
     * Sorts files: first.denodotest, if present, should be the first test in the list and last.denodotest, if present, should be the 
     * last test in the list.
     */
    private static void sort(final File[] files) {
        
        Arrays.sort(files, (f1, f2) -> {
            if (FIRST_TEST_FILENAME.equals(f1.getName())) {
                return -1;
            }
            if (FIRST_TEST_FILENAME.equals(f2.getName())) {
                return 1;
            }
            if (LAST_TEST_FILENAME.equals(f1.getName())) {
                return 1;
            }
            if (LAST_TEST_FILENAME.equals(f2.getName())) {
                return -1;
            }

            return f1.compareTo(f2);
        });
    }

    @Override
    public ITestResource locateRelative(final String relativeLocator) {
        
        File relativeFile = new File(relativeLocator);
        if (!relativeFile.isAbsolute()) {
            relativeFile = new File(this.resourceFile.getParentFile(), relativeLocator);
        }
        if (relativeFile.isDirectory()) {
            return new LocalFolderTestResource(relativeFile, this.characterEncoding);
        }
        return new LocalFileTestResource(relativeFile, this.characterEncoding);
    }

    @Override
    public Reader readFile() {
        throw new TestExecutionException("The resource '" + this.name + "' is a directory. A directory cannot be read it.");
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        LocalFolderTestResource other = (LocalFolderTestResource) obj;
        if (this.name == null) {
            return other.name == null;
        } else {
            return this.name.equals(other.name);
        }
    }

}