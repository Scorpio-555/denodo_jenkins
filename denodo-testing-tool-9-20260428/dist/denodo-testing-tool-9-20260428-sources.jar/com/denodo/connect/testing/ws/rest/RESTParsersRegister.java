/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;


import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RESTParsersRegister {

    /**
     * REST Web services in VDP use the content type application/octet-stream unless the user specifies another content type:
     * either a constant (e.g., application/pdf) or an expression.
     * <p>
     * As we are unable to know which content type the user has configured for each blob field, we consider the BinaryParser as the default one.
     */
    private static final IRESTParser DEFAULT_PARSER = new BinaryParser();
    
    private final Map<String, IRESTParser> restParserByContentType;
    
    /**
     * Maps content types to a "canonical" one that is the one associated with the IRESTParser.
     * For example, XMLParser parses documents with content type: "application/xml" (which is what VDP uses, and is
     * the recommended one for web service responses).
     * This map generalizes parsers to accept many other XML-ish MIME types like "text/xml".
     */
    private final Map<String, List<String>> compatibleContentTypes;
    
    
    public RESTParsersRegister() {
        
        this.restParserByContentType = new HashMap<>();
        this.compatibleContentTypes = new HashMap<>();
        
        register(new HTMLParser(), List.of("application/xhtml+xml"));
        register(new JSONParser(), Arrays.asList("text/json", "text/javascript"));
        register(new RSSParser(), List.of("application/rss+xml"));
        register(new XMLParser(), List.of("text/xml"));
        register(new MultipartParser(), Collections.emptyList());
        register(DEFAULT_PARSER, List.of("application/binary"));
        
    }

    private void register(final IRESTParser restParser, final List<String> compatContentTypes) {
        this.restParserByContentType.put(restParser.getContentType(), restParser);
        this.compatibleContentTypes.put(restParser.getContentType(), compatContentTypes);
    }

    public IRESTParser get(final String contentType) {
        
        final String normalizedContentType = normalize(contentType);
        
        for (final Map.Entry<String, IRESTParser> entry : this.restParserByContentType.entrySet()) {
            final String parserContentType = entry.getKey();
            if (parserContentType.equals(normalizedContentType)) {
                return entry.getValue();
            }
        }
            
        return DEFAULT_PARSER;
    }

    private String normalize(final String contentType) {
        
        for (final Map.Entry<String, List<String>> entry : this.compatibleContentTypes.entrySet()) {
            final String canonicalContentType = entry.getKey();
            if (contentType.contains(canonicalContentType)) { // contains(), not equals(), because content types can be of the form: "text/plain; charset=xxx"
                return canonicalContentType;
            }
            
            for (final String compatibleContentType : entry.getValue()) {
                if (contentType.contains(compatibleContentType)) {
                    return canonicalContentType;
                }
            }
        }
        
        return DEFAULT_PARSER.getContentType();
    }

}
