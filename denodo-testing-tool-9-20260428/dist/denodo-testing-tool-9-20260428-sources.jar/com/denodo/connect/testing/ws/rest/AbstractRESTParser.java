/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public abstract class AbstractRESTParser implements IRESTParser {

    
    private static final String SELECT_PARAMETER  = "$select";
    private static final String PARAMETERS_SEPARATOR  = "&";
    
    /**
     * Parses the $SELECT parameter from the URI and return the projected fields names.
     */
    protected static List<Object> getHeaderFromSelectParameter(final String uri) {
        
        final List<Object> header = new ArrayList<>();
        
        final int paramStartIndex = uri.indexOf(SELECT_PARAMETER);
        if (paramStartIndex != -1) {
            int paramEndIndex = uri.indexOf(PARAMETERS_SEPARATOR, paramStartIndex);
            if (paramEndIndex == -1) {
                paramEndIndex = uri.length();
            }
            final String parameter = uri.substring(paramStartIndex + 1 + SELECT_PARAMETER.length(), paramEndIndex);
            final String[] fields = parameter.split(",");
            Collections.addAll(header, fields);
        }
        
        return header;
    }

}
