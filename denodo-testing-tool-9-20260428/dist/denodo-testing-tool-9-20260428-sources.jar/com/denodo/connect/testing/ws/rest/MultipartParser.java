/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.apache.commons.fileupload.MultipartStream;
import org.apache.http.entity.ContentType;
import org.apache.http.protocol.HTTP;

import com.denodo.connect.testing.util.BlobUtils;

public class MultipartParser extends AbstractRESTParser {
    

    /**
     * The length of the buffer used for processing a request.
     */
    private static final int BUFSIZE = 4096;
    
    /**
     * Example of header with boundary parameter: "multipart/mixed; boundary=Boundary_7_1683511982_1423572279009"
     */
    private static final String BOUNDARY = "boundary=";
    
    /**
     * Content-ID is a unique identifier for a message part, allowing it to be referred to it by cid url.
     * Example: Content-Id: 70696374757265
     */
    private static final String CONTENT_ID = "Content-Id:";
    
    /**
     * cid refers to another message part in the same message.
     * Example. "picture":"cid:70696374757265"
     */
    private static final String CID = "cid:";
    
    
    public MultipartParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return "multipart/mixed";
    }

    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) throws IOException {
        
        final Map<String, Iterator<List<Object>>> messageParts = new LinkedHashMap<>();

        final String boundary = getValue(response.getHeaders(), BOUNDARY);
        final MultipartStream multipartStream = new MultipartStream(response.getContent(), boundary.getBytes(
            StandardCharsets.UTF_8), BUFSIZE, null);

        boolean nextPart = multipartStream.skipPreamble();
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        while (nextPart) {
            final String partHeaders = multipartStream.readHeaders();
            multipartStream.readBodyData(output);
            final IRESTParser restParser = client.getResponseParser(partHeaders);
            final RESTResponse partResponse = new RESTResponse(response.getURI(), partHeaders, getCharset(partHeaders),
                    new ByteArrayInputStream(output.toByteArray()));
            final Iterator<List<Object>> messagePart = restParser.parse(client, partResponse);
            messageParts.put(partHeaders, messagePart);

            nextPart = multipartStream.readBoundary();
            output.reset();
        }

        final List<List<Object>> assembledMessage = assembleMessage(messageParts);
        return assembledMessage.iterator();

        
    }

    private static String getValue(final String input, final String parameterName) {
        
        String boundary = null;
        final int boundaryIndex = input.indexOf(parameterName);
        if (boundaryIndex != -1) {
            boundary = input.substring(boundaryIndex + parameterName.length()).trim();
        }
        
        return boundary;
    }
    
    private static List<List<Object>> assembleMessage(final Map<String, Iterator<List<Object>>> messageParts) {
        
        final List<List<Object>> assembledMessage = new ArrayList<>();
        
        final Iterator<List<Object>> mainMessage = findMainMessage(messageParts);
        if (mainMessage != null) {
            while (mainMessage.hasNext()) {
                final List<Object> elements = mainMessage.next();
                resolveReferences(elements, messageParts);
                assembledMessage.add(elements);
            }
        }
        
        return assembledMessage;
        
    }
    
    /**
     * If the VDP view has a field of type blob, the REST response will be a multipart message:
     *  - The first part of the message, main message, will be the JSON or XML document with the data.
     *  - The following parts contain the value of each blob field, encoded in base64.
     */
    private static Iterator<List<Object>> findMainMessage(final Map<String, Iterator<List<Object>>> messageParts) {
        
        for (final Map.Entry<String, Iterator<List<Object>>> messagePart : messageParts.entrySet()) {
            final String messageHeaders = messagePart.getKey();
            if (isMainMessage(messageHeaders)) {
                return messagePart.getValue();
            }
        }
        
        return null;
    }
    
    private static boolean isMainMessage(final String headers) {
        return !headers.contains(CONTENT_ID);
    }
    
    /**
     * Resolve references like "cid:70696374757265" with the message identified by the cid value in its Content-ID header.
     */
    private static void resolveReferences(final List<Object> elements, final Map<String, Iterator<List<Object>>> messageParts) {
        
        for (final ListIterator<Object> it = elements.listIterator(); it.hasNext();) {
            final Object element = it.next();
            if (element != null) {
                final String referenceID = getValue(element.toString(), CID);
                if (referenceID != null) {
                    final Object referencedContent = findReferencedContent(referenceID, messageParts);
                    if (referencedContent != null) {
                        it.set(referencedContent);
                    }
                }
            }
        }
    }
        
    /**
     * Referenced content is a blob field.
     */
    private static Object findReferencedContent(final String contentID, final Map<String, Iterator<List<Object>>> messageParts) {
     
        for (final Map.Entry<String, Iterator<List<Object>>> messagePart : messageParts.entrySet()) {
            final String messageHeaders = messagePart.getKey();
            final String messageContentID = getValue(messageHeaders, CONTENT_ID);
            if (contentID.equals(messageContentID)) {
                return BlobUtils.findBlobContent(messagePart.getValue());
            }
        }

        return null;
    }

    private static Charset getCharset(final String headers) throws UnsupportedEncodingException {
        
        Charset charset;
        try {
            final ContentType contentType = ContentType.parse(headers);
            charset = contentType.getCharset();
        } catch (final UnsupportedCharsetException ex) {
            throw new UnsupportedEncodingException(ex.getMessage());
        }

        if (charset == null) {
            charset = HTTP.DEF_CONTENT_CHARSET;
        }
        
        return charset;
    }

}
