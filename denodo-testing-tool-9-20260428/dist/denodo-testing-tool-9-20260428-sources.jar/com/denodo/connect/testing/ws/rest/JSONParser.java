/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.BlobUtils;
import com.denodo.connect.testing.util.TextualData;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

/**
 * Transforms JSON data in the corresponding Java objects.
 * <p>
 * Each VDP row is transformed in a List<Object>.
 * A VDP view (a collection of rows) is transformed in a List of List<Object>.
 * <p>
 * Each field is transformed depending on its type:
 *  - Primitive types to TextualData, as REST responses do not have metadata information.
 *  - Array types to List.
 *  - Record types to Object[].
 */
public class JSONParser extends AbstractRESTParser {


    /**
     * Name of the JSON element that contains the results when the web service returns a collection.
     */
    private static final String ELEMENTS_NAME = "elements";
    
    /**
     * JSON results could include in each row a link to the row itself and, for each association of the view, a link to traverse the association.
     * These links are grouped in an element named "links" that the parser will skip as they are not relevant for tests results.
     */
    private static final String JSON_RESTFUL_LINKS_NAME = "links";

    private static final String MULTIPART_MIXED_BLOB_TYPE = "multipart/mixed";
    private static final String TYPE_MEMBER_NAME = "type";
    private static final String HREF_MEMBER_NAME = "href";

    
    public JSONParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return  "application/json";
    }
    
    /**
     * Parses the JSON response when no schema is provided.
     * 
     */
    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) throws IOException {
        
        final Reader reader = response.getReader();
        final ArrayList<String> blobElements = new ArrayList<>(); // we do not know which elements are of type blob,
        // we detect them on the fly
        return parse(client, reader, List.of(JSON_RESTFUL_LINKS_NAME), blobElements);
    }
    
    private static Iterator<List<Object>> parse(final IRESTClient restClient, final Reader reader, final List<String> ignoredElements,
            final List<String> blobElements) throws IOException {
        
        final JsonParser parser = new JsonParser();
        JsonElement json = parser.parse(reader);
        json = getJSONResults(json);
        
        final List<List<Object>> results = new ArrayList<>();
        results.add(getHeader(json, ignoredElements));
        
        if (json.isJsonObject()) {
            results.add(deserializeRow(restClient, json, ignoredElements, blobElements));
        } else if (json.isJsonArray()) {
            results.addAll(deserializeView(restClient, json, ignoredElements, blobElements));
        }
        
        return results.iterator();
    }

    private static List<Object> getHeader(final JsonElement json, final List<String> ignoredElements) {
        
        if (json.isJsonObject()) {
            final JsonObject jsonObject = json.getAsJsonObject();
            final List<Object> elementNames = new ArrayList<>();
            for (final Entry<String, JsonElement> entry : jsonObject.entrySet()) {           
                final String elementName = entry.getKey();
                
                if (shouldSkipElement(elementName, ignoredElements)) {
                    continue;
                }
                
                elementNames.add(elementName);
            }

            return elementNames;
            
        } else if (json.isJsonArray()) {
            final JsonArray jsonArray = json.getAsJsonArray();
            if (!jsonArray.isEmpty()) {
                final JsonElement firstElement = jsonArray.get(0);
                return getHeader(firstElement, ignoredElements);
            }
            
            return Collections.emptyList();
        }
        
        throw new TestExecutionException("Could not obtain element names from '" + json + "'");
    }
    
    private static List<List<Object>> deserializeView(final IRESTClient restClient, final JsonElement json, final List<String> ignoredElements,
            final List<String> blobElements) throws IOException {
        
        final JsonArray jsonView = json.getAsJsonArray();
        final List<List<Object>> view = new ArrayList<>();
        for (final JsonElement jsonElement : jsonView) {
            view.add(deserializeRow(restClient, jsonElement, ignoredElements, blobElements));
        }
        
        return view;
    }
    
    private static List<Object> deserializeRow(final IRESTClient restClient, final JsonElement json, final List<String> ignoredElements,
            final List<String> blobElements) throws IOException {
        
        final JsonObject jsonRow = json.getAsJsonObject();
        final List<Object> row = new ArrayList<>();
        for (final Entry<String, JsonElement> entry : jsonRow.entrySet()) { 
            final String elementName = entry.getKey();
            if (shouldSkipElement(elementName, ignoredElements)) {
                continue;
            }
            
            row.add(deserializeField(restClient, elementName, entry.getValue(), blobElements));
        }
        
        return row;
    }
    
    private static Object deserializeField(final IRESTClient restClient, final String elementName, final JsonElement json,
            final List<String> blobElements) throws IOException {
        
        if (json.isJsonObject()) {
            final JsonObject jsonObject = json.getAsJsonObject();
            
            if (isBlobReference(elementName, jsonObject, blobElements)) {
                return downloadBlob(restClient, jsonObject);
            }
            
            int i = 0;
            final Object[] record = new Object[jsonObject.entrySet().size()];
            for (final Entry<String, JsonElement> entry : jsonObject.entrySet()) { 
                final JsonElement jsonElement = entry.getValue();
                record[i++] = (deserializeField(restClient, elementName, jsonElement, blobElements));
            }
            
            return record;
            
        } 
        
        if (json.isJsonArray()) {
            final JsonArray jsonArray = json.getAsJsonArray();
            final List<Object> array = new ArrayList<>();
            for (final JsonElement jsonElement : jsonArray) {
                array.add(deserializeField(restClient, elementName, jsonElement, blobElements));
            }
            
            return array;
        
        } 
        
        if (json.isJsonPrimitive()) {
            final JsonPrimitive jsonPrimitive = json.getAsJsonPrimitive();

            return new TextualData(jsonPrimitive.getAsString());
            
        } 
        
        if (json.isJsonNull()) {
            return null;
        }
        
        throw new TestExecutionException("Could not deserialize the element '" + json + "'");
    }
    
    /**
     * REST web services return the result of a VDP view as a JSON object like:
     * {"name":"view_name","elements":[view_rows], "links":[links]. Being "links" an optional element configured by the admin of the REST service.
     * This method returns only the array named 'elements' that contains the view rows.
     * <p>
     * Otherwise, if the Web service returns only an element, this method does nothing.
     */
    private static JsonElement getJSONResults(final JsonElement json) {
        
        if (json.isJsonObject()) {
            final JsonObject jsonObject = json.getAsJsonObject();
            final Set<Entry<String, JsonElement>> entries = jsonObject.entrySet();
            if (entries.size() == 2 || entries.size() == 3) {
                final Entry<String, JsonElement>[] jsonElements = entries.toArray(new Entry[2]);
                final String elementName = jsonElements[1].getKey();
                final JsonElement jsonElement = jsonElements[1].getValue();
                if (elementName.equals(ELEMENTS_NAME) && jsonElement.isJsonArray()) {  
                    return jsonElement;
                }
            }
        }
        
        return json;
    }
    
    private static boolean shouldSkipElement(final String name, final List<String> ignoredElements) {
        return ignoredElements.contains(name);
    }

    /**
     * Blobs are of the form: 
     * "picture":{"rel":"self","type":"multipart/mixed","href":"/server/admin/staff/views/staff/1?$format=JSON&$select=picture"}
     */
    private static boolean isBlobReference(final String elementName, final JsonObject jsonObject, final List<String> blobElements) {
        
        if (blobElements.contains(elementName)) {
            return true;
        }

        // otherwise autodetect blob elements with the multipart/mixed type of the reference
        final JsonElement type = jsonObject.get(TYPE_MEMBER_NAME);
        return type != null && type.getAsString().equals(MULTIPART_MIXED_BLOB_TYPE);

    }
    
    private static String getBlobReference(final JsonObject jsonObject) {
        
        final JsonElement href = jsonObject.get(HREF_MEMBER_NAME);
        if (href == null) {
            return null;
        }
        
        return href.getAsString();
    }
    
    private static Object downloadBlob(final IRESTClient restClient, final JsonObject jsonObject) throws IOException {
        
        final String blobUrl = getBlobReference(jsonObject);
        if (blobUrl != null) {
            final Iterator<List<Object>> result = restClient.get(blobUrl);
            return BlobUtils.findBlobContent(result);
        }
        
        return null;
    }
    
    /**
     * Parses the JSON of the HTML response. Schema is needed to identify RESTful links and blob elements.
     * 
     */
    public Iterator<List<Object>> parse(final IRESTClient client, final String jsonSchema, final Reader reader) throws IOException {
        
        final JsonParser parser = new JsonParser();
        final JsonObject schema = parser.parse(jsonSchema).getAsJsonObject();
        
        final List<String> htmlRestfulLinks = getRESTfulLinks(schema);
        final List<String> blobElements = getBlobElements(schema);
        return parse(client, reader, htmlRestfulLinks, blobElements);
        
    }

    private static List<String> getRESTfulLinks(final JsonObject schema) {
        
        final List<String> restfulLinks = new ArrayList<>();

        for (final Entry<String, JsonElement> entry : schema.entrySet()) {           
            final String name = entry.getKey();
            final JsonObject metadata = entry.getValue().getAsJsonObject();
            if (isRESTfulLink(metadata)) {
                restfulLinks.add(getRESTfulLinkName(name));
            }
        }

        return restfulLinks;
    }
    
    /**
     * In the JSON of the HTML response RESTful links are of the form: 
     * "_primary_key":{"type":"object","properties":{"rel":{"type":"string"},"title":{"type":"string"},"href":{"type":"string"}}}
     */
    private static boolean isRESTfulLink(final JsonObject metadata) {
        
        final String type = metadata.getAsJsonPrimitive("type").getAsString();
        final JsonObject properties = metadata.getAsJsonObject("properties");
        return "object".equals(type) && properties.has("rel") && properties.has("title") && properties.has("href");
    }
    
    private static String getRESTfulLinkName(final String name) {
        
        if ("_primary_key".equals(name)) { //_primary_key is the name in the schema, Self is the name in the JSON data.
            return "Self";
        }
        
        // Names of link's associations starts with "_", e.g. "_company", but only in the schema, not in the JSON data.
        if (name.startsWith("_")) {
            return name.substring(1);
        }
        
        return name;
    }

    private static List<String> getBlobElements(final JsonObject schema) {
        
        final List<String> blobs = new ArrayList<>();

        for (final Entry<String, JsonElement> entry : schema.entrySet()) {           
            final String name = entry.getKey();
            final JsonObject metadata = entry.getValue().getAsJsonObject();
            if (isBlobElement(metadata)) {
                blobs.add(name);
            }
        }

        return blobs;
    }

    /**
     * In the JSON of the HTML response blobs are of the form: 
     * "picture":{"type":"binary"}
     */
    private static boolean isBlobElement(final JsonObject metadata) {
        
        final String type = metadata.getAsJsonPrimitive("type").getAsString();
        return "binary".equals(type);
    }
}
