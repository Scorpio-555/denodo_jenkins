/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

public class BinaryParser extends AbstractRESTParser {

    
    public BinaryParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return "application/octet-stream";
    }

    /**
     * URIs selecting a blob field with HTML responses
     * (<a href="http://localhost:9090/server/admin/staff/views/staff/1?$select=picture&$format=html">...</a>)
     * download the blob field directly.
     * URIs with JSON or XML responses
     * (<a href="http://localhost:9090/server/admin/staff/views/staff/1?select=picture$format=json">...</a>)
     * download multipart responses.
     * <p>
     * In the first case, we need to parse the $SELECT parameter from the URI to extract the name of the blob field
     * and use it as the result header with getHeader(uri).
     * In the latter case, the MultipartParser is in charge of extracting the name of the blob field.
     */
    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) throws IOException {
        
        final List<List<Object>> result = new ArrayList<>();

        if (response.getURI() != null) {
            final List<Object> header = getHeaderFromSelectParameter(response.getURI());
            result.add(header);
        }
        
        final List<Object> element = new ArrayList<>();

        //  binary fields are encoded in base64 when they are part of a multipart message
        final byte[] base64Data = IOUtils.toByteArray(response.getContent());
        byte[] decodedData = base64Data;
        if (Base64.isBase64(base64Data)) {
            decodedData = Base64.decodeBase64(base64Data);
        }

        element.add(decodedData);
        result.add(element);

        return result.iterator();

    }

}
