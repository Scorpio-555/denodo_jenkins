/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Iterator;
import java.util.List;

import org.attoparser.IMarkupHandler;
import org.attoparser.IMarkupParser;
import org.attoparser.MarkupParser;
import org.attoparser.ParseException;
import org.attoparser.config.ParseConfiguration;
import org.attoparser.output.OutputMarkupHandler;
import org.attoparser.select.BlockSelectorMarkupHandler;

import com.denodo.connect.testing.exception.TestExecutionException;

/**
 * This class extracts the JSON schema and data from the HTML REST Response and delegates the parsing in JSONParser class.
 * <p>
 * The JSON data is not exactly the same as the one received from a JSON REST Response,
 * therefore, we need the JSON Schema to detect
 * RESTful links and blob fields.
 *
 */
public class HTMLParser extends AbstractRESTParser {

    private static final String JAVASCRIPT_SELECTOR = "body/div/div/script";
    private static final String JAVASCRIPT_VAR_WITH_JSON_SCHEMA = "dataSchema = ";
    private static final String JAVASCRIPT_VAR_WITH_JSON_DATA = "var data = ";
    private static final String END_JAVASCRIPT_VAR = ";";

    public HTMLParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return "text/html";
    }

    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) throws IOException {
        
        
        try {

            final Reader reader = response.getReader();
            final String javascript = findInlineJavascript(reader);
            final String jsonSchema = findVariable(javascript, JAVASCRIPT_VAR_WITH_JSON_SCHEMA);
            final String jsonData = findVariable(javascript, JAVASCRIPT_VAR_WITH_JSON_DATA);
            final JSONParser jsonParser = new JSONParser();

            return jsonParser.parse(client, jsonSchema, new StringReader(jsonData));
            
        } catch (ParseException e) {
            throw new TestExecutionException("Error parsing HTML data", e);
        }
    }

    private static String findInlineJavascript(final Reader reader) throws ParseException {

        final Writer writer = new StringWriter();
        final IMarkupHandler outputHandler = new OutputMarkupHandler(writer);
        final BlockSelectorMarkupHandler jsSelectorHandler = new BlockSelectorMarkupHandler(outputHandler, JAVASCRIPT_SELECTOR);

        final IMarkupParser markupParser = new MarkupParser(ParseConfiguration.htmlConfiguration());

        markupParser.parse(reader, jsSelectorHandler);
        
        return writer.toString();
    }

    private static String findVariable(final String javascriptContent, final String varName) {
        
        final int startJSONData = javascriptContent.indexOf(varName);
        final int endJSONData = javascriptContent.indexOf(END_JAVASCRIPT_VAR, startJSONData);
        
        if (startJSONData == -1 || endJSONData == -1) {
            throw new TestExecutionException("JSON not found in Javascript: '" + javascriptContent + "'");
        }

        return javascriptContent.substring(startJSONData + varName.length(), endJSONData);

    }

}
