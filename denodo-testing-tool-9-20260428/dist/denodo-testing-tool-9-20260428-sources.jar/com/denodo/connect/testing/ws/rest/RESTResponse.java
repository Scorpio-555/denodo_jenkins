/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;

public class RESTResponse {
    
    private String uri;
    private String headers; 
    private Charset charset;
    private InputStream content;
    private final Map<String, Object> parameters;
    
    public RESTResponse() {
        this.parameters = new LinkedHashMap<>();
    }

    public RESTResponse(final String uri, final String headers, final Charset charset, final InputStream content) {

        this();
        this.uri = uri;
        this.headers = headers;
        this.charset = charset;
        this.content = content;
    }
    
    public String getURI() {
        return this.uri;
    }
    
    public void setURI(final String uri) {
        this.uri = uri;
    }

    public String getHeaders() {
        return this.headers;
    }
    
    public void setHeaders(final String headers) {
        this.headers = headers;
    }

    public Charset getCharset() {
        return this.charset;
    }
    
    public void setCharset(final Charset charset) {
        this.charset = charset;
    }

    public InputStream getContent() {
        return this.content;
    }
    
    public void setContent(final InputStream content) {
        this.content = content;
    }
    
    public Reader getReader() {
        return new InputStreamReader(this.content, this.charset);
    }

    public Object getParameter(final String name) {
        return this.parameters.get(name);
    }

    public void setParameters(final Map<String, Object> params) {
        this.parameters.putAll(params);
    }
    
    public void addParameter(final String name, final Object value) {
        this.parameters.put(name, value);
    }

}
