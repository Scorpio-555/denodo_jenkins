/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;

public class RESTClient implements IRESTClient {
    
    private final RESTParsersRegister restParsersRegister;
    
    private URI currentURI;
    private String user;
    private String password;
    private final Map<String, Object> params;
    
    public RESTClient(final RESTParsersRegister restParsersRegister) {
        
        Validate.notNull(restParsersRegister, "REST parsers register cannot be null");
        this.restParsersRegister = restParsersRegister;
        this.params = new HashMap<>();
    }
    
    @Override
    public void setCredentials(final String user, final String password) {
        this.user = user;
        this.password = password;
    }
        
    @Override
    public void addParameter(final String name, final Object value) {
        this.params.put(name, value);
    }
    
    @Override
    public void cleanup() {
        this.currentURI = null;
        clearCredentials();
        clearParameters();
    }
    
    public void clearCredentials() {
        this.user = null;
        this.password = null;
    }

    public void clearParameters() {
        this.params.clear();
    }
    
    @Override
    public Iterator<List<Object>> get(final String uriRaw) throws IOException {
        
        Validate.notNull(uriRaw, "URI cannot be null.");
        
        this.currentURI = resolveURI(uriRaw);
        
        final HttpGet getRequest = new HttpGet(this.currentURI);

        final HttpClientBuilder httpClientBuilder = HttpClients.custom();
        setCredentials(httpClientBuilder);

        
        try (   final CloseableHttpClient httpClient = httpClientBuilder.build();
                final CloseableHttpResponse response = httpClient.execute(getRequest)
        ) {

            final int statusCode = response.getStatusLine().getStatusCode();
            if (HttpStatus.SC_NO_CONTENT == statusCode) {
                return Collections.emptyIterator();
            }
            if (HttpStatus.SC_OK != statusCode) {
                throw new HttpResponseException(statusCode, statusCode + " " + response.getStatusLine().getReasonPhrase() + ": " + this.currentURI);
            }
            
            final HttpEntity httpEntity = response.getEntity();
            final Header contentType = httpEntity.getContentType();
            final Charset charset = getCharset(httpEntity);
            try (final InputStream content = httpEntity.getContent()) {
         
                final IRESTParser restParser = getResponseParser(contentType.getValue());
                final RESTResponse restResponse = new RESTResponse(this.currentURI.toString(), contentType.getValue(), charset,
                        content);
                restResponse.setParameters(this.params);
                return restParser.parse(this, restResponse);
            }

        }
    }

    private URI resolveURI(final String uriRaw) throws IOException {

        URI uri = URI.create(uriRaw);
        if (!uri.isAbsolute()) {
            if (this.currentURI != null) {
                uri = this.currentURI.resolve(uri);
            } else {
                throw new IOException ("URI does not specify a valid host name: " + uriRaw);
            }
        }
        
        return uri;
    }

    @Override
    public IRESTParser getResponseParser(final String headers) {
        return this.restParsersRegister.get(headers);
    }

    private void setCredentials(final HttpClientBuilder httpClientBuilder) {
        
        if (StringUtils.isNotBlank(this.user)) {
            final CredentialsProvider credsProvider = new BasicCredentialsProvider();
            credsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(this.user, this.password == null ? StringUtils.EMPTY : this.password));
            httpClientBuilder.setDefaultCredentialsProvider(credsProvider);
        }
    }
    
    private static Charset getCharset(final HttpEntity entity) throws UnsupportedEncodingException {
        
        Charset charset = null;
        try {
            final ContentType contentType = ContentType.get(entity);
            if (contentType != null) {
                charset = contentType.getCharset();
            }
        } catch (final UnsupportedCharsetException ex) {
            throw new UnsupportedEncodingException(ex.getMessage());
        }

        if (charset == null) {
            charset = HTTP.DEF_CONTENT_CHARSET;
        }
        
        return charset;
    }
    
}
