/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.mvel2.MVEL;

import com.denodo.connect.testing.engine.qualifier.StandardQualifiers.StandardContextValues;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.TextualData;
import com.rometools.rome.feed.synd.SyndCategory;
import com.rometools.rome.feed.synd.SyndEnclosure;
import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.FeedException;
import com.rometools.rome.io.SyndFeedInput;

/**
 * Transforms RSS data in the corresponding Java objects.
 * <p>
 * Each VDP row is transformed in a List<Object>.
 * A VDP view (a collection of rows) is transformed in a List of List<Object>.
 * <p>
 * Each field is transformed in TextualData, as REST responses do not have metadata information.
 */
public class RSSParser extends AbstractRESTParser {
    
    
    private static final String TITLE = "title";
    private static final String DESCRIPTION = "description";
    private static final String LINK = "link";
    private static final String AUTHOR = "author";
    private static final String CATEGORY = "category";
    private static final String CATEGORY_DOMAIN = "category#domain";
    private static final String COMMENTS = "comments";
    private static final String GUID = "guid";
    private static final String GUID_ISPERMALINK = "guid#isPermaLink";
    private static final String PUB_DATE = "pubDate";
    private static final String ENCLOSURE_URL = "enclosure#url";
    private static final String ENCLOSURE_LENGTH = "enclosure#length";
    private static final String ENCLOSURE_TYPE = "enclosure#type";
    private static final String SOURCE = "source";
    private static final String SOURCE_URL = "source#url";
    
    private static final String BLOB_METADATA = ":binary";
    

    public RSSParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return  "application/rss+xml";
    }

    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) {
        
        try {
            
            final SyndFeedInput input = new SyndFeedInput();
            final SyndFeed feed = input.build(response.getReader());
            final List<SyndEntry> entries = feed.getEntries();

            final String mappingsValue = (String) response.getParameter(StandardContextValues.MAPPINGS.name());
            final Map<String, String> mappings = resolveMappings(mappingsValue);
            
            final List<List<Object>> results = new ArrayList<>();
            final List<Object> header = getHeader(response.getURI(), mappings);
            final List<List<Object>> resultsDeserialized = deserializeView(entries, header, mappings);
            if (!resultsDeserialized.isEmpty()) {
                results.add(header);
                results.addAll(resultsDeserialized);
            }
           
            return results.iterator();
        
        } catch (final FeedException e) {
            throw new TestExecutionException("Error parsing RSS data", e);
        }
    }
    
    private static List<Object> getHeader(final String uri, final Map<String, String> mappings) {
    
        final List<Object> header = getHeaderFromSelectParameter(uri);
        if (header.isEmpty()) {
            addMappedField(TITLE, mappings, header);
            addMappedField(DESCRIPTION, mappings, header);
            addMappedField(LINK, mappings, header);
            addMappedField(AUTHOR, mappings, header);
            addMappedField(CATEGORY, mappings, header);
            addMappedField(CATEGORY_DOMAIN, mappings, header);
            addMappedField(COMMENTS, mappings, header);
            addMappedField(GUID, mappings, header);
            addMappedField(GUID_ISPERMALINK, mappings, header);
            addMappedField(PUB_DATE, mappings, header);
            addMappedField(ENCLOSURE_URL, mappings, header);
            addMappedField(ENCLOSURE_LENGTH, mappings, header);
            addMappedField(ENCLOSURE_TYPE, mappings, header);
            addMappedField(SOURCE, mappings, header);
            addMappedField(SOURCE_URL, mappings, header);
        }
        
        return header;
    }
    
    private static void addMappedField(final String rssField, final Map<String, String> mappings, final List<Object> header) {
        
        final String viewField = getCanonicalMappedField(rssField, mappings);
        if (viewField != null) {
            header.add(viewField);
        }
    }
    
    /**
     * Gets the VDP field name mapped to the rssField.
     * Removes the VDP field name with all the metadata information, if any.
     * 
     */
    private static String getMappedField(final String rssField, final Map<String, String> mappings) {
        
        String viewField = mappings.get(rssField);
        if (viewField == null) {
            final String rssAttribute = getRSSAttribute(rssField);
            viewField = mappings.get(rssAttribute);
        }
        
        return viewField;
    }

    /**
     * Gets the VDP field name mapped to the rssField. Removes metadata information from the field name, if any (e.g. :binary)
     * 
     */
    private static String getCanonicalMappedField(final String rssField, final Map<String, String> mappings) {
        
        final String viewField = getMappedField(rssField, mappings);
        return StringUtils.removeEndIgnoreCase(viewField, BLOB_METADATA); // always try to remove the binary metadata suffix
    }
    
    private static boolean isOutputField(final String rssField, final List<Object> header, final Map<String, String> mappings) {
        
        final String mappedField = getCanonicalMappedField(rssField, mappings);
        return header.contains(mappedField);
    }
    
    private static String getRSSAttribute(final String rssField) {
        
        final int startIndex = rssField.indexOf('#');
        if (startIndex != -1) {
            return rssField.substring(startIndex + 1);
        }
        
        return null;
    }
    
    private static List<List<Object>> deserializeView(final List<SyndEntry> entries, final List<Object> header, final Map<String, String> mappings) {
        
        final List<List<Object>> view = new ArrayList<>();
        for (final SyndEntry entry : entries) {
            view.add(deserializeRow(entry, header, mappings));
        }
        
        return view;
    }
    
    /**
     * Each <item> element defines an article in the RSS feed.
     * <p>
     * The <item> element has three required child elements:
     *  - <title> 
     *  - <link>
     *  - <description>
     * <p>
     * Optional elements:
     * - <author>
     * - <category>
     * - <comments>
     * - <guid>
     * - <pubDate> 
     * - <enclosure>
     * - <source>
     */
    private static List<Object> deserializeRow(final SyndEntry entry, final List<Object> header, final Map<String, String> mappings) {
        
        final List<Object> row = new ArrayList<>();

        if (isOutputField(TITLE, header, mappings)) {
            row.add(getOutputField(TITLE, entry.getTitle(), mappings));
        }
        if (isOutputField(DESCRIPTION, header, mappings)) {
            row.add(getOutputField(DESCRIPTION, entry.getDescription() == null ? null : entry.getDescription().getValue(), mappings));
        }
        if (isOutputField(LINK, header, mappings)) {
            row.add(getOutputField(LINK, entry.getLink(), mappings));
        }
        if (isOutputField(AUTHOR, header, mappings)) {
            row.add(getOutputField(AUTHOR, entry.getAuthor(), mappings));
        }
        
        final List<SyndCategory> categories = entry.getCategories();
        for (final SyndCategory category : categories) {
            
            if (isOutputField(CATEGORY, header, mappings)) {
             row.add(getOutputField(CATEGORY, category.getName(), mappings));
            }
            if (isOutputField(CATEGORY_DOMAIN, header, mappings)) {
                row.add(getOutputField(CATEGORY_DOMAIN, category.getTaxonomyUri(), mappings));
            }
        }
        
        if (isOutputField(COMMENTS, header, mappings)) {
            row.add(getOutputField(COMMENTS, entry.getComments(), mappings));
        }

        if (isOutputField(GUID, header, mappings)) {
            row.add(getOutputField(GUID, entry.getUri(), mappings));
        }
        
        if (isOutputField(GUID_ISPERMALINK, header, mappings)) {
            row.add(getOutputField(GUID_ISPERMALINK, Boolean.toString(entry.getLink() != null), mappings));
        }
        
        if (isOutputField(PUB_DATE, header, mappings)) {
            row.add(entry.getPublishedDate());
        }
        
        final List<SyndEnclosure> enclosures = entry.getEnclosures();
        for (final SyndEnclosure enclosure : enclosures) {
            
            if (isOutputField(ENCLOSURE_URL, header, mappings)) {
                row.add(getOutputField(ENCLOSURE_URL, enclosure.getUrl(), mappings));       
            }
            if (isOutputField(ENCLOSURE_LENGTH, header, mappings)) {
                row.add(getOutputField(ENCLOSURE_LENGTH, Long.toString(enclosure.getLength()), mappings));
            }
            if (isOutputField(ENCLOSURE_TYPE, header, mappings)) {
                row.add(getOutputField(ENCLOSURE_TYPE, enclosure.getType(), mappings));
            }
        }
        
        final SyndFeed sourceFeed = entry.getSource();
        if (sourceFeed != null) {
            
            if (isOutputField(SOURCE, header, mappings)) {
                row.add(getOutputField(SOURCE, sourceFeed.getTitle(), mappings));
            }
            if (isOutputField(SOURCE_URL, header, mappings)) {
                row.add(getOutputField(SOURCE_URL, sourceFeed.getUri(), mappings));
            }
        }
        
        return row;
    }

    /**
     * MVEL is used to configure mappings in the test file.
     * Mappings are expressed in the following format: [rest_field1 : view_field1, rest_field2: view_field2, ...]
     * For example:
     * ["guid" : "film_id", "pubDate" : "release_year"]
     * <p>
     * NOTE: "#" denotes mappings with tag attributes: "category#domain", "guid#isPermaLink", "enclosure#url"... 
     *       This syntax is optional, you could use "domain", "isPermaLink"... but in the case of mapping both "enclosure#url" or "source#url"
     *       the "#" is mandatory to distinguish which "url" is being mapped.
     * <p>
     * Mapping is required. 
     * Another option was to allow not configuring mappings for fields with the same name in RSS and in the VDP view,
     * like a view field named "title".
     * But with this option, we cannot distinguish between not mapped RSS fields and fields like
     * "title" with null values for all the rows of the view.
     * Therefore, all the fields that form part of the output must be mapped.
     */
    @SuppressWarnings("unchecked")
    private static Map<String, String> resolveMappings(final String mappings) {
        
        final Map<String, String> viewMappings = (Map<String, String>) MVEL.eval(mappings);
        if (viewMappings == null || viewMappings.isEmpty()) {
            throw new TestExecutionException("It is mandatory to configure mappings between RSS fields and VDP view fields.");
        }

        final Map<String, String> orderedMappings = new TreeMap<>(viewMappings); 
        return deleteDuplicatedValues(orderedMappings);
    }

    private static Map<String, String> deleteDuplicatedValues(final Map<String, String> viewMappings) {
        
        final Map<String, String> valueKeysMap = MapUtils.invertMap(viewMappings); // This step removes duplicated values
        
        return MapUtils.invertMap(valueKeysMap);
    }
    
    private static Object getOutputField(final String name, final String value, final Map<String, String> mappings) {
        
        if (isBlobElement(name, mappings)) {
            final byte[] blob = getBlobElement(value);
            if (blob != null && blob.length > 0) {
                return blob;
            }
        }
        
        return new TextualData(value);
    }
    
    /**
     * Blob fields are distinguished by the suffix :binary.
     * <p>
     * "VDP_field_name:binary"
     */
    private static boolean isBlobElement(final String name, final Map<String, String> mappings) {
        
            final String mappedField = getMappedField(name, mappings);
            return mappedField.endsWith(BLOB_METADATA);
    }
    
    /**
     * Blob fields in VDP RSS web services are encoded as Base64.
     */
    private static byte[] getBlobElement(final String base64Data) {
        
        if (Base64.isBase64(base64Data)) {
            return Base64.decodeBase64(base64Data);
        }
        
        return null;
        
    }
}
