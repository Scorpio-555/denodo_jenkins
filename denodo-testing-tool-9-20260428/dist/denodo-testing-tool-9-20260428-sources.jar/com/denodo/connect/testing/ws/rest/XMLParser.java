/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.ws.rest;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.attoparser.ParseException;
import org.attoparser.config.ParseConfiguration;
import org.attoparser.dom.DOMMarkupParser;
import org.attoparser.dom.Document;
import org.attoparser.dom.Element;
import org.attoparser.dom.IDOMMarkupParser;
import org.attoparser.dom.Text;
import org.unbescape.xml.XmlEscape;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.BlobUtils;
import com.denodo.connect.testing.util.TextualData;

/**
 * Transforms XML data in the corresponding Java objects.
 * <p>
 * Each VDP row is transformed in a List<Object>.
 * A VDP view (a collection of rows) is transformed in a List of List<Object>.
 * <p>
 * Each field is transformed depending on its type:
 *  - Primitive types to TextualData, as REST responses do not have metadata information.
 *  - Array types to List
 *  - Record types to Object[]
 */
public class XMLParser extends AbstractRESTParser {
    

    /**
     * Name of the root element that contains the results when the web service returns a collection.
     */
    private static final String COLLECTION_ROOT_NAME = "denodo:view";
    
    /**
     * XML results could include in each row a link to the row itself and, for each association of the view, a link to traverse the association.
     * These links are grouped in an element named "atom:link" (element reused from the ATOM specification)
     * that the parser will skip as they are not relevant for tests results.
     */
    private static final String RESTFUL_LINKS_NAME = "atom:link";
    
    /**
     * Denodo REST Web services specify that a field value is NULL by adding the attribute xsi:nil="true" to the element.
     */
    private static final String NULL_ATTRIBUTE_NAME = "xsi:nil";
    private static final String NULL_ATTRIBUTE_VALUE = "true";
    
    private static final String HREF_ATTRIBUTE_NAME = "href";
    private static final String TYPE_ATTRIBUTE_NAME = "type";
    private static final String MULTIPART_MIXED_BLOB_TYPE = "multipart/mixed";
    

    public XMLParser() {
        super();
    }
    
    @Override
    public String getContentType() {
        return "application/xml";
    }

    @Override
    public Iterator<List<Object>> parse(final IRESTClient client, final RESTResponse response) throws IOException {
        
        try {
        
            final Reader reader = response.getReader();
            final IDOMMarkupParser parser = new DOMMarkupParser(ParseConfiguration.xmlConfiguration());
            final Document document = parser.parse(reader);
            
            final Element xmlRoot = getRoot(document);

            final List<List<Object>> results = new ArrayList<>();
            results.add(getHeader(xmlRoot));
            
            if (isCollectionRoot(xmlRoot)) {
                results.addAll(deserializeView(client, xmlRoot));
            } else {
                results.add(deserializeRow(client, xmlRoot));
            }
            
            return results.iterator();
            
        } catch (ParseException e) {
            throw new TestExecutionException("Error parsing XML data", e);
        }
    }

    
    private static Element getRoot(final Document xmlDocument) {
    
        final Element root = xmlDocument.getFirstChildOfType(Element.class);
        if (root == null) {
            throw new TestExecutionException("XML document has no root element");
        }
        
        return root;
    }
    
    private static List<Object> getHeader(final Element xmlRoot) {
                
        Element element = xmlRoot;
        if (isCollectionRoot(xmlRoot)) {
            element = xmlRoot.getFirstChildOfType(Element.class);
        }
        
        // Use Set because Array types lead to duplicate element names
        final Set<Object> header = new LinkedHashSet<>();
        for (final Element xmlChild : element.getChildrenOfType(Element.class)) {
            
            if (shouldSkipElement(xmlChild)) {
                continue;
            }
            
            header.add(xmlChild.getElementName());
        }
        
        return new ArrayList<>(header);
    }

    private static List<List<Object>> deserializeView(final IRESTClient restClient, final Element xml) throws IOException {
        
        final List<List<Object>> view = new ArrayList<>();
        for (final Element xmlChild : xml.getChildrenOfType(Element.class)) {
            if (shouldSkipElement(xmlChild)) {
                continue;
            }

            view.add(deserializeRow(restClient, xmlChild));
        }
        
        return view;
    }
    
    /**
     * This method uses a multivalued map for detecting Array types like "people_column" in the example:
     * <people>
     *    <group_no>100</group_no>
     *    <people_column>...</people_column>
     *    <people_column>...</people_column>
     * </people>
     * <p>
     * Then the multivalued map is flattened:
     *  - if the list contains only one element, the list is deleted, and only the value is kept
     *  - otherwise the value list is kept
     */
    private static List<Object> deserializeRow(final IRESTClient restClient, final Element xml) throws IOException {

        final Map<String, List<Object>> fields = new LinkedHashMap<>();
        for (final Element xmlChild : xml.getChildrenOfType(Element.class)) {
            if (shouldSkipElement(xmlChild)) {
                continue;
            }
            
            List<Object> array = fields.get(xmlChild.getElementName());
            if (array == null) {
                array = new ArrayList<>();
            }
            array.add(deserializeField(restClient, xmlChild));
            fields.put(xmlChild.getElementName(), array);
        }
        
        return flattenMultiValueMap(fields);
    }

    private static List<Object> flattenMultiValueMap(Map<String, List<Object>> fields) {
        
        List<Object> row = new ArrayList<>();
        
        for (List<Object> value : fields.values()) {
            if (value.size() == 1) {
                row.add(value.get(0));
            } else {
                row.add(value);
            }
        }
        
        return row;
    }

    private static Object deserializeField(final IRESTClient restClient, final Element xml) throws IOException {
        
        if (hasNullValue(xml)) {
            return null;
        } 
        
        // Empty elements represents empty strings
        if (!xml.hasChildren()) {
            return new TextualData(StringUtils.EMPTY); 
        } 
        
        if (hasOneTextChild(xml)) {
            final Text text = xml.getFirstChildOfType(Text.class);
            return new TextualData(text.getContent());
        }
        
        if (isBlobReference(xml)) {
            return downloadBlob(restClient, xml);
        }
        
        List<Element> xmlChildren = xml.getChildrenOfType(Element.class);
        final Map<String, List<Object>> fields = new LinkedHashMap<>();
        for (final Element xmlChild : xmlChildren) {
            List<Object> array = fields.get(xmlChild.getElementName());
            if (array == null) {
                array = new ArrayList<>();
            }
            array.add(deserializeField(restClient, xmlChild));
            fields.put(xmlChild.getElementName(), array);
        }

        return flattenMultiValueMap(fields).toArray();
    }
    
    /**
     * Blobs are of the form: 
     * <picture xsi:nil="false">
     *     <atom:link rel="self" type="multipart/mixed" href="http://localhost:9090/server/admin/staff/views/staff/1?$format=XML&amp;$select=picture"/>
     * </picture>
     */
    private static boolean isBlobReference(final Element element) {
        
        if (element.numChildren() == 1) {
            Element child = element.getFirstChildOfType(Element.class);
            return RESTFUL_LINKS_NAME.equals(child.getElementName()) && MULTIPART_MIXED_BLOB_TYPE.equals(child.getAttributeValue(TYPE_ATTRIBUTE_NAME));
        }
        
        return false;
    }
    
    private static String getBlobReference(final Element element) {
        
        Element child = element.getFirstChildOfType(Element.class);
        final String blobHref = child.getAttributeValue(HREF_ATTRIBUTE_NAME);
        return XmlEscape.unescapeXml(blobHref);
    }
    
    private static Object downloadBlob(final IRESTClient restClient, final Element element) throws IOException {
        
        final String blobUrl = getBlobReference(element);
        if (blobUrl != null) {
            final Iterator<List<Object>> result = restClient.get(blobUrl);
            return BlobUtils.findBlobContent(result);
        }
        
        return null;
    }
    
    private static boolean hasOneTextChild(final Element xmlChild) {
        return xmlChild.numChildren() == 1 && xmlChild.getFirstChildOfType(Text.class) != null;
    }
    
    private static boolean isCollectionRoot(final Element element) {
        return COLLECTION_ROOT_NAME.equals(element.getElementName());
    }
    
    private static boolean shouldSkipElement(final Element child) {
        return RESTFUL_LINKS_NAME.equals(child.getElementName());
    }

    private static boolean hasNullValue(final Element element) {
        return NULL_ATTRIBUTE_VALUE.equals(element.getAttributeValue(NULL_ATTRIBUTE_NAME));
    }
    

}
