package com.denodo.connect.testing.reporter;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import com.denodo.connect.testing.engine.TestExecutorResult;
import com.sun.mail.smtp.SMTPTransport;

public class EmailTestReporter extends AbstractTestReporter {
    
    private static final Logger LOG = LoggerFactory.getLogger(EmailTestReporter.class);
    
    private String firstTestable = null;
    
    public enum MessageLevel {
        FULL,
        
        SUMMARY,
        
        FAILED
    }
    
    private String username =null;
    private String password;
    private String serverHost;
    private String serverPort;
    private String serverProtocol;
    private String smtpAuth = "false";
    private String smtpStarttlsEnable = "false";
    private String smtpQuitwait = "false";
    private String recipient;
    private String from;
    private MessageLevel messageDetailLevel;
    private String failedTestsMetafilePath;
    private String createdFailedTestsMetafilePath;
    
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public void setServerProtocol(String serverProtocol) {
        this.serverProtocol = serverProtocol;
    }

    public void setSmtpAuth(String smtpAuth) {
        this.smtpAuth = smtpAuth;
    }

    public void setSmtpStarttlsEnable(String smtpStarttlsEnable) {
        this.smtpStarttlsEnable = smtpStarttlsEnable;
    }

    public void setSmtpQuitwait(String smtpQuitwait) {
        this.smtpQuitwait = smtpQuitwait;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setMessageDetailLevel(String messageDetailLevel) {
        this.messageDetailLevel = MessageLevel.valueOf(messageDetailLevel.toUpperCase());
    }
    
    @Override
    public void engineStart(final String resourceName, String failedTestsMetafilePath) {
        
        Validate.notEmpty(this.serverHost, "Server host cannot be null or empty");
        Validate.notEmpty(this.serverPort, "Server port cannot be null or empty");
        Validate.notEmpty(this.serverProtocol, "Server port cannot be null or empty");
        Validate.notEmpty(this.from, "From cannot be null or empty");
        Validate.notEmpty(this.recipient, "Recipient cannot be null or empty");
        Validate.notNull(this.messageDetailLevel, "Message detail level cannot be null or empty");

        if (Boolean.parseBoolean(this.smtpAuth)) {
            Validate.notEmpty(this.username, "Username cannot be null or empty when smtpAuth is true");
            Validate.notEmpty(this.password, "Password cannot be null or empty when smtpAuth is true");
        }
        
        this.firstTestable = resourceName;
        this.failedTestsMetafilePath = failedTestsMetafilePath;
    }

    @Override
    public void engineEnd(final TestExecutorResult result, String failedTestsMetafilePath) {
        
        if (!result.getFailedTests().isEmpty() || (result.getFailedTests().isEmpty() && !MessageLevel.FAILED.equals(this.messageDetailLevel))) {
            String sb = "Denodo Testing Tool Report: "
                + (result.getFailedTests().isEmpty() ? "OK" : "FAILED")
                + " Test resource: "
                + abbreviateResourceName(this.firstTestable);
            this.createdFailedTestsMetafilePath = failedTestsMetafilePath;

            try {
                send(sb, result);
            } catch (MessagingException e) {
                LOG.error("Error sending the e-mail report: ", e);
            }
        }
    }
    
    private void send(String subject, final TestExecutorResult result) throws MessagingException {

        Properties props = new Properties();
        props.setProperty("mail.smtp.host", this.serverHost);
        props.setProperty("mail.smtp.port", this.serverPort);
        props.setProperty("mail.smtp.auth", this.smtpAuth);
        props.setProperty("mail.smtp.starttls.enable", this.smtpStarttlsEnable);
        props.setProperty("mail.smtp.quitwait", this.smtpQuitwait);

        Session session = Session.getInstance(props, null);

        final MimeMessage msg = new MimeMessage(session);

        msg.setFrom(new InternetAddress(this.from));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(this.recipient, false));

        msg.setSubject(subject);
        
        Context ctx = getContext(result);
        
        ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
        resolver.setPrefix("mail/");
        resolver.setSuffix(".html");
        
        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(resolver);
        
        // Create the HTML body using Thymeleaf
        final String htmlContent = templateEngine.process("email", ctx);
        msg.setContent(htmlContent, "text/html; charset=utf-8");

        SMTPTransport t = (SMTPTransport)session.getTransport(this.serverProtocol);

        if (Boolean.parseBoolean(this.smtpAuth)) {
            t.connect(this.serverHost, this.username, this.password);
        } else {
            t.connect();
        }
        t.sendMessage(msg, msg.getAllRecipients());      
        t.close();
    }
    
    private Context getContext(final TestExecutorResult result) {
        final Context ctx = new Context();
        ctx.setVariable("title", getTitle(result));
        ctx.setVariable("currentDate", new Date());
        if (result.getFailedTests().isEmpty()) {
            // green color
            ctx.setVariable("backgroundColor", "#BCF5A9");
            ctx.setVariable("fontColor", "#21610B");
        } else {
            // red color
            ctx.setVariable("backgroundColor", "#F5A9A9");
            ctx.setVariable("fontColor", "#DF0101");
        }
        ctx.setVariable("resource", this.firstTestable);
        if(this.failedTestsMetafilePath!=null){
            ctx.setVariable("onlyFailedTestsLastExecution", this.failedTestsMetafilePath);
        }
        ctx.setVariable("totalTests", result.getTotalTests());
        ctx.setVariable("okTests", result.getOkTests());
        ctx.setVariable("failedTestsNumber", result.getTotalTests() - result.getOkTests());
        if(this.createdFailedTestsMetafilePath!=null){
            ctx.setVariable("createdFailedTestsMetafilePath", this.createdFailedTestsMetafilePath);
        }
        ctx.setVariable("showErrorSummary", !MessageLevel.FULL.equals(this.messageDetailLevel)
            && !result.getFailedTests().isEmpty());
        ctx.setVariable("showFullExecution", MessageLevel.FULL.equals(this.messageDetailLevel));
        ctx.setVariable("failedTests", result.getFailedTests());
        ctx.setVariable("allTests", result.getAllTests());
        ctx.setVariable("totalTuples", result.getTotalTuples());
        ctx.setVariable("zeroTupleTests", result.getZeroTuplesTests());
        
        return ctx;
    }
    
    private static String getTitle(final TestExecutorResult result) {
        StringBuilder sb = new StringBuilder();
        if (result.getFailedTests().isEmpty()) {
            sb.append("Execution was SUCCESSFUL");
        } else {
            int failedTests = result.getTotalTests() - result.getOkTests();
            sb.append(failedTests);
            if (failedTests > 1) {
                sb.append(" tests have ");
            } else {
                sb.append(" test has ");
            }
            sb.append("FAILED");
        }
        
        return sb.toString();
    }
    
    private static String abbreviateResourceName(final String resourceName) {

        if (resourceName == null) {
            return null;
        }

        if (resourceName.length() > 40) {
            return "..."
                + resourceName.substring(resourceName.length() - 37);
        }
        return resourceName;

    }
}
