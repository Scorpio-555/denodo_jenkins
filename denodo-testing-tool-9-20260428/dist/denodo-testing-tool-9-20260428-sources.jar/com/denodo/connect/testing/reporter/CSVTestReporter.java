package com.denodo.connect.testing.reporter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorResult;
import com.denodo.connect.testing.exception.TestExecutionException;

public class CSVTestReporter extends AbstractTestReporter {

    private static final BigInteger NANOS_IN_MILLIS = BigInteger.valueOf(1000000);
    
    FileWriter fileWriter = null;
    CSVPrinter csvFilePrinter = null;
    
    private String pathToOutputFile = null;
    
    private Boolean overwriteOutputFileIfExists = null;
    
    public void setPathToOutputFile(String pathToFile) {
        this.pathToOutputFile = pathToFile;
    }
    
    public void setOverwriteOutputFileIfExists(Boolean overwriteOutputFile) {
        this.overwriteOutputFileIfExists = overwriteOutputFile;
    }


    @Override
    public void engineStart(final String resourceName, String failedTestsMetafilePath) {
        Validate.notNull(this.pathToOutputFile, "Path to csv file cannot be null or empty");
        Validate.notNull(this.overwriteOutputFileIfExists, "The value of overwriteOutputFileIfExists cannot be null: " + this.pathToOutputFile);
        
        String[] headerLine = {"Test Result","Resource Name","Test Name","Time Elapsed", "Tuples", "Test Message"};
        CSVFormat format = CSVFormat.RFC4180.withEscape('\\').withDelimiter(',').
                withHeader(headerLine);
        
        boolean alreadyExists = new File(this.pathToOutputFile).exists();
        
        try {
            boolean append = !this.overwriteOutputFileIfExists;
            this.fileWriter = new FileWriter(this.pathToOutputFile, append);
            
            if (alreadyExists && append) {
                // We can assume that the file already has the header line
                // null: disable header
                format = format.withHeader((String[]) null);
            }
            
            this.csvFilePrinter = new CSVPrinter(this.fileWriter, format);
        } catch (FileNotFoundException e) {
            throw new TestExecutionException("Error opening or creating the file " + this.pathToOutputFile, e);
        } catch (IOException e) {
            throw new TestExecutionException("Error writing headers to the file " + this.pathToOutputFile, e);
        }
    }
    
    @Override
    public void engineEnd(final TestExecutorResult result, String createdMetafilePath) {        
        try {
            if (this.csvFilePrinter != null) {
                this.csvFilePrinter.flush();
                this.csvFilePrinter.close();
            }
        } catch (IOException e) {
            throw new TestExecutionException("Error flushing/closing " + this.pathToOutputFile, e);
        } 
    }
    
    @Override
    public void testEnd(final int nestingLevel, final String resourceName, final String testName, final String testDescription,
            final ITestResult testResult, final long executionTimeNanos, final Integer totalTuples) {
        
        try {            
            List<String> testRecord = new ArrayList<>();
            
            if (testResult != null) {
                String testResultValue = testResult.isOK() ? "OK" : "FAILED";

                String testMessage = StringUtils.EMPTY;
                if (testResult.hasMessage()) {
                    testMessage = testResult.getMessage();
                }
                
                // Test Result
                testRecord.add(testResultValue);
                //Resource Name
                testRecord.add(resourceName != null ? resourceName : StringUtils.EMPTY);
                // Test Name
                testRecord.add(testName != null ? testName : StringUtils.EMPTY);
                // Time Elapsed
                testRecord.add(duration(executionTimeNanos));
                // Number of tuples
                if (totalTuples != null) {
                    // At this point, totalTuples should be not null because it is null when testResult is null
                    testRecord.add(totalTuples.toString());
                }else{
                    testRecord.add(null);
                }
                //Test Message
                testRecord.add(testMessage);
                
                this.csvFilePrinter.printRecord(testRecord);
            }
            
        } catch (IOException e) {
            throw new TestExecutionException("Error writing to file " + this.pathToOutputFile, e);
        } 
    }
    
    private static String duration(final long nanos) {
        final BigInteger nanosBI = BigInteger.valueOf(nanos);
        return nanosBI.divide(NANOS_IN_MILLIS) + "ms";
    }
}
