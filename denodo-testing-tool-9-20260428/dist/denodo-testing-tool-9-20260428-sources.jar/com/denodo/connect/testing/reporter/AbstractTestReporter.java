/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.reporter;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorResult;


public abstract class AbstractTestReporter implements ITestReporter {

    @Override
    public void engineStart(final String resourceName, String failedTestsMetafilePath) {
        // Nothing to do here - meant to be overridden
    }

    @Override
    public void engineEnd(final TestExecutorResult result, String createdMetafilePath) {
        // Nothing to do here - meant to be overridden
    }

    @Override
    public void sequenceStart(final int nestingLevel, final String resourceName) {
        // Nothing to do here - meant to be overridden
    }

    @Override
    public void sequenceEnd(final int nestingLevel, final String resourceName, final TestExecutorResult result) {
        // Nothing to do here - meant to be overridden
    }

    @Override
    public void testStart(final int nestingLevel, final String resourceName, final String testName) {
        // Nothing to do here - meant to be overridden
    }

    @Override
    public void testEnd(final int nestingLevel, final String resourceName, final String testName, final String testDescription,
            final ITestResult testResult, final long executionTimeNanos, final Integer totalTuples) {
        // Nothing to do here - meant to be overridden
    }

}
