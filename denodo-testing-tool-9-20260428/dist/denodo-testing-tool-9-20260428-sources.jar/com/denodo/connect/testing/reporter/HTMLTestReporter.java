package com.denodo.connect.testing.reporter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Date;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import com.denodo.connect.testing.engine.TestExecutorResult;

public class HTMLTestReporter extends AbstractTestReporter {
    
    private static final Logger LOG = LoggerFactory.getLogger(HTMLTestReporter.class);
    
    private Writer writer = null;
    
    private String firstTestable = null;
    
    private String pathToOutputFile = null;
    
    private Boolean overwriteOutputFileIfExists = null;
    
    private String failedTestsMetafilePath = null;
    
    private String createdFailedTestsMetafilePath = null;
    
    public void setPathToOutputFile(String pathToFile) {
        this.pathToOutputFile = pathToFile;
    }
    
    public void setOverwriteOutputFileIfExists(Boolean overwriteOutputFile) {
        this.overwriteOutputFileIfExists = overwriteOutputFile;
    }
    
    @Override
    public void engineStart(final String resourceName, String failedTestsMetafilePath) {

        Validate.notNull(this.pathToOutputFile, "Path to html file cannot be null or empty");
        Validate.notNull(this.overwriteOutputFileIfExists, "The value of overwriteOutputFileIfExists cannot be null: " + this.pathToOutputFile);
        
        this.firstTestable = resourceName;
        
        boolean alreadyExists = new File(this.pathToOutputFile).exists();
        this.failedTestsMetafilePath = failedTestsMetafilePath;
        
        if (alreadyExists && !this.overwriteOutputFileIfExists) {
            LOG.error("The file " + this.pathToOutputFile + " already exists.");
        } else {
            try {
                final FileOutputStream fileOutputStream = new FileOutputStream(this.pathToOutputFile);
                this.writer = new OutputStreamWriter(fileOutputStream, Charset.defaultCharset());
                
            } catch (FileNotFoundException e) {
                LOG.error("Error opening or creating the file " + this.pathToOutputFile, e);
            } 
        }
    }
    
    @Override
    public void engineEnd(final TestExecutorResult result, String createdMetafilePath) {
        try {
            this.createdFailedTestsMetafilePath = createdMetafilePath;
            Context ctx = getContext(result);
            
            ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
            resolver.setPrefix("html/");
            resolver.setSuffix(".html");
            
            TemplateEngine templateEngine = new TemplateEngine();
            templateEngine.setTemplateResolver(resolver);
            

            // Create the HTML body using Thymeleaf
            templateEngine.process("html_report", ctx, this.writer);
            

        } finally {
            try {
                this.writer.close();
            } catch (final Throwable ignored) {
                // ignored - otherwise would override an important exception being thrown above
            }
        }
    }

    private Context getContext(final TestExecutorResult result) {
        final Context ctx = new Context();   
        ctx.setVariable("title", getTitle(result));
        ctx.setVariable("currentDate", new Date());
        if (result.getFailedTests().isEmpty()) {
            // green color
            ctx.setVariable("backgroundColor", "#BCF5A9");
            ctx.setVariable("fontColor", "#21610B");
        } else {
            // red color
            ctx.setVariable("backgroundColor", "#F5A9A9");
            ctx.setVariable("fontColor", "#DF0101");
        }
        
        ctx.setVariable("resource", this.firstTestable);
        if(this.failedTestsMetafilePath!=null){
            ctx.setVariable("onlyFailedTestsLastExecution", this.failedTestsMetafilePath);
        }
        ctx.setVariable("totalTests", result.getTotalTests());
        ctx.setVariable("okTests", result.getOkTests());
        ctx.setVariable("failedTestsNumber", result.getTotalTests() - result.getOkTests());
        if(this.createdFailedTestsMetafilePath!=null){
            ctx.setVariable("createdFailedTestsMetafilePath", this.createdFailedTestsMetafilePath);
        }
        ctx.setVariable("totalTimeElapsed", result.getExecutionTimeNanos());
        ctx.setVariable("totalTuples", result.getTotalTuples());
        ctx.setVariable("zeroTupleTests", result.getZeroTuplesTests());
        
        ctx.setVariable("allTests", result.getAllTests());
       
        return ctx;
    }
    
    private static String getTitle(final TestExecutorResult result) {
        StringBuilder sb = new StringBuilder();
        if (result.getFailedTests().isEmpty()) {
            sb.append("Execution was SUCCESSFUL");
        } else {
            int failedTests = result.getTotalTests() - result.getOkTests();
            sb.append(failedTests);
            if (failedTests > 1) {
                sb.append(" tests have ");
            } else {
                sb.append(" test has ");
            }
            sb.append("FAILED");
        }
        
        return sb.toString();
    }
}
