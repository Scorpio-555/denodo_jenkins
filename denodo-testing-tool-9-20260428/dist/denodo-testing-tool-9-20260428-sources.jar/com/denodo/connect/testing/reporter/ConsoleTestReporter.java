/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.reporter;

import java.math.BigInteger;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorResult;
import com.denodo.connect.testing.engine.TestExecutorResult.TestInformation;



public class ConsoleTestReporter extends AbstractTestReporter {

    private static final BigInteger NANOS_IN_MILLIS = BigInteger.valueOf(1000000);
    
    @Override
    public void engineStart(final String resourceName,  String failedTestsMetafilePath) {
        
        final StringBuilder sb = new StringBuilder();
        sb.append(formatTestResults("EXECUTION:START", null, null, null,
            null, null, null, null));
        sb.append('\n');
        sb.append("-------------------------------------------------------\n");
        sb.append(" T E S T S                                             \n");
        sb.append("-------------------------------------------------------\n");
        if(failedTestsMetafilePath!=null){
            sb.append("-------------------------------------------------------\n");   
            sb.append("Only the tests that have failed in the last execution will be executed. \n");
            sb.append("Failed test metafile being used: ").append(failedTestsMetafilePath).append(". \n");
            sb.append("-------------------------------------------------------\n");   
        }
        
        final String message = sb.toString();
        output(formatLine(message, 0), false);
    }

    @Override
    public void engineEnd(final TestExecutorResult result, String createdMetafilePath) {
        
        final StringBuilder sb = new StringBuilder();
        sb.append(formatTestResults("EXECUTION:END", null, null,
            result.getOkTests(), result.getTotalTests(), result.getExecutionTimeNanos(), null,
            result.getTotalTuples()));
        sb.append("\n-------------------------------------------------------\n");
        sb.append("Results: \n");
        
        if (!result.getFailedTests().isEmpty()) {
            sb.append("\nFailed tests: \n");
            for (TestInformation failedTest : result.getFailedTests()) {
                sb.append("-");
                if (failedTest.getName() != null) {
                    sb.append(failedTest.getName());
                }
                sb.append('(').append(abbreviateResourceName(failedTest.getResource())).append("): ")
                    .append(failedTest.getMsg()).append('\n');
            }
            sb.append('\n');
            if(createdMetafilePath!=null){
                sb.append("\nfile ").append(createdMetafilePath).append(
                    " was created. Execute again with --failed-resumable to only execute tests that failed during this execution. \n");
            }
        }
        
        sb.append("Tests run: ").append(result.getTotalTests());
        sb.append(", OK: ").append(result.getOkTests());
        sb.append(result.getOkTests() < result.getTotalTests() ? " (FAILED: " + (result.getTotalTests() - result.getOkTests()) + ")" : "").append('\n');
        sb.append("Total tuples: ").append(result.getTotalTuples());
        sb.append(", Zero-tuple tests: ").append(result.getZeroTuplesTests()).append('\n');
        sb.append("Suite executed in ").append(duration(result.getExecutionTimeNanos())).append('.');
        sb.append("\n-------------------------------------------------------\n");
        final String message = sb.toString();
        
        output(formatLine(message, 0), false);
        
    }

    @Override
    public void sequenceStart(final int nestingLevel, final String resourceName) {

        final String message =
            formatTestResults("SEQUENCE:START", abbreviateResourceName(resourceName), null,
                null, null, null, null, null)
                + "Sequence started: "
                + resourceName
                + '.';
        output(formatLine(message, nestingLevel), false);
    }

    @Override
    public void sequenceEnd(final int nestingLevel, final String resourceName, final TestExecutorResult result) {

        final String message = formatTestResults("SEQUENCE:END", abbreviateResourceName(resourceName), null,
            result.getOkTests(), result.getTotalTests(),
            result.getExecutionTimeNanos(), null, result.getTotalTuples())
            + "Sequence finished. Tests run: " + result.getTotalTests()
            + ", OK: " + result.getOkTests()
            + (result.getOkTests() < result.getTotalTests() ? " (FAILED: " + (result.getTotalTests()
            - result.getOkTests()) + ")" : "")
            + ", Total tuples: " + result.getTotalTuples()
            + ", Time elapsed: " + duration(result.getExecutionTimeNanos()) + '.';
        
        output(formatLine(message, nestingLevel), false);
    }

    @Override
    public void testStart(final int nestingLevel, final String resourceName, final String testName) {
        // The implementation of this method is not outputting anything for test start events.
        
    }

    @Override
    public void testEnd(final int nestingLevel, final String resourceName, final String testName, final String testDescription,
            final ITestResult testResult, final long executionTimeNanos, final Integer totalTuples) {

        if (testResult != null) {
            // At this point, totalTuples should be not null because it is null when testResult is null
            Long tuples = totalTuples != null ? Long.valueOf(totalTuples) : null;
            
            final StringBuilder sb = new StringBuilder();
            sb.append(formatTestResults("TEST:END", abbreviateResourceName(resourceName), testName,
                null, null, executionTimeNanos, testResult.isOK(), tuples));
            if (testName != null) {
                sb.append("Test run: ").append(testName).append('.');
            }
            sb.append(' ');

            if (testResult.isOK()) {
                sb.append("Test executed OK");
            } else {
                sb.append("Test FAILED!");
            }

            if (testResult.hasMessage()) {
                sb.append(": ").append(testResult.getMessage());
            } else {
                sb.append(". ");
            }

            sb.append(" Time elapsed: ").append(duration(executionTimeNanos)).append('.');

            if (testResult.hasThrowable()) {
                if (testResult.isOK()) {
                    // If the result is OK, we just inform about the exception (correctly) obtained
                    sb.append(" Exception thrown: ").append(testResult.getThrowable().getClass().getName()).append(": ")
                        .append(testResult.getThrowable().getMessage());

                } else {
                    sb.append('\n').append(ExceptionUtils.getStackTrace(testResult.getThrowable()));
                }
            }

            final String message = sb.toString();
            output(formatLine(message, nestingLevel), !testResult.isOK());
        }
    }

    /*
     * This methods formats test results for easily parse reports with log analysis tools.
     */
    private static String formatTestResults(
            final String executionState, final String resourceName, final String testName, final Integer okTests,
            final Integer totalTests, final Long executionTimeNanos, final Boolean ok, final Long totalTuples) {
    
        final StringBuilder sb = new StringBuilder();
        sb.append('[').append(executionState.toUpperCase()).append(']');
        
        if (ok != null) {
            sb.append(ok ? "[OK]" : "[FAILED]");
        } else if (okTests != null && totalTests != null) {
            sb.append(okTests.equals(totalTests) ? "[OK]" : "[FAILED]");
        }
        
        if (resourceName != null) {
            sb.append('[').append(resourceName).append(']');
        }
        if (testName != null) {
            sb.append('[').append(testName).append(']');
        }

        if (totalTests != null) {
            sb.append('[').append(totalTests).append(']');
        }

        if (okTests != null) {
            sb.append('[').append(okTests).append(']');
        }
        
        if (executionTimeNanos != null) {
            sb.append('[').append(duration(executionTimeNanos)).append(']');
        }
        
        if (totalTuples != null) {
            sb.append('[').append(totalTuples).append(']');
        }
        
        sb.append(' ');
        return sb.toString();
    }
    
    private static String duration(final long nanos) {
        final BigInteger nanosBI = BigInteger.valueOf(nanos);
        return nanosBI.divide(NANOS_IN_MILLIS) + "ms";
    }
    
    private static String formatLine(final String message, final int nestingLevel) {

        return "--".repeat(Math.max(0, nestingLevel)) + message;
    }
    
    private static void output(final String line, final boolean error) {
        
        System.out.println(line);
        if (error) {
            System.err.println(line);
        }
    }
    
    private static String abbreviateResourceName(final String resourceName) {

        if (resourceName == null) {
            return null;
        }

        if (resourceName.length() > 40) {
            return "..." + resourceName.substring(resourceName.length() - 37);
        }
        return resourceName;

    }

}
