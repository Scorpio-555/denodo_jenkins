package com.denodo.connect.testing.reporter;

import java.util.List;

import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestExecutorResult;

public class MultipleTestReporter implements ITestReporter {

    private final List<ITestReporter> testReporters;
    
    public MultipleTestReporter(List<ITestReporter> testReporters) {
        super();
        this.testReporters = testReporters;
    }

    @Override
    public void engineStart(final String resourceName, String failedTestsMetafilePath) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.engineStart(resourceName, failedTestsMetafilePath);
        }
    }

    @Override
    public void engineEnd(TestExecutorResult result, String createdMetafilePath) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.engineEnd(result, createdMetafilePath);
        }
    }

    @Override
    public void sequenceStart(int nestingLevel, String resourceName) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.sequenceStart(nestingLevel, resourceName);
        }
    }

    @Override
    public void sequenceEnd(int nestingLevel, String resourceName, TestExecutorResult result) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.sequenceEnd(nestingLevel, resourceName, result);
        }
    }

    @Override
    public void testStart(int nestingLevel, String resourceName, String testName) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.testStart(nestingLevel, resourceName, testName);
        }
    }

    @Override
    public void testEnd(int nestingLevel, String resourceName, String testName, String testDescription, ITestResult testResult,
            long executionTimeNanos, final Integer totalTuples) {
        for (ITestReporter testReporter : this.testReporters) {
            testReporter.testEnd(nestingLevel, resourceName, testName, testDescription, testResult, executionTimeNanos, totalTuples);
        }
    }

}
