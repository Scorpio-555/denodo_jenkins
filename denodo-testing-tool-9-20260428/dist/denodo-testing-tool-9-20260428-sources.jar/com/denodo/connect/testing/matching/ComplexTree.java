/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;


import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import jakarta.annotation.Nonnull;

/**
 * Represents a complex object (Array or Struct):
 * <p>
 *  - Each node of the tree can be a simple node or a complex node. 
 *  - A complex node is a head of a subtree and represents a complex structure inside the complex object.
 * <p>
 *  Example: [{'e1'}]
 * <p>
 *       Complex (Array)    Complex (Struct)    Simple
 *         [{'e1'}]     ->      {'e1'}     ->   e1
 *          
 */
public class ComplexTree implements Serializable, Comparable<ComplexTree> {

    @Serial
    private static final long serialVersionUID = 5243718308685945301L;
    
    private final ComplexTreeNode root;
    private DatePatterns datePatterns;
    private final ComplexTreeNodeComparator comparator;
    private final boolean ordered;


    public ComplexTree(final String root, final DatePatterns datePatterns, final boolean ordered) {
        
        this.root = new ComplexTreeNode(this, root);
        this.datePatterns = datePatterns;
        this.ordered = ordered;
        this.comparator = new ComplexTreeNodeComparator(datePatterns);
    }

    public ComplexTreeNode getRoot() {
        return this.root;
    }

    DatePatterns getDatePatterns() {
        return this.datePatterns;
    }

    public void updateDatePatterns(final DatePatterns patterns) {
        this.datePatterns = patterns;
    }
    
    public ComplexTreeNodeComparator getComparator() {
        return this.comparator;
    }
    
    public boolean isOrdered() {
        return this.ordered;
    }

    @Override
    public String toString() {
        return this.root.getValue().toString();
    }

    @Override
    public int compareTo(@Nonnull final ComplexTree other) {

        final DatePatterns patterns = chooseSortingOrComparingPattern(other);
        return this.getRoot().compare(other.getRoot(), patterns);
    }

    private DatePatterns chooseSortingOrComparingPattern(final ComplexTree other) {
        
        DatePatterns patterns;
        if (this.datePatterns instanceof SortingDatePatterns) {
            patterns = this.datePatterns;
        } else {
            // when comparing ComplexTree, we need patterns for the "other" ComplexTree,
            patterns = new DatePatterns(this.getDatePatterns().getResultDatePatterns(),
                    other.getDatePatterns().getExpectedDatePatterns());
        }
        
        return patterns;
    }
    


    @Override
    public int hashCode() {
        
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.root == null) ? 0 : this.root.hashCode());
        result = prime * result + ((this.datePatterns == null) ? 0 : this.datePatterns.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        
        final ComplexTree other = (ComplexTree) obj;
        if (this.root == null) {
            if (other.root != null)
                return false;
        } else if (!this.root.equals(other.root))
            return false;
        
        if (this.datePatterns == null) {
            return other.datePatterns == null;
        } else {
            return this.datePatterns.equals(other.datePatterns);
        }
    }



    public static class ComplexTreeNode implements Serializable  {

        @Serial
        private static final long serialVersionUID = 2594148699911642133L;

        public enum Type {
            SIMPLE,
            COMPLEX
        }
        
        private final ComplexTree complexTree;
        private final Object value;
        private final List<ComplexTreeNode> children;
        private boolean sortedChildren;
        

        ComplexTreeNode(final ComplexTree complexTree, final Object value) {
            super();
            this.complexTree = complexTree;
            this.value = value;
            this.children = new ArrayList<>();
            this.sortedChildren = false;
        }

        public ComplexTreeNode addChild(final Object element) {
            
            final ComplexTreeNode newNode = new ComplexTreeNode(this.complexTree, element);
            this.children.add(newNode);
            
            return newNode;
        }

        public Object getValue() {
            return this.value;
        }

        public List<ComplexTreeNode> getChildren() {
            return this.children;
        }

        public Type getType() {
            return this.children.isEmpty() ? Type.SIMPLE : Type.COMPLEX;
        }
        
        public boolean isOrdered() {
            return this.complexTree.isOrdered();
        }
        
        public ComplexTreeNodeComparator getComparator() {
            return this.complexTree.getComparator();
        }
        
        private boolean notSortedChildren() {
            return !this.sortedChildren;
        }

        private void setSortedChildren() {
            this.sortedChildren = true;
        }
        
        public int compare(final ComplexTreeNode o, final DatePatterns datePattern) {
            
            final boolean isOrdered = this.isOrdered() && o.isOrdered();
            
            if (Type.SIMPLE.equals(this.getType())) {
                if (Type.COMPLEX.equals(o.getType())) {
                    // We are considering a complex object is greater than a simple object
                    return -1;
                }
                
                // Both are leaves, simple objects. Compare them.
                return DataComparator.compare(this.getValue(), o.getValue(), datePattern, false, false);
            
            } else if (Type.SIMPLE.equals(o.getType())) {
                // We are considering a complex object is greater than a simple object
                return 1;
            } else {
                
                // Both are complex
                
                // Short circuit:
                // Each complex node has its value as string. This string is a representation of the complex structure that it contains. 
                // First, try to compare the value as string in case they are equal, it means that both subtrees are equal
                if (this.getValue().equals(o.getValue())) {
                    return 0;
                }

                if (!isOrdered) {
                    // Sort data to compare them ordered
                    if (this.notSortedChildren()) {
                        this.getChildren().sort(this.getComparator());
                        this.setSortedChildren();
                    }
                    
                    if (o.notSortedChildren()) {
                        o.getChildren().sort(this.getComparator());
                        o.setSortedChildren();
                    }
                }

                final Iterator<ComplexTreeNode> thisChildren = this.getChildren().iterator();
                final Iterator<ComplexTreeNode> otherChildren = o.getChildren().iterator();
                int i = 0;
                while (thisChildren.hasNext() && otherChildren.hasNext()) {
                    
                    // Elements are already in the order that we need to compare
                    final int result = thisChildren.next().compare(otherChildren.next(), datePattern);
                    if (result != 0) {
                        return result;
                    }
                    i++;
                }
                
                if (i < this.getChildren().size()) {
                    // "this" contains "o" but "this" has more elements
                    return 1;
                } else if (i < o.getChildren().size()) {
                    // "this" contains "o" but "o" has more elements
                    return -1;
                }

            }
            return 0;
            
            
        }
        
        @Override
        public String toString() {
            return getValue().toString();
        }


        @Override
        public int hashCode() {
            
            final int prime = 31;
            int result = 1;
            result = prime * result + ((this.children == null) ? 0 : this.children.hashCode());
            result = prime * result + ((this.value == null) ? 0 : this.value.hashCode());
            return result;
        }

        @Override
        public boolean equals(final Object obj) {
            
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            
            final ComplexTreeNode other = (ComplexTreeNode) obj;
            if (this.children == null) {
                if (other.children != null)
                    return false;
            }
            
            if (this.value == null) {
                return other.value == null;
            } else {
                return this.value.equals(other.value);

            }
        }
    }
    
    public static class ComplexTreeNodeComparator implements Comparator<ComplexTreeNode> {

        private DatePatterns datePatterns;
        
        public ComplexTreeNodeComparator(final DatePatterns datePatterns) {
            // for sorting operations a SortingDatePatters is required, so we need to assure it
            ensureSortingDatePatterns(datePatterns);
        }

        private void ensureSortingDatePatterns(final DatePatterns patterns) {
            
            if (patterns instanceof SortingDatePatterns) {
                this.datePatterns = patterns;
            } else {
                this.datePatterns = new SortingDatePatterns(patterns.getResultDatePatterns());
            }
        }
        
        @Override
        public int compare(final ComplexTreeNode complexNode1, final ComplexTreeNode complexNode2) {
            return complexNode1.compare(complexNode2, this.datePatterns);
        }

    }

}
