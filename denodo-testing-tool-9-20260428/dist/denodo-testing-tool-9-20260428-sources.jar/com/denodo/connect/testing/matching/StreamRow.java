/*
 * Copyright (c) 2026. DENODO Technologies.
 * http://www.denodo.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of DENODO
 * Technologies ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with DENODO.
 */
package com.denodo.connect.testing.matching;

import java.io.ObjectInputStream;
import java.util.List;

/**
 * Helper record that links a data row to its origin stream. Used by the priority queue during the merge phase to read
 * the next row from the correct chunk.
 */
record StreamRow(List<Object> row, ObjectInputStream stream) {

}
