/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Equator;
import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.Configuration;
import com.denodo.connect.testing.engine.IDataSet;
import com.denodo.connect.testing.engine.ITestResult;
import com.denodo.connect.testing.engine.TestResult;
import com.denodo.connect.testing.engine.qualifier.ExceptionProcessor;
import com.denodo.connect.testing.engine.qualifier.StandardQualifiers;
import com.denodo.connect.testing.util.ComplexTypeUtils;




public class StandardDataSetMatcher implements IDataSetMatcher {


    private final int maxRowsInMemoryDuringMatching;
    private final String resultsDatePattern;


    public StandardDataSetMatcher(final Configuration configuration) {
        super();
        this.maxRowsInMemoryDuringMatching = configuration.getMaxRowsInMemory();
        this.resultsDatePattern = configuration.getResultsDatePattern();
    }



    @Override
    public ITestResult match(final IDataSet resultDataSet, final IDataSet expectedDataSet) {

        Validate.notNull(resultDataSet, "Result Data Set cannot be null");
        Validate.notNull(expectedDataSet, "Expected Data Set cannot be null");

        /*
         * PHASE 1: Check if matching has to be done on error artifacts instead of data.
         */
        final Throwable resultThrowable = resultDataSet.getThrowable();
        final Throwable expectedThrowable = expectedDataSet.getThrowable();

        if (resultThrowable != null && expectedThrowable != null) {
            return matchThrowables(resultThrowable, expectedThrowable);
        }
        if (resultThrowable != null || expectedThrowable != null) {
            // One data set contained an exception, the other one didn't.

            if (expectedThrowable != null) {

                if (expectedThrowable instanceof ExceptionProcessor.MessageContainerException) {
                    return new TestResult(
                            false,
                            "Test was expected to throw an exception containing message \"" + expectedThrowable.getMessage() + "\", but no exception was raised instead.",
                            null /* No raised exception to be shown */);
                }

                // expectedException is not a mere message container

                return new TestResult(
                        false,
                        "Test was expected to throw an exception of class " + expectedThrowable.getClass().getName() + ", but no exception was raised instead.",
                        null /* No raised exception to be shown */);

            }

            // It's not that we were expecting an exception that didn't happen, but the opposite: an unexpected exception happened

            return new TestResult(
                    false,
                    "Test raised an unexpected " + resultThrowable.getClass().getName() + ": " + resultThrowable.getMessage(),
                    resultThrowable);

        }


        /*
         * PHASE 2: Check headers
         */

        final List<String> resultHeader = resultDataSet.getHeader();
        final List<String> expectedHeader = expectedDataSet.getHeader();

        if (!matchHeaders(resultHeader, expectedHeader)) {

            return new TestResult(
                    false,
                    "Expected data columns/headers do NOT match those returned by test after execution: expected [" + expectedHeader + "] " +
                        "but obtained [" + resultHeader + "].",
                    null /* no exception */);

        }

        // Might be returned as null if there is no need for it
        final int[] columnIndexTranslator = computeColumnIndexTranslator(resultHeader, expectedHeader);


        /*
         * PHASE 3: Check data
         */

        final boolean ordered = resultDataSet.isOrdered() || expectedDataSet.isOrdered();
        final DatePatterns datePatterns = new DatePatterns(this.resultsDatePattern, resultDataSet.getDatePatterns(), expectedDataSet.getDatePatterns());
        final boolean complexOrdered = resultDataSet.isComplexOrdered() && expectedDataSet.isComplexOrdered();

        return matchData(
                resultDataSet.getData(), expectedDataSet.getData(),
                expectedDataSet.getSetType(), datePatterns, columnIndexTranslator,
                ordered, this.maxRowsInMemoryDuringMatching, complexOrdered);

    }




    static ITestResult matchThrowables(final Throwable resultThrowable, final Throwable expectedThrowable) {

        if (resultThrowable instanceof ExceptionProcessor.TestEngineSyntheticException) {
            throw new IllegalArgumentException("Result throwable is an internal test engine synthetic exception, which is forbidden");
        }

        if (!(expectedThrowable instanceof ExceptionProcessor.TestEngineSyntheticException)) {
            throw new IllegalArgumentException("Result throwable is NOT an internal test engine synthetic exception, which is forbidden");
        }


        if (expectedThrowable instanceof ExceptionProcessor.ClassContainerException) {
            // We are matching by class name

            final Class<? extends Throwable> expectedThrowableClass = ((ExceptionProcessor.ClassContainerException)expectedThrowable).getContainedClass();

            Throwable examinedThrowable = resultThrowable;
            while (examinedThrowable != null && !expectedThrowableClass.isAssignableFrom(examinedThrowable.getClass())) {
                examinedThrowable = examinedThrowable.getCause();
            }

            // At the end, either we found a throwable mathing, or null
            if (examinedThrowable != null) {
                // OK, exceptions match

                return new TestResult(
                        true,
                        "Test raised an exception as expected. Expected " + expectedThrowableClass.getName() + " and the resulting exception was " + examinedThrowable.getClass().getName() + ": " + examinedThrowable.getMessage(),
                        null /* The test has gone OK, so there is no need to show an exception trace even if it was expected, as it would be confusing */);

            }

            // FAIL, Exceptions do NOT match

            return new TestResult(
                    false,
                    "Test raised an exception as expected, but this exception did NOT match the one expected. Expected " + expectedThrowableClass.getName() + " but the resulting exception was " + resultThrowable.getClass().getName() + ": " + resultThrowable.getMessage(),
                    resultThrowable /* We output the exception trace in order to compare with the expected one */);

        }

        // By now we already know expectedThrowable is a MessageContainerException

        final String expectedMessage = expectedThrowable.getMessage();

        if (resultThrowable.getMessage().contains(expectedMessage)) {
            // OK, the raised exception matches the expected message

            return new TestResult(
                    true,
                    "Test raised an exception with a message that matched the one expected. The resulting exception was " + resultThrowable.getClass().getName() + ": " + resultThrowable.getMessage(),
                    null /* No raised exception to be shown */);

        }

        // FAIL, the raised exception does not match the expected message

        return new TestResult(
                false,
                "Test raised an exception as expected, but the message of this exception did NOT match the expected message. Expected message was \"" + expectedMessage + "\" but the resulting exception was " + resultThrowable.getClass().getName() + ": " + resultThrowable.getMessage(),
                resultThrowable /* We output the exception trace in order to compare with the expected one */);

    }




    static boolean matchHeaders(final List<String> resultHeader, final List<String> expectedHeader) {

        if (resultHeader == null && expectedHeader == null) {
            // Both data sets have no headers, so we'll just compare in order
            return true;
        }
        if (resultHeader == null || expectedHeader == null) {
            // Only one is null, but there is not really anything to check against, so let's consider it a match
            return true;
        }

        // By now we know none of the header objects are null

        return CollectionUtils.isEqualCollection(resultHeader, expectedHeader, new Equator<String>() {
            @Override
            public boolean equate(final String o1, final String o2) {
                if (o1 == null && o2 == null) {
                    return true;
                }
                if (o1 == null || o2 == null) {
                    return false;
                }
                return o1.equalsIgnoreCase(o2);
            }

            @Override
            public int hash(final String o) {
                if (o == null) {
                    return 0;
                }
                return o.toLowerCase().hashCode();
            }
        });

    }



    static int[] computeColumnIndexTranslator(final List<String> resultHeader, final List<String> expectedHeader) {

        if (resultHeader == null || expectedHeader == null) {
            return null;
        }

        final int[] columnIndexTranslator = new int[resultHeader.size()];
        Arrays.fill(columnIndexTranslator, -1);

        for (int i = 0; i < resultHeader.size(); i++) {

            final String header1Item = resultHeader.get(i);

            for (int j = 0; j < expectedHeader.size() && columnIndexTranslator[i] == -1; j++) {
                if (header1Item.equalsIgnoreCase(expectedHeader.get(j))) {
                    columnIndexTranslator[i] = j;
                }
            }

            if (columnIndexTranslator[i] == -1) {
                // Given we have validated headers before, this should NEVER happen
                throw new IllegalStateException(
                        "Header conversion index not found for header: " + header1Item);
            }

        }

        return columnIndexTranslator;

    }




    static ITestResult matchData(
            final Iterator<List<Object>> resultDataIter, final Iterator<List<Object>> expectedDataIter,
            final StandardQualifiers.StandardSetTypes exptectedSetType, final DatePatterns datePatterns,
            final int[] columnIndexTranslator, final boolean ordered,
            final int maxRowsInMemoryDuringMatching, final boolean complexOrdered) {


        if (resultDataIter == null && expectedDataIter == null) {
            // Both are null, consider this a match
            return new TestResult(
                    true,
                    "Results matched (both results were null)",
                    null /* No raised exception to be shown */);
        }

        if (resultDataIter == null) {
            // Only one of them is null, therefore not a match
            return new TestResult(
                    false,
                    "Obtained results were null, but expected results are NOT null",
                    null /* No raised exception to be shown */);
        }
        if (expectedDataIter == null) {
            // Only one of them is null, therefore not a match
            return new TestResult(
                    false,
                    "Expected results were null, but obtained results are NOT null",
                    null /* No raised exception to be shown */);
        }


        // At this point, we know both resultDataIter and expectedDataIter are not null

        return (ordered?
                matchOrderedData(resultDataIter, expectedDataIter, exptectedSetType, datePatterns, columnIndexTranslator, complexOrdered) :
                matchUnorderedData(resultDataIter, expectedDataIter, exptectedSetType, datePatterns, columnIndexTranslator, maxRowsInMemoryDuringMatching, complexOrdered));

    }





    static ITestResult matchOrderedData(
            final Iterator<List<Object>> resultDataIter, final Iterator<List<Object>> expectedDataIter,
            final StandardQualifiers.StandardSetTypes expectedSetType, final DatePatterns datePatterns,
            final int[] columnIndexTranslator, final boolean complexOrdered) {

        // At this point, we know both resultDataIter and expectedDataIter are not null

        int resultCounter = 0;
        int expectedCounter = 0;

        final boolean resultsMustBeExact = StandardQualifiers.StandardSetTypes.FULL == expectedSetType;

        boolean advanceResults = true;
        boolean advanceExpected = true;
        List<Object> rowResult = null;
        List<Object> rowExpected = null;
        int column;

        while (resultDataIter.hasNext() && expectedDataIter.hasNext()) {


            if (advanceResults) {
                rowResult = resultDataIter.next();
                resultCounter++;
            }
            if (advanceExpected) {
                rowExpected = expectedDataIter.next();
                expectedCounter++;
            }


            if (rowResult == null || rowExpected == null) {
                throw new IllegalArgumentException("Data iterator returned null row, which is forbidden");
            }

            if (rowResult.size() != rowExpected.size()) {
                // This can happen if we headers were null and we could not match them. In any case, it means
                // that data sets do not match.

                return new TestResult(
                        false,
                        "Number of columns in expected data does NOT match those returned by test after execution: expected " + rowExpected.size() + " columns, " +
                                "but obtained " + rowResult.size() + ".",
                        null /* no exception */);

            }

            int dataFieldComparison = 0;
            Object objResult = null;
            Object objExpected = null;
            for (column = 0; column < rowResult.size(); column++) {

                objResult = rowResult.get(column);
                // Columns might not be ordered, so we might need to translate positions from data1 to data2
                objExpected = (columnIndexTranslator == null? rowExpected.get(column) : rowExpected.get(columnIndexTranslator[column]));

                datePatterns.resetCurrentDatePatterns();
                dataFieldComparison = DataComparator.compare(objResult, objExpected, datePatterns, complexOrdered, false);

                if (dataFieldComparison == 0) {
                    // OK, these match, so just try the next one
                    continue;
                }

                // Objects didn't match

                if (resultsMustBeExact) {
                    // Match failed. Results must be exact so advancing any of the result iterators to search
                    // a second match opportunity makes no sense

                    final String objResultStr = getStringRepresentationInErrors(objResult, datePatterns);
                    final String objExpectedStr = getStringRepresentationInErrors(objExpected, datePatterns);

                    return new TestResult(
                            false,
                            "Row " + resultCounter + ", col " + (column + 1) + " of the obtained result contained " +
                                    "[" + objResultStr + "], but [" + objExpectedStr + "] " +
                                    "was expected at that position.",
                            null /* no exception */);

                }

                break;

            }


            if (dataFieldComparison != 0) {
                // We ended the iteration of the columns, but because not all columns matched. And this could be
                // OK if we are looking for subsets or supersets, so we will try to search a new match by
                // advancing the iterator that produced the row lowest in order of the two (we will use the last
                // dataFieldComparison value for that).

                if (dataFieldComparison < 0 && StandardQualifiers.StandardSetTypes.SUBSET.equals(expectedSetType)) {
                    // results are lower than expected, advance results

                    advanceResults = true;
                    advanceExpected = false;

                } else if (dataFieldComparison > 0 && StandardQualifiers.StandardSetTypes.SUPERSET.equals(expectedSetType)) {
                    // results are higher than expected, advance expected

                    advanceResults = false;
                    advanceExpected = true;

                } else {

                    // Match failed. We needed a subset or superset, but we can confirm now that it is impossible to
                    // obtain a match because the lowest row (according to compared order) is the wrong one, so advancing
                    // any iterators would be wrong.

                    final String objResultStr = getStringRepresentationInErrors(objResult, datePatterns);
                    final String objExpectedStr = getStringRepresentationInErrors(objExpected, datePatterns);

                    return new TestResult(
                            false,
                            "Row " + resultCounter + ", col " + (column + 1) + " of the obtained result contained " +
                                    "[" + objResultStr + "], but [" + objExpectedStr + "] " +
                                    "was expected at that position.",
                            null /* no exception */);
                }

            } else {
                // Matching went smoothly for this row, so we just need to advance both iterators

                advanceResults = true;
                advanceExpected = true;

            }

        }

        if (resultDataIter.hasNext()) {
            // The result data set might have more data, so we will be fine if the expected data set has been specified to be a
            // SUBSET of the results. And should fail otherwise.


            // We need to traverse the entire iterator, not only to determine its size, but also to allow the
            // iterator to close its resources when a final 'hasNext()' call is made and no more elements exist.
            while (resultDataIter.hasNext()) {
                resultDataIter.next();
                resultCounter++;
            }


            if (StandardQualifiers.StandardSetTypes.SUBSET.equals(expectedSetType)) {

                return new TestResult(
                        true,
                        "Obtained and expected results (subset) match.",
                        null /* no exception */);

            }

            return new TestResult(
                    false,
                    "Expected results are only a subset of the obtained data set. Obtained " + resultCounter + " rows, " +
                            "but expected " + expectedCounter + ".",
                    null /* no exception */);

        }


        if (expectedDataIter.hasNext()) {
            // The expected data set might have more data, so we will be fine if the expected data set has been specified to be a
            // SUPERSET of the results. And should fail otherwise.

            // We need to traverse the entire iterator, not only to determine its size, but also to allow the
            // iterator to close its resources when a final 'hasNext()' call is made and no more elements exist.
            while (expectedDataIter.hasNext()) {
                expectedDataIter.next();
                expectedCounter++;
            }


            if (StandardQualifiers.StandardSetTypes.SUPERSET.equals(expectedSetType)) {

                return new TestResult(
                        true,
                        "Obtained and expected results (superset) match.",
                        null /* no exception */);

            }

            return new TestResult(
                    false,
                    "Obtained results do not match the expected result data set. Execution " +
                            "obtained " + resultCounter + " rows, but some of the " +
                            "expected " + expectedCounter + " rows were not found among " +
                            "the results. If you are sure all rows are contained, check the setting of " +
                            "the 'ordered' context property in your %RESULTS directive.",
                    null /* no exception */);

        }


        /*
         * Everything matched OK! Just report it.
         */

        if (StandardQualifiers.StandardSetTypes.SUBSET.equals(expectedSetType)) {

            return new TestResult(
                    true,
                    "Obtained and expected results (subset) match.",
                    null /* no exception */);

        }

        if (StandardQualifiers.StandardSetTypes.SUPERSET.equals(expectedSetType)) {

            return new TestResult(
                    true,
                    "Obtained and expected results (superset) match.",
                    null /* no exception */);

        }

        return new TestResult(
                true,
                "Obtained and expected results match.",
                null /* no exception */);

    }




    static ITestResult matchUnorderedData(
            final Iterator<List<Object>> resultDataIter, final Iterator<List<Object>> expectedDataIter,
            final StandardQualifiers.StandardSetTypes expectedSetType, final DatePatterns datePatterns,
            final int[] columnIndexTranslator, final int maxRowsInMemoryDuringMatching, final boolean complexOrdered) {

        // We need to know which columns are complex in order to get the representation in case expectedData is csv or data
        final List<Integer> columnIndexComplex = new ArrayList<>();
        
        // We will apply the column index translator during the ordering of the expected dataset, so that it is ordered according to the order of columns in which it will be matched

        final SortingDatePatterns resultDatePatterns = new SortingDatePatterns(datePatterns.getResultDatePatterns());
        final SortingDatePatterns expectedDatePatterns = new SortingDatePatterns(datePatterns.getExpectedDatePatterns());
        
        final Iterator<List<Object>> orderedResultDataIter = DataSetSorter.sort(resultDataIter, maxRowsInMemoryDuringMatching, resultDatePatterns, null, complexOrdered, columnIndexComplex);
        final Iterator<List<Object>> orderedExpectedDataIter = DataSetSorter.sort(expectedDataIter, maxRowsInMemoryDuringMatching, expectedDatePatterns, columnIndexTranslator, complexOrdered, columnIndexComplex);

        return matchOrderedData(orderedResultDataIter, orderedExpectedDataIter, expectedSetType, datePatterns, null, complexOrdered);

    }



    static String getStringRepresentationInErrors(final Object obj, final DatePatterns datePatterns) {

        // This method is meant to show objects in errors with meaningful representations, so that not only they
        // allow the user to spot the error, but also to locate the offending piece of data in the sources.

        if (obj == null) {
            return "null";
        }

        if (DataComparator.isClassDateish(obj.getClass())) {
            if (obj instanceof Calendar) {
                return datePatterns.printDate((Calendar) obj, null);
            }
            if (obj instanceof Date) {
                return datePatterns.printDate((Date) obj, null);
            }
        }
        
        if (DataComparator.isClassComplexStructure(obj.getClass())) {
            return ComplexTypeUtils.convertComplexToString(obj);
        }

        return obj.toString();

    }



}