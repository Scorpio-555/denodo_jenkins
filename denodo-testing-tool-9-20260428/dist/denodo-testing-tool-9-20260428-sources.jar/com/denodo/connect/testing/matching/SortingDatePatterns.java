/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2018, Denodo Technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;

import java.util.Collection;

import com.denodo.connect.testing.Configuration;

public class SortingDatePatterns extends DatePatterns {

    
    
    public SortingDatePatterns(final Collection<String> datePatterns) {
        super(datePatterns, datePatterns);
    }
    
    /**
     * When sorting data sets, we must use the same Date Pattern on all data sets (expected and results)
     * because later comparison between both data sets should be done with dates following the same order.
     * <p>
     * Selected date pattern is ISO860 because it includes all the date fields: from year to milliseconds, time zone included.  
     */
    @Override
    protected String getComparisonDatePattern() {        
        return Configuration.DEFAULT_RESULTS_DATE_PATTERN;
    }
}
