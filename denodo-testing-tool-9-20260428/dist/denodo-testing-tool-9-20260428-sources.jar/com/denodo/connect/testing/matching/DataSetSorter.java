/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.io.MemorySafeObjectOutputStream;
import com.denodo.connect.testing.util.ComplexTypeUtils;


class DataSetSorter {

    static final int IO_BUFFER_SIZE = 65536; // 64KB
    private static final Logger LOG = LoggerFactory.getLogger(DataSetSorter.class);

    private static final String TEMP_FILE_PREFIX = "denodotesting-temp-";
    private static final String TEMP_FILE_SUFFIX = ".data";

    private DataSetSorter() {
    }

    @SuppressWarnings("unchecked")
    static Iterator<List<Object>> sort(final Iterator<List<Object>> dataIter, final int maxRowsInMemoryDuringMatching,
            final DatePatterns datePatterns, final int[] columnIndexTranslator, final boolean complexOrdered,
            final List<Integer> columnIndexComplex) {

        boolean sortingDone = false;
        final Set<File> allFiles = new HashSet<>(10); // We'll use this to make sure we delete ALL files we create, even in the case of an exception
        final List<File> chunkFiles = new ArrayList<>(10);
        final RowComparator rowComparator = new RowComparator(datePatterns, complexOrdered, columnIndexComplex);

        long globalStartTime = System.currentTimeMillis();

        try {

            ArrayList<ArrayList<Object>> chunk;
            while (!(chunk = readSortedChunkOfData(dataIter, maxRowsInMemoryDuringMatching, rowComparator, columnIndexTranslator, complexOrdered, columnIndexComplex, datePatterns)).isEmpty()) {

                if (!dataIter.hasNext() && chunkFiles.isEmpty()) {
                    // No need to use disk at all! We were able to sort everything in memory in just one chunk!
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("All data fit in memory. Sorted without using disk chunks.");
                    }
                    return (Iterator<List<Object>>)(Iterator<?>) chunk.iterator();
                }

                writeChunkToDisk(chunk, allFiles, chunkFiles);
            }

            // If we got here, it's because we need to perform the merging of at least two files
            if (chunkFiles.size() > 1) {
                if (LOG.isDebugEnabled()) {
                    long chunkingTime = System.currentTimeMillis() - globalStartTime;
                    LOG.debug("Finished reading and chunking data. Total chunks: {}. Time elapsed: {} ms.",
                        chunkFiles.size(), chunkingTime);
                    LOG.debug("Starting K-Way Merge Sort phase.");
                }

                long mergeStartTime = System.currentTimeMillis();
                final File finalMergedFile = performKWayMerge(chunkFiles, rowComparator, allFiles);
                chunkFiles.clear();
                chunkFiles.add(finalMergedFile);

                if (LOG.isInfoEnabled()) {
                    long totalMergeTime = System.currentTimeMillis() - mergeStartTime;
                    long totalTime = System.currentTimeMillis() - globalStartTime;
                    LOG.info("Finished K-Way Merge Sort. Merge time: {} ms. Total sort time: {} ms.", totalMergeTime,
                        totalTime);
                }
            }

            sortingDone = true;

            /*
             * Create iterator on the file data. We know that, at this point, there is only one file remaining containing
             * all the ordered data.
             */
            if (chunkFiles.isEmpty()) {
                return Collections.emptyIterator();
            }
            return new SortedDataIterator(chunkFiles.get(0));

        } finally {
            // We make sure we've cleaned up everything
            cleanupFiles(sortingDone, chunkFiles, allFiles);
        }
    }

    private static void cleanupFiles(final boolean sortingDone, final List<File> chunkFiles, final Set<File> allFiles) {
        if (sortingDone && !chunkFiles.isEmpty()) {
            // If we sorted everything, we don't want to delete the final result file
            allFiles.remove(chunkFiles.get(0));
        }

        for (final File file : allFiles) {
            deleteFileQuietly(file);
        }
    }

    private static void writeChunkToDisk(final ArrayList<ArrayList<Object>> chunk, final Set<File> allFiles,
        final List<File> chunkFiles) {
        try {
            final File chunkFile = File.createTempFile(TEMP_FILE_PREFIX, TEMP_FILE_SUFFIX);
            chunkFile.deleteOnExit();
            allFiles.add(chunkFile);

            try (FileOutputStream chunkFileOutputStream = new FileOutputStream(chunkFile);
                BufferedOutputStream bufferedChunkOutputStream = new BufferedOutputStream(chunkFileOutputStream,
                    IO_BUFFER_SIZE);
                ObjectOutputStream chunkObjectOutputStream = new ObjectOutputStream(bufferedChunkOutputStream);
                MemorySafeObjectOutputStream memorySafeObjectOutputStream = new MemorySafeObjectOutputStream(
                    chunkObjectOutputStream)) {

                for (final ArrayList<Object> chunkRow : chunk) {
                    memorySafeObjectOutputStream.writeObject(chunkRow);
                }

                if (LOG.isDebugEnabled()) {
                    LOG.debug("Created temporary chunk file for sorting: {}. Total chunks generated: {}",
                        chunkFile.getName(), (chunkFiles.size() + 1));
                }
            }
            chunkFiles.add(chunkFile);
        } catch (final Exception e) {
            throw new TestExecutionException("Cannot create temporary resources for ordering unordered data", e);
        }
    }

    /**
     * Performs a K-Way Merge Sort using a PriorityQueue to combine multiple sorted chunks into a single sorted file.
     */
    @SuppressWarnings("java:S2093")
    private static File performKWayMerge(final List<File> chunkFiles, final RowComparator rowComparator,
        final Set<File> allFiles) {

        try {
            final File finalMergedFile = File.createTempFile(TEMP_FILE_PREFIX, TEMP_FILE_SUFFIX);
            finalMergedFile.deleteOnExit();
            allFiles.add(finalMergedFile);

            try (FileOutputStream finalFileOutputStream = new FileOutputStream(finalMergedFile);
                BufferedOutputStream bufferedFinalOutputStream = new BufferedOutputStream(finalFileOutputStream,
                    IO_BUFFER_SIZE);
                ObjectOutputStream oos = new ObjectOutputStream(bufferedFinalOutputStream);
                MemorySafeObjectOutputStream memorySafeObjectOutputStream = new MemorySafeObjectOutputStream(oos)) {

                final PriorityQueue<StreamRow> priorityQueue = new PriorityQueue<>(chunkFiles.size(),
                    (sr1, sr2) -> rowComparator.compare(sr1.row(), sr2.row()));

                // We keep track of open streams to ensure they are properly closed in the finally block
                final List<ObjectInputStream> openStreams = new ArrayList<>(chunkFiles.size());

                try {
                    // Read the first row of each chunk and put it in the priority queue
                    for (final File chunkFile : chunkFiles) {
                        // The stream is intentionally kept open and managed via the openStreams list.
                        final ObjectInputStream ois = new ObjectInputStream(
                            new BufferedInputStream(new FileInputStream(chunkFile), IO_BUFFER_SIZE));
                        openStreams.add(ois);
                        readRowAndAddToQueue(ois, priorityQueue);
                    }

                    // 2. Extract the smallest element and read the next one from its origin stream
                    while (!priorityQueue.isEmpty()) {
                        final StreamRow min = priorityQueue.poll();
                        memorySafeObjectOutputStream.writeObject(min.row());
                        readRowAndAddToQueue(min.stream(), priorityQueue);
                    }
                } finally {
                    // Ensure all streams are closed
                    for (final ObjectInputStream ois : openStreams) {
                        closeQuietly(ois);
                    }
                }
            }
            return finalMergedFile;

        } catch (final IOException | ClassNotFoundException e) {
            throw new TestExecutionException("Error during K-Way Merge process", e);
        }

    }

    @SuppressWarnings("unchecked")
    private static void readRowAndAddToQueue(final ObjectInputStream stream,
        final PriorityQueue<StreamRow> priorityQueue) throws IOException, ClassNotFoundException {
        try {
            final List<Object> row = (List<Object>) stream.readObject();
            priorityQueue.add(new StreamRow(row, stream));
        } catch (final EOFException ignored) {
            // The chunk has been fully consumed or was empty from the start
            closeQuietly(stream);
        }
    }


    static ArrayList<ArrayList<Object>> readSortedChunkOfData(final Iterator<List<Object>> dataIter, final int maxRowsInMemory,
            final RowComparator rowComparator, final int[] columnIndexTranslator, final boolean complexOrdered,
            final List<Integer> columnIndexComplex, final DatePatterns datePatterns) {

        final ArrayList<ArrayList<Object>> chunk = new ArrayList<>(100); // The array for the first list are just refs, so no big deal in setting 100 and then being many more

        int rowCount = 0;
        while (dataIter.hasNext() && rowCount < maxRowsInMemory) {
            ArrayList<Object> row = ensureSerialization(dataIter.next(), complexOrdered, datePatterns);
            row = applyColumnOrdering(row, columnIndexTranslator);
            getColumnIndexComplex(row, columnIndexComplex);
            chunk.add(row);
            rowCount++;
        }

        chunk.sort(rowComparator);

        return chunk;

    }




    static ArrayList<Object> ensureSerialization(final List<Object> row, final boolean complexOrdered, final DatePatterns datePatterns) {

        boolean allSerializable = true;
        final int rowLen = row.size();
        for (final Object cell : row) {
            if (cell != null && !(cell instanceof Serializable)) {
                allSerializable = false;
                break;
            }
        }

        if (allSerializable) {
            if (row instanceof ArrayList) {
                return (ArrayList<Object>)row;
            }
            return new ArrayList<>(row);
        }

        // We need to change some elements in the list, so we better ensure this List implementation is actually
        // modifiable by creating a new one.
        final ArrayList<Object> newRow = new ArrayList<>(row);

        for (int i = 0; i < rowLen; i++) {
            final Object cell = newRow.get(i);
            if (cell != null && !(cell instanceof Serializable)) {
                if (DataComparator.isClassComplexStructure(cell.getClass())) {
                    // We are serializing complex structures in this ComplexTree because
                    // this is the format in which they will be afterward compared for matching.

                    newRow.set(i, ComplexTypeUtils.convertComplexToComplexTree(cell, complexOrdered, datePatterns));
                    
                } else {
                    throw new TestExecutionException(
                            "Cannot serialize object of class " + cell.getClass().getName() + ". Unordered " +
                            "result matching is only supported for Serializable data types.");
                }
            }
        }

        return newRow;

    }


    static ArrayList<Object> applyColumnOrdering(final ArrayList<Object> row, final int... columnIndexTranslator) {

        if (columnIndexTranslator == null) {
            return row;
        }
        final ArrayList<Object> orderedRow = new ArrayList<>(row.size());
        final int rowLen = row.size();
        for (int i = 0; i < rowLen; i++) {
            orderedRow.add(row.get(columnIndexTranslator[i]));
        }
        return orderedRow;
    }

    static void getColumnIndexComplex(final ArrayList<Object> row, final List<Integer> columnIndexComplex) {
        
        final int rowLen = row.size();
        for (int i = 0; i < rowLen; i++) {
            if (row.get(i) != null && DataComparator.isClassComplexStructure(row.get(i).getClass())) {
                columnIndexComplex.add(i);
            }
        }
     
    }

    private static void closeQuietly(final AutoCloseable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (final Exception ignored) {
                // ignored
            }
        }
    }

    private static void deleteFileQuietly(final File file) {
        if (file != null) {
            try {
                Files.deleteIfExists(file.toPath());
            } catch (final Exception ignored) {
                // ignored
            }
        }


    }

    record RowComparator(DatePatterns datePatterns, boolean complexOrdered, List<Integer> columnIndexComplex) implements
        Comparator<List<Object>> {
        @Override
        public int compare(final List<Object> row1, final List<Object> row2) {
            return DataComparator.compare(row1, row2, this.datePatterns, this.complexOrdered, this.columnIndexComplex);
        }

    }
}