/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Array;
import java.sql.Struct;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.denodo.connect.testing.matching.DatePatterns.BadDateFormatException;
import com.denodo.connect.testing.util.ComplexTypeUtils;
import com.denodo.connect.testing.util.TextualData;


class DataComparator {

    @SuppressWarnings({"unchecked", "rawtypes"})
    static int compare(final Object obj1, final Object obj2, final DatePatterns datePatterns, final boolean complexOrdered, final boolean isComplex) {

        if (isBlank(obj1) && isBlank(obj2)) {
            return 0;
        }
        if (isBlank(obj1)) {
            return -1;
        }
        if (isBlank(obj2)) {
            return 1;
        }

        // First, we turn primitives into objects
        Object normalizedObj1 = normalizePrimitives(obj1);
        Object normalizedObj2 = normalizePrimitives(obj2);


        // Cache the original shapes of the compared objects (if they are TextualData or Strings) just in case we need to
        // compare again without normalization.
        final TextualData textualDataObj1 = (normalizedObj1 instanceof TextualData ? (TextualData) normalizedObj1 : null);
        final TextualData textualDataObj2 = (normalizedObj2 instanceof TextualData ? (TextualData) normalizedObj2 : null);
        final String stringObj1 = (normalizedObj1 instanceof String ? (String) normalizedObj1 : null);
        final String stringObj2 = (normalizedObj2 instanceof String ? (String) normalizedObj2 : null);


        // Now we make sure any TextualData (data represented as text which type is not known and might need to be
        // parsed as number/boolean) is normalized.
        final boolean expected = true;
        normalizedObj1 = normalizeTextualData(normalizedObj1, datePatterns, !expected);
        normalizedObj2 = normalizeTextualData(normalizedObj2, datePatterns, expected);


        // After normalizing TextualData, objects might have become null!
        if (normalizedObj1 == null && normalizedObj2 == null) {
            return 0;
        }
        if (normalizedObj1 == null) {
            return -1;
        }
        if (normalizedObj2 == null) {
            return 1;
        }


        // Compute the classes of both objects
        Class<?> normalizedObj1Class = normalizedObj1.getClass();
        Class<?> normalizedObj2Class = normalizedObj2.getClass();

        // We normalized the objects so that numeric values are compared disregarding their classes (e.g. long vs. int)
        normalizedObj1 = normalizeNumbers(normalizedObj1, normalizedObj1Class, normalizedObj2Class);
        normalizedObj2 = normalizeNumbers(normalizedObj2, normalizedObj1Class, normalizedObj2Class);

        // We obtain the completely-normalized classes being compared
        normalizedObj1Class = normalizedObj1.getClass();
        normalizedObj2Class = normalizedObj2.getClass();

        // We normalized the objects so that date values are compared disregarding their classes (e.g. long vs. int)
        normalizedObj1 = normalizeDates(normalizedObj1, normalizedObj1Class, normalizedObj2Class, datePatterns, !expected);
        normalizedObj2 = normalizeDates(normalizedObj2, normalizedObj1Class, normalizedObj2Class, datePatterns, expected);

        // Finally, we obtain the completely-normalized classes being compared
        normalizedObj1Class = normalizedObj1.getClass();
        normalizedObj2Class = normalizedObj2.getClass();

        // We normalized the objects so that complex (array,struct) objects can be compared
        normalizedObj1 = normalizeComplex(normalizedObj1, normalizedObj1Class, normalizedObj2Class, complexOrdered,
                datePatterns, isComplex);
        normalizedObj2 = normalizeComplex(normalizedObj2, normalizedObj1Class, normalizedObj2Class, complexOrdered,
                datePatterns, isComplex);

        // Finally, we obtain the completely-normalized classes being compared
        normalizedObj1Class = normalizedObj1.getClass();
        normalizedObj2Class = normalizedObj2.getClass();


        /*
         * First comparison attempt, including all normalizations (textual data + numeric)
         */
        if (normalizedObj1Class.isAssignableFrom(normalizedObj2Class) || normalizedObj2Class.isAssignableFrom(normalizedObj1Class)) {

            if (Comparable.class.isAssignableFrom(normalizedObj1Class) && Comparable.class.isAssignableFrom(normalizedObj2Class)) {

                if (normalizedObj1Class.isAssignableFrom(normalizedObj2Class)) {
                    return ((Comparable) normalizedObj1).compareTo(normalizedObj2);
                }
                
                return -1 * ((Comparable) normalizedObj2).compareTo(normalizedObj1);

            }
            
            if (isClassBinaryData(normalizedObj1Class) && isClassBinaryData(normalizedObj2Class)) {
                return Arrays.equals((byte[]) normalizedObj1, (byte[])normalizedObj2) ? 0 : -1;
            }

        }



        /*
         * Second comparison attempt, excluding TextualData normalization (and therefore numeric also) just in
         * case we shouldn't have normalized one of the objects in the first place.
         */
        if (((textualDataObj1 != null && !textualDataObj1.hasKnownType() && stringObj2 != null) ||
                (textualDataObj2 != null && !textualDataObj2.hasKnownType() && stringObj1 != null))) {

            // NOTE this comparisons only make sense one is normalized TextualData and the other is a String.
            // It shouldn't be applied if both are TextualData because in such case we could be ordering
            // numbers (expressed in a text-based medium like a CSV) by their alphabetical order, instead
            // of the numerical order.

            if (textualDataObj1 != null)  {
                return textualDataObj1.getValue().compareTo(stringObj2);
            }
            
            return stringObj1.compareTo(textualDataObj2.getValue());

        }


        // Object are not comparable, so we should be outputting a non-zero result in a consistent manner (using class names comparison)
        return normalizedObj1Class.getName().compareTo(normalizedObj2Class.getName());

    }

    private static boolean isBlank(final Object obj) {
        return obj == null || StringUtils.EMPTY.equals(obj.toString()) || isBlankTextualData(obj);
    }

    private static boolean isBlankTextualData(final Object obj) {
        return obj instanceof TextualData && ((TextualData) obj).isNull() || obj == null;
    }


    static int compare(final List<Object> row1, final List<Object> row2, final DatePatterns datePatterns, 
            final boolean complexOrdered, final List<Integer> columnIndexComplex) {

        if (row1 == null && row2 == null) {
            return 0;
        }
        if (row1 == null) {
            return -1;
        }
        if (row2 == null) {
            return 1;
        }

        final int sizeRow1 = row1.size();
        final int sizeRow2 = row2.size();

        if (sizeRow1 != sizeRow2) {
            throw new IllegalArgumentException(
                    "Cannot compare rows of different size: " + sizeRow1 + " vs. " + sizeRow2);
        }

        boolean isComplex;
        for (int i = 0; i < sizeRow1; i++) {
            final Object obj1 = row1.get(i);
            final Object obj2 = row2.get(i);
            isComplex = columnIndexComplex.contains(i);
            final int comparison = DataComparator.compare(obj1, obj2, datePatterns, complexOrdered, isComplex);
            if (comparison != 0) {
                return comparison;
            }
        }

        return 0;

    }





    private static Object normalizePrimitives(final Object obj) {

        final Class<?> objClass = obj.getClass();

        if (!objClass.isPrimitive()) {
            return obj;
        }

        final String objClassName = objClass.getName();
        final String objValue = String.valueOf(obj);

        if (boolean.class.getName().equals(objClassName)) {
            return Boolean.valueOf(objValue);
        }

        if (short.class.getName().equals(objClassName)) {
            return Short.valueOf(objValue);
        }

        if (int.class.getName().equals(objClassName)) {
            return Integer.valueOf(objValue);
        }

        if (long.class.getName().equals(objClassName)) {
            return Long.valueOf(objValue);
        }

        if (float.class.getName().equals(objClassName)) {
            return Float.valueOf(objValue);
        }

        if (double.class.getName().equals(objClassName)) {
            return Double.valueOf(objValue);
        }

        if (char.class.getName().equals(objClassName)) {
            return Character.valueOf((Character) obj);
        }

        throw new IllegalStateException(
                "Unrecognized primitive type during normalization: " + objClass.getName());

    }





    private static Object normalizeTextualData(final Object obj, final DatePatterns datePatterns, final boolean expected) {

        if (!TextualData.class.isAssignableFrom(obj.getClass())) {
            return obj;
        }

        final TextualData textualData = (TextualData)obj;
        final String value = textualData.getValue();

        if (value == null) {
            // Value is null, nothing to do with it!
            return null;
        }

        if (textualData.hasKnownType()) {

            final Class<?> knownType = textualData.getKnownType();

            if (String.class.equals(knownType)) {
                /*
                 * Try to parse as a Date
                 */
                try {
                    return datePatterns.parseDate(value, expected, null);
                } catch (final BadDateFormatException ignored) {
                    // nothing to do, it simply not a Date
                }
                return value; // No conversion to be done at all!
            }
            if (BigDecimal.class.equals(knownType)) {
                return new BigDecimal(value); // Note there is no support for locale-dependent decimal comma
            }
            if (BigInteger.class.equals(knownType)) {
                return new BigInteger(value);
            }
            if (Double.class.equals(knownType)) {
                return Double.valueOf(value);
            }
            if (Float.class.equals(knownType)) {
                return Float.valueOf(value);
            }
            if (Long.class.equals(knownType)) {
                return Long.valueOf(value);
            }
            if (Integer.class.equals(knownType)) {
                return Integer.valueOf(value);
            }
            if (Short.class.equals(knownType)) {
                return Short.valueOf(value);
            }
            if (Boolean.class.equals(knownType)) {
                return Boolean.valueOf(value);
            }
            if (Character.class.equals(knownType)) {
                if (value.isEmpty()) {
                    throw new IllegalArgumentException("Cannot convert to Character a zero-length string");
                }
                return value.charAt(0);
            }
            if (Calendar.class.equals(knownType)) {
                return datePatterns.parseDate(value, expected, null);
            }
            if (Date.class.equals(knownType)) {
                return datePatterns.parseDate(value, expected, null); // We will return Calendars in any case,
            }
            if (Timestamp.class.equals(knownType)) {
                return datePatterns.parseDate(value, expected, null); // We will return Calendars in any case
            }

            throw new IllegalArgumentException("Cannot convert to " + knownType + ": unknown conversion.");

        }

        /*
         *  First attempt at auto-conversion of object: let's see if it would be a valid number
         */
        if (areAllCharactersNumeric(value)) {

            if (areAllCharactersIntegerNumeric(value)) {
                try {
                    // It's an integer number. Default to BigInteger.
                    return new BigInteger(value);
                } catch (final NumberFormatException ignored) {
                    // nothing to do, it simply not a Number
                }
            }
            try {
                // This is a decimal number. Default to BigDecimal. Note there is no support for locale-dependent decimal comma.
                return new BigDecimal(value);
            } catch (final NumberFormatException ignored) {
                // nothing to do, it simply not a Number
            }
        }

        /*
         * Try to parse as boolean. Note we cannot directly use Boolean.valueOf because it will return Boolean.FALSE
         * for everything except the "true" string.
         */
        if ("true".equals(value) || "false".equals(value)) {
            return Boolean.valueOf(value);
        }

        /*
         * Try to parse as a Date
         */
        try {
            return datePatterns.parseDate(value, expected, null);
        } catch (final BadDateFormatException ignored) {
            // nothing to do, it simply not a Date
        }

        /*
         * Nothing to do with complex structures... we will be comparing them as Strings, and we don't need to normalize
         * them at all!
         */


        /*
         * We don't really know what else to do with this piece of data, so we just return it as String.
         */
        return value;

    }



    private static boolean areAllCharactersNumeric(final String text) {
        
        char c;
        int n = text.length();
        if (n == 0) {
            return false;
        }
        
        int i = 0;
        while (n-- != 0) {
            c = text.charAt(i);
            if ((c < '0' || c > '9') && c != '.' && !(i == 0 && c == '-')) {
                return false;
            }
            i++;
        }
        return true;
    }

    private static boolean areAllCharactersIntegerNumeric(final String text) {

        char c;
        int n = text.length();
        if (n == 0) {
            return false;
        }

        int i = 0;
        while (n-- != 0) {
            c = text.charAt(i++);
            if ((c < '0' || c > '9') && !(i == 0 && c == '-')) {
                return false;
            }
        }
        return true;
    }



    private static Object normalizeNumbers(final Object obj, final Class<?> class1, final Class<?> class2) {

        if (class1.equals(class2)) {
            return obj;
        }

        if (!isClassNumeric(class1) || !isClassNumeric(class2)) {
            // They are not both numbers, so there's nothing we can do
            return obj;
        }

        /*
         * In order to be more memory-efficient, if BOTH classes are numeric integers (short, int, long, BigInteger)
         * we will normalize to the smallest class possible (the biggest of class1 and class2).
         *
         * In any other case, we will normalize to BigDecimal.
         */
        if (isClassNumericInteger(class1) && isClassNumericInteger(class2)) {

            if (BigInteger.class.equals(class1) || BigInteger.class.equals(class2)) {
                // Normalize to BigInteger
                if (BigInteger.class.equals(obj.getClass())) {
                    return obj;
                }
                if (Long.class.equals(obj.getClass())) {
                    return BigInteger.valueOf((Long) obj);
                }
                if (Integer.class.equals(obj.getClass())) {
                    return BigInteger.valueOf(((Integer)obj).longValue());
                }
                if (Short.class.equals(obj.getClass())) {
                    return BigInteger.valueOf(((Short)obj).longValue());
                }
                throw new IllegalStateException(
                        "Class was classified as numeric but cannot be recognized: " + obj.getClass().getName());
            }

            if (Long.class.equals(class1) || Long.class.equals(class2)) {
                // Normalize to Long
                if (Long.class.equals(obj.getClass())) {
                    return obj;
                }
                if (Integer.class.equals(obj.getClass())) {
                    return ((Integer) obj).longValue();
                }
                if (Short.class.equals(obj.getClass())) {
                    return ((Short) obj).longValue();
                }
                throw new IllegalStateException(
                        "Class was classified as numeric but cannot be recognized: " + obj.getClass().getName());
            }

            if (Integer.class.equals(class1) || Integer.class.equals(class2)) {
                // Normalize to Integer
                if (Integer.class.equals(obj.getClass())) {
                    return obj;
                }
                if (Short.class.equals(obj.getClass())) {
                    return ((Short) obj).intValue();
                }
                throw new IllegalStateException(
                        "Class was classified as numeric but cannot be recognized: " + obj.getClass().getName());
            }

            if (Short.class.equals(class1) || Short.class.equals(class2)) {
                // Normalize to Short
                if (Short.class.equals(obj.getClass())) {
                    return obj;
                }
                throw new IllegalStateException(
                        "Class was classified as numeric but cannot be recognized: " + obj.getClass().getName());
            }

            throw new IllegalStateException(
                    "Classes were classified as numeric but cannot be recognized: " + class1.getName() + " and " + class2.getName());

        }

        // At least one is a non-integer, so we will normalize everything to BigDecimal

        if (BigDecimal.class.equals(obj.getClass())) {
            return obj;
        }
        if (BigInteger.class.equals(obj.getClass())) {
            return new BigDecimal((BigInteger)obj);
        }
        if (Double.class.equals(obj.getClass())) {
            return BigDecimal.valueOf(((Double)obj).doubleValue());
        }
        if (Float.class.equals(obj.getClass())) {
            // BigDecimal can only be created from a double input, but turning a float into a double
            // with e.g. "Float#doubleValue()" will produce precision issues as the new decimal digits
            // (second byte) will not be totally zeroed.
            return new BigDecimal(((Float)obj).toString());
        }
        if (Long.class.equals(obj.getClass())) {
            return BigDecimal.valueOf(((Long)obj).longValue());
        }
        if (Integer.class.equals(obj.getClass())) {
            return BigDecimal.valueOf(((Integer)obj).longValue());
        }
        if (Short.class.equals(obj.getClass())) {
            return BigDecimal.valueOf(((Short)obj).longValue());
        }
        throw new IllegalStateException(
                "Class was classified as numeric but cannot be recognized: " + obj.getClass().getName());

    }




    private static boolean isClassNumeric(final Class<?> clazz) {
        return isClassNumericInteger(clazz) || isClassNumericDecimal(clazz);
    }

    private static boolean isClassNumericInteger(final Class<?> clazz) {
        return Integer.class.isAssignableFrom(clazz) || Long.class.isAssignableFrom(clazz) ||
                BigInteger.class.isAssignableFrom(clazz) || Short.class.isAssignableFrom(clazz);
    }

    private static boolean isClassNumericDecimal(final Class<?> clazz) {
        return Float.class.isAssignableFrom(clazz) || Double.class.isAssignableFrom(clazz) ||
                BigDecimal.class.isAssignableFrom(clazz);
    }
    



    private static Object normalizeDates(final Object obj, final Class<?> class1, final Class<?> class2,
            final DatePatterns datePatterns, final boolean expected) {


        if (isClassDateish(class1) && isClassDateish(class2)) {
            // Both are date-ish, convert both!
            return datePatterns.convertDateToString(obj);
        }

        if ((isClassDateish(class1) && String.class.equals(class2)) ||
                (String.class.equals(class1) && isClassDateish(class2))) {
            
            
            
            if (obj instanceof String) {
                // We perform a two-direction conversion in order to normalize the format, because the date,
                // even if specified in ISO6801 format, may have been only a partial specification (e.g. only
                // YYY-MM-DD and no time).
                try {
                    return datePatterns.convertDateToString(datePatterns.parseDate((String)obj, expected, null));
                } catch (final BadDateFormatException ignored) {
                    // nothing to do, it simply not a Date
                    return obj;
                }
            }
            return datePatterns.convertDateToString(obj);
        }
        
        // We try to get a date even when both objects are strings because 
        // it may be a normalization in order to sort rows and strings may be dates
        if (String.class.equals(class1) && String.class.equals(class2)) {
            try {
                return  datePatterns.convertDateToString(datePatterns.parseDate((String)obj, expected, null));
            } catch (final BadDateFormatException ignored) {
                // nothing to do, it simply not a Date
            } 
        }

        return obj; // Date normalization not possible

    }


    static boolean isClassDateish(final Class<?> clazz) {
        return Date.class.isAssignableFrom(clazz) || java.sql.Date.class.isAssignableFrom(clazz) ||
                Calendar.class.isAssignableFrom(clazz) || Timestamp.class.isAssignableFrom(clazz);
    }

    private static Object normalizeComplex(final Object obj, final Class<?> class1, final Class<?> class2, 
            final boolean complexOrdered, final DatePatterns datePatterns, final boolean isComplex) {

        if (isClassComplexStructure(class1) && isClassComplexStructure(class2)) {
            // Both are complex, convert both!
            
            // This complex tree allow the comparison between complex objects
            return ComplexTypeUtils.convertComplexToComplexTree(obj, complexOrdered, datePatterns);
        }

        if ((isClassComplexStructure(class1) && String.class.equals(class2)) ||
                (String.class.equals(class1) && isClassComplexStructure(class2))) {

            if (obj instanceof String) {
                // This complex tree allow the comparison between complex objects
                return ComplexTypeUtils.convertComplexStringToComplexTree((String)obj, complexOrdered, datePatterns);
            }
            
            return ComplexTypeUtils.convertComplexToComplexTree(obj, complexOrdered, datePatterns);
        }

        // It is a complex object as string but it should be a complex tree in order to sort rows
        if (String.class.equals(class1) && String.class.equals(class2) && isComplex) {

            return ComplexTypeUtils.convertComplexStringToComplexTree((String)obj, complexOrdered, datePatterns);
        }
        
        return obj; // Date normalization not possible

    }


    static boolean isClassComplexStructure(final Class<?> clazz) {
        return Array.class.isAssignableFrom(clazz) || List.class.isAssignableFrom(clazz) 
                || Struct.class.isAssignableFrom(clazz) || Object[].class.isAssignableFrom(clazz) 
                || ComplexTree.class.isAssignableFrom(clazz);
    }


    private static boolean isClassBinaryData(final Class<?> clazz) {
        return byte[].class.isAssignableFrom(clazz);
    }
    
}