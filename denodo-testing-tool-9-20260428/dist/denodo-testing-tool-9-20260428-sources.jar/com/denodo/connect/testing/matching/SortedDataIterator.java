/*
 * Copyright (c) 2026. DENODO Technologies.
 * http://www.denodo.com
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of DENODO
 * Technologies ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with DENODO.
 */
package com.denodo.connect.testing.matching;

import static com.denodo.connect.testing.matching.DataSetSorter.IO_BUFFER_SIZE;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import com.denodo.connect.testing.exception.TestExecutionException;

class SortedDataIterator implements Iterator<List<Object>> {

    private final File dataFile;
    private final FileInputStream dataFileInputStream;
    private final ObjectInputStream dataObjectInputStream;

    private boolean first = true;
    private List<Object> current = null;

    SortedDataIterator(final File dataFile) {

        super();

        this.dataFile = dataFile;

        try {
            this.dataFileInputStream = new FileInputStream(this.dataFile);
        } catch (final IOException e) {
            throw new TestExecutionException(
                "Cannot open temporary file for reading data", e);
        }

        try {
            // Applied BufferedInputStream to the final reader as well
            this.dataObjectInputStream = new ObjectInputStream(
                new BufferedInputStream(this.dataFileInputStream, IO_BUFFER_SIZE));
        } catch (final IOException e) {
            try {
                this.dataFileInputStream.close();
            } catch (final Exception ignored) {
                // ignored
            }
            throw new TestExecutionException(
                "Cannot open temporary object reader for unordered data", e);
        }

    }


    @SuppressWarnings("unchecked")
    @Override
    public boolean hasNext() {

        if (this.current == null && !this.first) {
            // current is null because we already read everything, and we should not call the streams again
            return false;
        }

        this.first = false;

        try {
            this.current = (List<Object>) this.dataObjectInputStream.readObject();
        } catch (final EOFException ignored) {
            // Everything fine -- we just reached the end of file
            this.current = null;
            cleanupResources();
        } catch (final Exception e) {
            cleanupResources();
            throw new TestExecutionException("Cannot read data from temporary unordered data file", e);
        }

        return this.current != null;
    }

    private void cleanupResources() {
        try {
            this.dataObjectInputStream.close();
        } catch (final IOException ignored) {
            // Ignore
        }
        try {
            this.dataFileInputStream.close();
        } catch (final IOException ignored) {
            // Ignore
        }
        try {
            if (this.dataFile != null) {
                Files.deleteIfExists(this.dataFile.toPath());
            }
        } catch (final Exception ignored) {
            // Ignore
        }
    }

    @Override
    public List<Object> next() {
        if (this.first && !hasNext()) {
            throw new NoSuchElementException("No more rows in the sorted data file.");
        }
        return this.current;
    }


    @Override
    public void remove() {
        throw new UnsupportedOperationException(
            "Cannot execute 'remove()' on " + this.getClass().getName());
    }

}
