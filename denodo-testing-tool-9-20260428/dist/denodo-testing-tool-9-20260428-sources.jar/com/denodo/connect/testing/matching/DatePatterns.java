/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.matching;

import java.io.Serial;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.Configuration;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.util.DateUtils;


public class DatePatterns {
    
    private static final Logger LOG = LoggerFactory.getLogger(DatePatterns.class);
    
    private static final String ISO8601_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ssz";
    
    private static final String VDP_LOCALDATE_PATTERN = "yyyy-MM-dd";
    private static final String VDP_TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS";
    private static final String VDP_TIMESTAMPTZ_PATTERN = "yyyy-MM-dd HH:mm:ss.SSSZ";
    private static final String VDP_TIME_PATTERN = "HH:mm:ss";
    
    private static final List<String> VDP_PATTERNS = Arrays.asList(VDP_LOCALDATE_PATTERN, VDP_TIMESTAMP_PATTERN,
            VDP_TIMESTAMPTZ_PATTERN, VDP_TIME_PATTERN);
    
    private static final Map<String, DateTimeFormatter> patternCache = new HashMap<>();
    
    private final Set<String> resultDatePatterns;
    private final Set<String> expectedDatePatterns;
    private String currentResultDatePattern;
    private String currentExpectedDatePattern;
    

    /**
     * @param resultDatePatterns "datepattern" context value in the EXECUTION directive. This context value can be multivalued.
     * @param expectedDatePatterns "datepattern" context value in the RESULTS directive. This context value can be multivalued.
     */
    public DatePatterns(final Collection<String> resultDatePatterns, final Collection<String> expectedDatePatterns) {

        this.resultDatePatterns = new LinkedHashSet<>();
        this.resultDatePatterns.addAll(resultDatePatterns);
        this.resultDatePatterns.addAll(VDP_PATTERNS);
        
        this.expectedDatePatterns = new LinkedHashSet<>();
        this.expectedDatePatterns.addAll(expectedDatePatterns);
        this.expectedDatePatterns.addAll(VDP_PATTERNS);
    }
    
    /**
     * @param globalDatePattern "resultsDatePattern" variable in the global configuration file.
     * @param resultDatePatterns "datepattern" context value in the EXECUTION directive. This context value can be multivalued.
     * @param expectedDatePatterns "datepattern" context value in the RESULTS directive. This context value can be multivalued.
     */
    public DatePatterns(final String globalDatePattern, final Collection<String> resultDatePatterns,
            final Collection<String> expectedDatePatterns) {

        this(resultDatePatterns, expectedDatePatterns);
        
        this.resultDatePatterns.add(globalDatePattern);
        this.expectedDatePatterns.add(globalDatePattern);
    }


    public Collection<String> getResultDatePatterns() {
        return this.resultDatePatterns;
    }

    public Collection<String> getExpectedDatePatterns() {
        return this.expectedDatePatterns;
    }
   
    public void resetCurrentDatePatterns() {
        this.currentResultDatePattern = null;
        this.currentExpectedDatePattern = null;
    }

    public Calendar parseDate(final String dateStr, final boolean expected, Locale locale) {
        
        if (expected) {
            return parseExpectedDate(dateStr, locale);
        }

        // TODO: 31/10/2024 locale?
        return parseResultDate(dateStr);
    }
    
    private Calendar parseExpectedDate(final String dateStr, Locale locale) {
        
        for (final String pattern : this.expectedDatePatterns) {
            
            final Calendar calendar = parseDate(dateStr, pattern, locale);
            
            if (calendar != null) {
                this.currentExpectedDatePattern = pattern;
                return calendar;
            }
        }
        
        // date does not adhere to any of the given patterns
        throw new BadDateFormatException(dateStr, this.expectedDatePatterns);
    }

    private Calendar parseResultDate(final String dateStr) {
        
        for (final String pattern : this.resultDatePatterns) {
            
            final Calendar calendar = parseDate(dateStr, pattern, null);
            
            if (calendar != null) {
                this.currentResultDatePattern = pattern;
                return calendar;
            }
        }
        
        // date does not adhere to any of the given patterns
        throw new BadDateFormatException(dateStr, this.resultDatePatterns);
    }
    
    private Calendar parseDate(final String dateStr, final String pattern, Locale locale) {

        Calendar calendar = null;
        try {

            DateTimeFormatter dateFormat = getFormatter(pattern).withLocale(locale);

            if (locale != null) {
                dateFormat = dateFormat.withLocale(locale);
            }

            final DateTime date = dateFormat.parseDateTime(dateStr);

            // Uses the default locale (null) so all created Calendars will use default locale, and
            // later comparisons between them will not be affected by the locale variable.
            calendar = date.toCalendar(null);

        } catch (final IllegalArgumentException e) {
            // FIX: Removed the exception object 'e' to avoid dumping millions of StackTraces to the log.
            // Using SLF4J parameterization for performance.
            if (LOG.isDebugEnabled()) {
                // todo uncomment
//                LOG.debug("'{}' does not adhere to format '{}'", dateStr, pattern);
            }
        }

        return calendar;
    }

    private DateTimeFormatter getFormatter(final String datePattern) {
        
        DateTimeFormatter formatter = patternCache.get(datePattern);
        
        if (formatter == null) {
            if (Configuration.DEFAULT_RESULTS_DATE_PATTERN.equalsIgnoreCase(datePattern)) {
                formatter = ISODateTimeFormat.dateTimeNoMillis();
            } else {
                formatter = DateTimeFormat.forPattern(datePattern);
            }

            formatter = formatter.withOffsetParsed();
            
            patternCache.put(datePattern, formatter);

        }
        
        return formatter;
    }
    
    public String convertDateToString(final Object obj) {
        
        if (obj instanceof Calendar) {
            return printDate(DateUtils.normalizeToDefaultTimeZone((Calendar) obj), null);
        }
        if (obj instanceof Date) {
            // This is valid for java.util.Date and java.sql.Date (which extends the former)
            return printDate(DateUtils.normalizeToDefaultTimeZone((Date) obj), null);
        }
        throw new IllegalArgumentException("Cannot convert date to String. Original class is " + obj.getClass().getName());
    }    
    
    public String printDate(final Calendar calendar, final Locale locale) {
        
        final String datePattern = getComparisonDatePattern();
        
         DateTimeFormatter dateFormat = getFormatter(datePattern);
         if (locale != null) {
             dateFormat = dateFormat.withLocale(locale);
         }
         final DateTimeZone timeZone = DateTimeZone.forTimeZone(calendar.getTimeZone());
         
         return dateFormat.withZone(timeZone).print(calendar.getTimeInMillis());
     }
     
     public String printDate(final Date date, final Locale locale) {
         
         final String datePattern = getComparisonDatePattern();

         DateTimeFormatter dateFormat = getFormatter(datePattern);
         if (locale != null) {
             dateFormat = dateFormat.withLocale(locale);
         }
         
         return dateFormat.print(new DateTime(date.getTime()));
     }    
    
    /*
     * This pattern will be used in {@link DataComparator} to match Date and Calendar using their string representations.
     */
    protected String getComparisonDatePattern() {        
        return getLessRestrictivePattern();
    }
    
    /*
     * Gets the less restrictive pattern, calculated as the shortest date pattern.
     */
    private String getLessRestrictivePattern() {
        
        if (this.currentResultDatePattern == null && this.currentExpectedDatePattern == null) {
                return Configuration.DEFAULT_RESULTS_DATE_PATTERN;
        }
        
        if (this.currentExpectedDatePattern == null) {
            return this.currentResultDatePattern;
        }
        
        if (this.currentResultDatePattern == null) {
            return this.currentExpectedDatePattern;
        }
        
        String restrictivePattern = this.currentExpectedDatePattern;

        final int expectedPatternLength = getLength(this.currentExpectedDatePattern);
        final int resultPatternLength = getLength(this.currentResultDatePattern);

        if (resultPatternLength < expectedPatternLength) {
            restrictivePattern = this.currentResultDatePattern;
        }
        
        return restrictivePattern;
    }

    private int getLength(final String pattern) {
        
        int length = pattern.length();
        if (Configuration.DEFAULT_RESULTS_DATE_PATTERN.equalsIgnoreCase(pattern)) {
            length = ISO8601_DATE_PATTERN.length();
        }
        
        return length;
    }

    
    
    public static class BadDateFormatException extends TestExecutionException {
        
        @Serial
        private static final long serialVersionUID = -2284890155128745454L;
        
        
        public BadDateFormatException(final String date, final Collection<String> patterns) {
            super("Bad format: Textual date \"" + date + "\" does not adhere to the " + patterns + " format");
        }
        
    }
}
