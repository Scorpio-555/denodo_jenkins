/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2025, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable.variables.processor;

import java.util.List;

public class MultivaluedVariables {


    private List<String> multivaluedVariables;

    private List<String> nestedMultivaluedVariables;

    public MultivaluedVariables(List<String> multivaluedVariables, List<String> nestedMultivaluedVariables) {
        this.multivaluedVariables = multivaluedVariables;
        this.nestedMultivaluedVariables = nestedMultivaluedVariables;
    }

    public List<String> getMultivaluedVariables() {
        return multivaluedVariables;
    }

    public void setMultivaluedVariables(List<String> multivaluedVariables) {
        this.multivaluedVariables = multivaluedVariables;
    }

    public List<String> getNestedMultivaluedVariables() {
        return nestedMultivaluedVariables;
    }

    public void setNestedMultivaluedVariables(List<String> nestedMultivaluedVariables) {
        nestedMultivaluedVariables = nestedMultivaluedVariables;
    }
}