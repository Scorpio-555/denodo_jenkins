/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable.resolver;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.denodo.connect.testing.engine.directive.IDirective;
import com.denodo.connect.testing.engine.directive.SetUpDirective;
import com.denodo.connect.testing.engine.directive.TearDownDirective;
import com.denodo.connect.testing.engine.directive.combiner.AddValuesCombiner;
import com.denodo.connect.testing.engine.directive.combiner.IDirectiveCombiner;
import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.resource.LocalFolderTestResource;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.ITestable;
import com.denodo.connect.testing.testable.Test;
import com.denodo.connect.testing.testable.TestSequence;
import com.denodo.connect.testing.testable.parser.ITestParser;
import com.denodo.connect.testing.util.FailedTests;

public class TestableResolver implements ITestableResolver {
    
    private static final Logger LOG = LoggerFactory.getLogger(TestableResolver.class);


    private static final String EXTENDS_DIRECTIVE = "EXTENDS";
    private static final IDirectiveCombiner EXTENDS_DIRECTIVE_COMBINER = new AddValuesCombiner();
    
    private final ITestParser parser;
    private final Map<String, IDirective> directives;

    public TestableResolver(final ITestParser parser, final Map<String, IDirective> directives) {
        super();

        Validate.notNull(parser, "Parser cannot be null");
        Validate.notNull(directives, "Directives cannot be null");
        
        this.parser = parser;
        this.directives = directives;
    }
    
    @Override
    public ITestable resolve(final ITestResource testResource, List<String> failedTests) {
        
        Validate.notNull(testResource, "Resource cannot be null");
        testResource.checkValid();
        
        if (testResource.isDirectory() || testResource.isIndex()) {
            final List<ITestable> testables = new ArrayList<>();
            final List<ITestResource> contents = getResourceContents(testResource);
            for (final ITestResource resource : contents) {
                try {
                    resource.checkValid();
                    final ITestable testable = resolve(resource, failedTests);
                    if(testable!=null){
                        testables.add(testable);
                    }
                } catch (IllegalArgumentException e) {
                    LOG.debug("Skipping. " + e.getLocalizedMessage());
                }
            }


            final List<ITestable> prunedtestables = pruningTestSequences(testables);
            if(prunedtestables!=null){
                return new TestSequence(testResource.getName(),prunedtestables );
            }else{
                return null;
            }
        }
        final Test test;
        if(failedTests!=null){
            if(FailedTests.isFailedTests(failedTests, testResource.getName())){
                test = resolveFile(testResource);
                checkTest(test);
            }else{
                test = null;
            }
        }else{
            test = resolveFile(testResource);
            checkTest(test);
        }

      
        
        return test;
        
    }
    
    
    
    /**
     * Prune the testsequence, removing the testsequences that only have the 'first.denodotest' element and the 'last.denodotest' or only one of them.  
     * @param testables   it an ordered list, if first.denodotest exist is the first element, and if last.denodotest exits is the last element.
     */
    private static List<ITestable> pruningTestSequences(List<ITestable>  testables){
        if(testables.size()>2){
            return testables;
        }else if(testables.size()==2){
            if( testables.get(0).getResourceName().endsWith(LocalFolderTestResource.FIRST_TEST_FILENAME)){
                if(testables.get(1).getResourceName().endsWith(LocalFolderTestResource.LAST_TEST_FILENAME)){
                    return null;
                }else{
                    return testables;
                }
            }else{
                return testables;
            }
        }else  if(testables.size()==1){
            if( testables.get(0).getResourceName().endsWith(LocalFolderTestResource.FIRST_TEST_FILENAME)||
                    testables.get(0).getResourceName().endsWith(LocalFolderTestResource.LAST_TEST_FILENAME)){
                return null;
            }
            return testables;
        }
        return null;
    }
    
    private List<ITestResource> getResourceContents(final ITestResource testResource) {
        
        List<ITestResource> contents;

        final ITestResource indexResource = findIndex(testResource);
        if (indexResource != null) {
            contents = this.parser.parseIndex(indexResource);
        } else {
            contents = testResource.getContents();    
        }
        
        return contents;
    }
    
    private static ITestResource findIndex(final ITestResource testResource) {
     
        if (testResource.isIndex()) {
            return testResource;
        }
        
        if (testResource.isDirectory()) {
            final List<ITestResource> contents = testResource.getContents();
            for (final ITestResource resource : contents) {
                if (resource.isIndex()) {
                    return resource;
                }
            }
        }
        
        return null;
    }
    
    private Test resolveFile(final ITestResource testResource) {

        final Test test = this.parser.parse(testResource);
        final Field extendsField = test.getField(EXTENDS_DIRECTIVE);
        if (extendsField != null) {
            final ITestResource relativeResource = testResource.locateRelative(extendsField.getValueWithoutQualifier().getText());
            return combine(resolveFile(relativeResource), test);
        }
        
        return test;

    }

    private Test combine(final Test parent, final Test child) {

        final Map<String, Field> fieldsByName = new LinkedHashMap<>();
        final Map<String, Field> childFieldsByName = child.getFieldsByName();
        final Map<String, Field> parentFieldsByName = parent.getFieldsByName();

        final Set<String> allFields = new LinkedHashSet<>();
        allFields.addAll(childFieldsByName.keySet());
        allFields.addAll(parentFieldsByName.keySet());

        for (final String fieldName : allFields) {

            if (childFieldsByName.containsKey(fieldName)) {
                if (parentFieldsByName.containsKey(fieldName)) {

                    final Field childField = childFieldsByName.get(fieldName);
                    final Field parentField = parentFieldsByName.get(fieldName);

                    final Field combinedField = combineFields(childField, parentField);
                    fieldsByName.put(combinedField.getName(), combinedField);

                } else {
                    fieldsByName.put(fieldName, childFieldsByName.get(fieldName));
                }
            } else {
                if (parentFieldsByName.containsKey(fieldName)) {
                    fieldsByName.put(fieldName, parentFieldsByName.get(fieldName));
                }
            }

        }

        return new Test(child.getResourceName(), fieldsByName);

    }

    private Field combineFields(final Field childField, final Field parentField) {
        
        final IDirective directive = this.directives.get(childField.getName());
        if (directive == null) {
            return defaultDirectiveCombine(childField, parentField);
        }
        
        return directive.combine(childField, parentField);
    }

    private static Field defaultDirectiveCombine(final Field childField, final Field parentField) {
        return EXTENDS_DIRECTIVE_COMBINER.combine(childField, parentField);
    }
    
    private void checkTest(final Test test) {
        
        // first.denodotest should have the SETUP directive
        if (test.getResourceName().endsWith(LocalFolderTestResource.FIRST_TEST_FILENAME)) {
            checkFirstLastTestFormat(test, SetUpDirective.SETUP_DIRECTIVE_FIELD);
        
         // last.denodotest should have the TEARDOWN directive
        } else if (test.getResourceName().endsWith(LocalFolderTestResource.LAST_TEST_FILENAME)) {
            checkFirstLastTestFormat(test, TearDownDirective.TEARDOWN_DIRECTIVE_FIELD);
        } else {
            checkTestFormat(test);
        }

    }

    private static void checkFirstLastTestFormat(Test test, final String directiveName) {
        
            final Field field = test.getField(directiveName);
            if (field == null) {
                throw new TestExecutionException("Missing directive for special test '" + test.getResourceName()
                        + "'. Directive '" + directiveName + "' is required.");
            }
        
    }
    
    private void checkTestFormat(final Test test) {
        
        final Map<String, Field> fieldsByName = test.getFieldsByName();
        for (final Map.Entry<String, IDirective> entry : this.directives.entrySet()) {
            final String directiveName = entry.getKey();
            final IDirective directive = entry.getValue();
            final Field field = fieldsByName.get(directiveName);
            if (field == null && directive.isRequired()) {
                throw new TestExecutionException("Missing directive for test '" + test.getResourceName() + "'. Directive '" + directiveName + "' is required.");
            }
        }
    }

}
