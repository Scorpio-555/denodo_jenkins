/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable;

import java.util.Collections;
import java.util.Map;

import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.engine.directive.NameDirective;


public class Test implements ITestable {
    
    private final String resourceName;
    private final Map<String, Field> fieldsByName;
    
    public Test(final String resourceName, final Map<String, Field> fieldsByName) {
        super();
        
        Validate.notNull(resourceName, "Resource name cannot be null");
        
        this.resourceName = resourceName;
        this.fieldsByName = fieldsByName;
    }
    
    @Override
    public String getResourceName() {
        return this.resourceName;
    }

    /*
     * Convenience method for getting test name without executing the directive NAME.
     * Test reporters need test name before executing any directive
     * ({@link com.denodo.connect.testing.reporter.ITestReporter#testStart(int, String, String)})
     */
    public String getName() {
        
        String name = null;
        final Field nameField = getField(NameDirective.NAME_DIRECTIVE_FIELD);
        if (nameField != null) {
            final FieldValue fieldValue = nameField.getValueWithoutQualifier();
            if (fieldValue != null) {
                name = fieldValue.getText();
            }
        }
        
        return name;
    }
    
    public Map<String, Field> getFieldsByName() {
        return Collections.unmodifiableMap(this.fieldsByName);
    }

    public Field getField(final String fieldName) {
        return this.fieldsByName.get(fieldName);
    }
    
    @Override
    public int getSize() {
        return 1;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((this.fieldsByName == null) ? 0 : this.fieldsByName.hashCode());
        result = prime * result + ((this.resourceName == null) ? 0 : this.resourceName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Test other = (Test) obj;
        if (this.fieldsByName == null) {
            if (other.fieldsByName != null) {
                return false;
            }
        } else if (!this.fieldsByName.equals(other.fieldsByName)) {
            return false;
        }
        if (this.resourceName == null) {
            return other.resourceName == null;
        } else {
            return this.resourceName.equals(other.resourceName);
        }
    }

    @Override
    public String toString() {
        return "[resourceName=" + this.resourceName + ", fieldsByName=" + this.fieldsByName + "]";
    }
    
    
    
}