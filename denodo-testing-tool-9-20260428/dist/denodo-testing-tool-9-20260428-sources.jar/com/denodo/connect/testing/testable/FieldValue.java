/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable;

import java.util.ArrayList;
import java.util.List;

import com.denodo.connect.testing.engine.ContextVariables;
import com.denodo.connect.testing.util.VariableUtils;

public class FieldValue {
    
    private final String qualifier;
    private String context;
    private String text;
    
    public FieldValue(final String qualifier, final String context, final String text) {
        super();
        this.qualifier = qualifier;
        this.context = context;
        this.text = text;
    }
    
    public String getQualifier() {
        return this.qualifier;
    }
    
    public String getContext() {
        return this.context;
    }
    
    public String getText() {
        return this.text;
    }
    
    public void replaceVariables(final ContextVariables variables) {
        
        this.context = VariableUtils.replaceVariables(this.context, variables);
        this.text = VariableUtils.replaceVariables(this.text, variables);
    }
    
    public List<String> findVariables() {
        List<String> variablesList = new ArrayList<>();
        variablesList.addAll(VariableUtils.findVariables(this.context));
        variablesList.addAll(VariableUtils.findVariables(this.text));
        
        return variablesList;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.qualifier == null) ? 0 : this.qualifier.hashCode());
        result = prime * result + ((this.context == null) ? 0 : this.context.hashCode());
        result = prime * result + ((this.text == null) ? 0 : this.text.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        FieldValue other = (FieldValue) obj;
        if (this.qualifier == null) {
            if (other.qualifier != null) {
                return false;
            }
        } else if (!this.qualifier.equals(other.qualifier)) {
            return false;
        }
        if (this.context == null) {
            if (other.context != null) {
                return false;
            }
        } else if (!this.context.equals(other.context)) {
            return false;
        }
        if (this.text == null) {
            return other.text == null;
        } else {
            return this.text.equals(other.text);
        }
    }

    @Override
    public String toString() {
        return "[qualifier=" + this.qualifier + ", context=" + this.context + ", text=" + this.text + "]";
    }

    @Override
    public Object clone() {
        return new FieldValue(this.qualifier, this.context, this.text);
    }
    
}