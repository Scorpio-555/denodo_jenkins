/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable.parser;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.denodo.connect.testing.exception.TestExecutionException;
import com.denodo.connect.testing.resource.ITestResource;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.FieldValue;
import com.denodo.connect.testing.testable.Test;
import com.denodo.connect.testing.util.EscapeUtils;
import com.denodo.connect.testing.util.VariableUtils;

public class TestParser implements ITestParser {    
    
    private static final char COMMENT_PREFIX_CHAR = '#';
    private static final char FIELD_PREFIX_CHAR = '%';
    
    private static final Pattern FIELD_DEFINITION_PATTERN = Pattern.compile("([\\p{Alnum}_-]*)(\\[(\\S*)])?");
    private static final int FIELD_NAME_GROUP = 1;
    private static final int FIELD_QUALIFIER_GROUP = 3;
    
    private static final char FIELD_CONTEXT_START_DELIMITER = '{';
    private static final char FIELD_CONTEXT_END_DELIMITER = '}';
    
    private static final char VAR_CONTEXT_START_DELIMITER = '$';

    
    public TestParser() {
        super();        
    }
    
    @Override
    public Test parse(final ITestResource testResource) {
        
        Validate.notNull(testResource, "Resource cannot be null");
        
        final Map<String, Field> fieldsByName = new LinkedHashMap<>();
        
        BufferedReader br = null;
        try {
            
            br = new BufferedReader(testResource.readFile());
            String currentFieldName = null;
            String currentFieldQualifier = null;
            StringBuilder strBuilder = null;
            boolean builderContainsSomething = false;
            
            String line = br.readLine();
            while (line != null) {
                
                if (StringUtils.isBlank(line) || isCommentLine(line)) {
                    line = br.readLine();
                    continue;
                }
                
                line = EscapeUtils.unescapeUnicode(line);
                    
                final String newFieldDefinition = extractFieldDefinition(line);
                if (newFieldDefinition == null) {
                    // This is not a new field, it is content belonging to the previously-defined field
                    if (currentFieldName == null) {
                        line = br.readLine();
                        continue;
                    }
                    if (builderContainsSomething) {
                        strBuilder.append('\n');
                    }
                    strBuilder.append(line);
                    builderContainsSomething = true;
                    line = br.readLine();
                    continue;
                }
                
                if (currentFieldName != null) {
                    insertField(fieldsByName, currentFieldName, currentFieldQualifier, strBuilder.toString());
                }
                
                final int lineLen = line.length();
                currentFieldName = extractFieldName(newFieldDefinition);
                currentFieldQualifier = extractFieldQualifier(newFieldDefinition);
                
                strBuilder = new StringBuilder();
                builderContainsSomething = false;
                
                if ((newFieldDefinition.length() + 1) < (lineLen - 1)) {
                    final int valueStart = newFieldDefinition.length() + 1;
                    if (valueStart < (lineLen - 1)) {
                        strBuilder.append(line.substring(valueStart));
                        builderContainsSomething = true;
                    }
                }
                
                line = br.readLine();
            }

            if (currentFieldName != null) {
                insertField(fieldsByName, currentFieldName, currentFieldQualifier, strBuilder.toString());
            }

            return new Test(testResource.getName(), fieldsByName);

        } catch (IOException e) {
            throw new TestExecutionException("Error reading test file '" + testResource.getName() + "'", e);
        } finally {
            IOUtils.closeQuietly(br);
        }
        
        
    }
    
    @Override
    public List<ITestResource> parseIndex(final ITestResource indexResource) {

        Validate.notNull(indexResource, "Resource cannot be null");
        
        final List<ITestResource> testResources = new ArrayList<>();
        BufferedReader br = null;
        try {
            
            br = new BufferedReader(indexResource.readFile());
            String line = br.readLine();
            while (line != null) {
                
                if (StringUtils.isBlank(line) || isCommentLine(line)) {
                    line = br.readLine();
                    continue;
                }
                
                line = line.trim();
                
                final ITestResource testResource = indexResource.locateRelative(line);
                testResource.checkValid();
                testResources.add(testResource);
                
                line = br.readLine();
            }
        
            return testResources;
            
        } catch (IOException e) {
            throw new TestExecutionException("Error reading index file '" + indexResource.getName() + "'", e);
        } finally {
            IOUtils.closeQuietly(br);
        }
    }

    private static boolean isCommentLine(final String line) {
        return !line.isEmpty() && line.charAt(0) == COMMENT_PREFIX_CHAR;
    }
    
    private static void insertField(final Map<String, Field> fieldsByName, final String fieldName, final String fieldQualifier,
            final String fieldContents) {
       
        final FieldValue newFieldValue = extractFieldValue(fieldQualifier, fieldContents);

        // Field exists
        if (fieldsByName.containsKey(fieldName)) {
            fieldsByName.get(fieldName).getValues().add(newFieldValue);
        } else {

            final List<FieldValue> newValues = new ArrayList<>();
            if (newFieldValue != null) {
                newValues.add(newFieldValue);
            }
            final Field newField = new Field(fieldName, newValues);

            fieldsByName.put(fieldName, newField);
        }
            
    }
    
    private static String extractFieldDefinition(final String line) {

        final int lineLen = line.length();
        if (lineLen == 0) {
            return null;
        }
        
        char c = line.charAt(0);
        if (c != FIELD_PREFIX_CHAR) {
            return null;
        }
        
        int i = 1;
        while (i < lineLen) {
            c = line.charAt(i);
            if (Character.isWhitespace(c)) {
                break;
            }
            i++; 
        }
    
        final String tentativeFieldDefinition = line.substring(1, i);
        
        return isFieldDefinition(tentativeFieldDefinition) ? tentativeFieldDefinition : null;
        
    }
    
    private static boolean isFieldDefinition(final String name) {
        
        if (name == null) {
            return false;
        }
        final Matcher m = FIELD_DEFINITION_PATTERN.matcher(name);
        return m.matches();
    }
    
    private static String extractFieldName(final String fieldDefinition) {
        return VariableUtils.extractValue(FIELD_DEFINITION_PATTERN, FIELD_NAME_GROUP, fieldDefinition);
    }
    
    private static String extractFieldQualifier(final String fieldDefinition) {
        return VariableUtils.extractValue(FIELD_DEFINITION_PATTERN, FIELD_QUALIFIER_GROUP, fieldDefinition);
    }
    
    /**
     * - FieldContents is of the form: "{ context } value ".
     * - Context variables have the syntax: "${variable}".
     * - Context can contain context variables: "{ds: ${context_variable}, ordered:true}".
     */
    private static FieldValue extractFieldValue(final String fieldQualifier, final String fieldContents) {
        
        final StringBuilder context = new StringBuilder();
        final StringBuilder value = new StringBuilder();
        
        char c = '\0';
        char previousChar;
        int n = fieldContents.length();
        int i = 0;
        boolean skipBlanks = true;  // only skip blanks before the context and between context and value
        boolean foundFirstNonBlank = false;
        boolean withinContext = false;
        boolean withinContextVar = false;
        while (n-- != 0) {
            previousChar = c;
            c = fieldContents.charAt(i++);
            if (skipBlanks && c <= ' ') {
                continue;
            }            
            
            // Only the first '{' marks the beginning of the context, others '{' are part of the context or the value.
            if (startsContext(c, foundFirstNonBlank)) { 
                withinContext = true;
                skipBlanks = false;
                continue;
            }
            
            foundFirstNonBlank = true;
            
            // Context variables within the context should be detected to locate the end of the context '}' properly: both context and var end with '}'
            if (startsContextVar(c, previousChar, withinContext) ) {
                withinContextVar = true;
            }
            
            // Detect whether '}' marks the end of the var or the context.
            if (endsContextOrContextVar(c, withinContext)) {
                if (withinContextVar) {
                    withinContextVar = false;
                } else {
                    withinContext = false;
                    skipBlanks = true;
                    continue;
                }
            }
            
            if (withinContext) {
                context.append(c);
            } else {
                value.append(c);
                skipBlanks = false;
            }
        }
        
        FieldValue fieldValue = null;
        if (!context.isEmpty() || !value.isEmpty()) {
            fieldValue = new FieldValue(fieldQualifier, !context.isEmpty() ? context.toString() : null,
                !value.isEmpty() ? value.toString() : null);
        }
        
        return fieldValue;
        
    }

    private static boolean startsContext(final char c, final boolean foundFirstNonBlank) {
        return !foundFirstNonBlank && c == FIELD_CONTEXT_START_DELIMITER;
    }

    private static boolean startsContextVar(final char c, final char previousChar, final boolean withinContext) {
        return withinContext && previousChar == VAR_CONTEXT_START_DELIMITER  && c == FIELD_CONTEXT_START_DELIMITER;
    }

    private static boolean endsContextOrContextVar(final char c, final boolean withinContext) {
        return withinContext && c == FIELD_CONTEXT_END_DELIMITER;
    }

}
