package com.denodo.connect.testing.testable.variables.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.denodo.connect.testing.engine.ContextVariables;
import com.denodo.connect.testing.engine.TestExecutorContext;
import com.denodo.connect.testing.engine.directive.IDirective;
import com.denodo.connect.testing.exception.TestConfigurationException;
import com.denodo.connect.testing.testable.Field;
import com.denodo.connect.testing.testable.Test;
import com.denodo.connect.testing.util.CartesianProductIterator;

public class TestVariablesProcessor implements ITestVariablesProcessor {

    private static final String DIRECTIVE_CONTEXT = "CONTEXT";
    
    private static final String MULTI_VALUED_VARIABLE_SIGN = "[]";

    private static final String NESTED_MULTI_VALUED_VARIABLE_SIGN = "[][]";
    
    private static final String VALUES_SEPARATOR = ",";

    private static final String VALUES_NESTED_SEPARATOR = "],";
    
    @Override
    public List<List<TestExecutorContext>> process(final Test test, final Map<String, IDirective> directives) {
        
        TestExecutorContext context = processContext(test, directives);
        MultivaluedVariables multiValuedVariables = getMultiValuedVariables(test, directives, context);
        List<List<TestExecutorContext>> listContexts;
        if (!multiValuedVariables.getMultivaluedVariables().isEmpty()|| !multiValuedVariables.getNestedMultivaluedVariables().isEmpty()) {
            listContexts = getTestExecutorContext(context, multiValuedVariables);

        } else {
            listContexts= new ArrayList<>();
            List<TestExecutorContext> newContexts = new ArrayList<>(1);
            newContexts.add(context);
            listContexts.add(newContexts);

        }
        return listContexts;
    }
    
    private static TestExecutorContext processContext(final Test test, final Map<String, IDirective> directives) {
        final TestExecutorContext context = new TestExecutorContext();
        
        IDirective directiveContext = directives.get(DIRECTIVE_CONTEXT);
        
        final Field directiveField = test.getField(DIRECTIVE_CONTEXT);
        if (directiveField != null) {
            directiveContext.process(test.getResourceName(), directiveField, context);
        }
        return context;
    }
    
    private static List<String> getVariables(final Test test, final Map<String, IDirective> directives) {
        List<String> variablesList = new ArrayList<>();
        for (final Map.Entry<String, IDirective> entry : directives.entrySet()) {
            final String directiveName = entry.getKey();
            final Field directiveField = test.getField(directiveName);
            if (directiveField != null) {
                variablesList.addAll(directiveField.findVariables());
            }
        }
        return variablesList;
    }
    
    private static MultivaluedVariables getMultiValuedVariables(final Test test, final Map<String, IDirective> directives, TestExecutorContext context) {
        List<String> variables = getVariables(test, directives);
        
        MultivaluedVariables multiValuedVar = new MultivaluedVariables(new ArrayList<>(), new ArrayList<>());
        
        if (context.getContextVariables() != null) {
            for (Entry<String, Object> cv : context.getContextVariables().entrySet()) {
                String varName = cv.getKey();
                if (varName.endsWith(NESTED_MULTI_VALUED_VARIABLE_SIGN)) {
                    String nameWithoutSign = getVarNameWithoutNestedSign(varName);
                    if (variables.contains(nameWithoutSign)) {
                        multiValuedVar.getNestedMultivaluedVariables().add(varName);
                        if(multiValuedVar.getNestedMultivaluedVariables().size()>1){
                            throw new TestConfigurationException(test.getName()+": Only one nested array is allowed in the context. "
                                + "Parallel execution is restricted to one level of concurrency.");
                        }
                    }
                }else if (varName.endsWith(MULTI_VALUED_VARIABLE_SIGN)) {
                    String nameWithoutSign = getVarNameWithoutSign(varName);
                    if (variables.contains(nameWithoutSign)) {
                        multiValuedVar.getMultivaluedVariables().add(varName);
                    }
                }
            }
        }
        
        return multiValuedVar;
    }
    
    private static Map<String, List<String>> getMultivaluedVariablesAndValues(final ContextVariables contextVar, final List<String> multiValuedVar) {
        Map<String, List<String>> multiValuedValues = new LinkedHashMap<>();
        for (String var : multiValuedVar) {
            Object varValue = contextVar.get(var);
            if (varValue != null) {
                String[] valueAsArray = ((String) varValue).split(VALUES_SEPARATOR);
                List<String> trimmedList = new ArrayList<>(valueAsArray.length);
                for (String s : valueAsArray) {
                    trimmedList.add(s.trim());
                }
                multiValuedValues.put(var, trimmedList);
            }
        }
        return multiValuedValues;
    }

    private static Map<String, List<List<String>>> getNestedMultivaluedVariablesAndValues(final ContextVariables contextVar, final List<String> multiValuedVar) {

        Map<String, List<List<String>>> multiValuedValues = new HashMap<>();
        for (String var : multiValuedVar) {
            Object varValue = contextVar.get(var);
            if (varValue != null) {
                String[] valueAsArray = ((String) varValue).substring(0, ((String) varValue).length() - 1).replaceAll("\\[","").split(VALUES_NESTED_SEPARATOR);

                List<List<String>> nestedList = new ArrayList<>(valueAsArray.length);
                for (String valueNested : valueAsArray) {
                    String[] value = ((String) valueNested).split(VALUES_SEPARATOR);
                    List<String> trimmedList = new ArrayList<>(value.length);
                    for (String s : value) {
                        trimmedList.add(s.trim());
                    }
                    nestedList.add(trimmedList);
                }
                multiValuedValues.put(var, nestedList);
            }
        }
        return multiValuedValues;
    }
    
    // Using the map with each property and the list of its values we are going to build a list. 
    // In the new list each pair variable-value is going to be a map and the maps of one variable
    // are grouped in a list.
    // Example
    // var1[] = val1_1, val1_2
    // var2[] = val2_1, val2_2, val2_3
    // Result: [[{var1[]='val1_1'}, {var1[]='val1_2'}], [{var2[]='val2_1'}, {var2[]='val2_2'}, {var2[]='val2_3'}]]
    private static List<List<Map<String, String>>> getVariablesByGroup(final Map<String, List<String>> multiValuedValues) {
        
        List<List<Map<String, String>>> variables = new ArrayList<>();
        
        for (Entry<String, List<String>> entry : multiValuedValues.entrySet()) {
            List<Map<String,String>> entryListOfMap = new ArrayList<>();
            for (String value : entry.getValue()) {
                Map<String,String> varMap = new HashMap<>(1);
                varMap.put(entry.getKey(), value);
                entryListOfMap.add(varMap);
            }
            variables.add(entryListOfMap);
        }       
        return variables;
    }
    
    private static List<List<TestExecutorContext>> getTestExecutorContext(final TestExecutorContext context,
            final MultivaluedVariables multiValuedVariables) {
        List<List<TestExecutorContext>> listNestedTestExecutorContext = new ArrayList<>();
        Map<String, List<List<String>>> nestedMultiValuedVariablesAndValues =
            getNestedMultivaluedVariablesAndValues(context.getContextVariables(), multiValuedVariables.getNestedMultivaluedVariables());

        Map<String, List<String>> multiValuedVariablesAndValues = 
                getMultivaluedVariablesAndValues(context.getContextVariables(), multiValuedVariables.getMultivaluedVariables());

        

        
        ContextVariables originalContextVariables = context.getContextVariables();

        if (!nestedMultiValuedVariablesAndValues.isEmpty()) {
            for (Map.Entry<String, List<List<String>>> entry : nestedMultiValuedVariablesAndValues.entrySet()) {

                for (List<String> listVariable : entry.getValue()) {
                    multiValuedVariablesAndValues.put(entry.getKey(), listVariable);
                    List<List<Map<String, String>>> variablesByGroup = getVariablesByGroup(
                        multiValuedVariablesAndValues);
                    CartesianProductIterator<Map<String, String>> cartesianProductIterartor = new CartesianProductIterator<>(
                        variablesByGroup);
                    List<TestExecutorContext> testExecutorContextList = new ArrayList<>();
                    while (cartesianProductIterartor.hasNext()) {
                        List<Map<String, String>> combination = cartesianProductIterartor.next();

                        // Each list is a set of variables for a context
                        TestExecutorContext newContext = new TestExecutorContext();
                        ContextVariables newContextVariables = getNewContextVariables(originalContextVariables,
                            combination);
                        newContext.setContextVariables(newContextVariables);

                        // Add a suffix to identify the variables used.
                        newContext.setSuffixName(getSuffixName(newContextVariables, multiValuedVariablesAndValues));

                        testExecutorContextList.add(newContext);

                    }
                    listNestedTestExecutorContext.add(testExecutorContextList);
                }
            }


        } else {
            List<List<Map<String, String>>> variablesByGroup = getVariablesByGroup(multiValuedVariablesAndValues);
            CartesianProductIterator<Map<String, String>> cartesianProductIterartor = new CartesianProductIterator<>(
                variablesByGroup);
            List<TestExecutorContext> testExecutorContextList = new ArrayList<>();
            while (cartesianProductIterartor.hasNext()) {
                List<Map<String, String>> combination = cartesianProductIterartor.next();

                // Each list is a set of variables for a context
                TestExecutorContext newContext = new TestExecutorContext();
                ContextVariables newContextVariables = getNewContextVariables(originalContextVariables, combination);
                newContext.setContextVariables(newContextVariables);

                // Add a suffix to identify the variables used.
                newContext.setSuffixName(getSuffixName(newContextVariables, multiValuedVariablesAndValues));

                testExecutorContextList.add(newContext);
            }
            listNestedTestExecutorContext.add(testExecutorContextList);
        }
        
        return listNestedTestExecutorContext;
    }
    
    private static ContextVariables getNewContextVariables(final ContextVariables originalContextVariables, 
            final List<Map<String, String>> combination) {
        ContextVariables newContextVariables = (ContextVariables) originalContextVariables.clone();

        for (Map<String, String> varMap : combination) {
            for (Entry<String, String> var : varMap.entrySet()) {

                if (var.getKey().endsWith(NESTED_MULTI_VALUED_VARIABLE_SIGN)) {
                    newContextVariables.put(getVarNameWithoutNestedSign(var.getKey()), var.getValue());
                } else {
                    newContextVariables.put(getVarNameWithoutSign(var.getKey()), var.getValue());
                }
                newContextVariables.remove(var.getKey());
            }
        }
        
        return newContextVariables;
    }
    
    private static String getSuffixName(final  ContextVariables newContextVariables, final Map<String, List<String>> multiValuedVariablesAndValues) {
        StringBuilder sb = new StringBuilder();
        
        for (Entry<String, List<String>> mv : multiValuedVariablesAndValues.entrySet()) {
            String varName;
            if(mv.getKey().endsWith(NESTED_MULTI_VALUED_VARIABLE_SIGN)){
                varName = getVarNameWithoutNestedSign(mv.getKey());
            } else{
                varName = getVarNameWithoutSign(mv.getKey());
            }
            Object value = newContextVariables.get(varName);
            if (value != null) {
                sb.append("_");
                sb.append(varName);
                sb.append(mv.getValue().indexOf((String) value));
            }
        }
        
        return sb.toString();
    }
    
    private static String getVarNameWithoutSign(String varName) {
        return varName.substring(0, varName.length() - MULTI_VALUED_VARIABLE_SIGN.length());
    }

    private static String getVarNameWithoutNestedSign(String varName) {
        return varName.substring(0, varName.length() - NESTED_MULTI_VALUED_VARIABLE_SIGN.length());
    }
    
}
