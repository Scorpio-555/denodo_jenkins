/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;

import com.denodo.connect.testing.engine.ContextVariables;


public class Field {
    
    private final String name;
    private List<FieldValue> values;
    private List<FieldValue> originalValues; // values with variables
    private boolean variablesReplaced = false;
    
    public Field(final String name, final List<FieldValue> values) {
        super();
        this.name = name;
        this.values = values;
    }
    
    public String getName() {
        return this.name;
    }

    public List<FieldValue> getValues() {
        return this.values;
    }
    
    public List<FieldValue> getValuesWithoutQualifier() {
        return (List<FieldValue>) CollectionUtils.select(this.values, new Predicate() {

            @Override
            public boolean evaluate(Object arg0) {
                return ((FieldValue) arg0).getQualifier() == null;
            }
        });
    }
    
    /**
     * Convenience method for those fields that have no qualifiers and only one value is relevant. 
     */
    public FieldValue getValueWithoutQualifier() {
        
        List<FieldValue> valuesWithoutQualifiers = getValuesWithoutQualifier();
        if (!valuesWithoutQualifiers.isEmpty()) {
            return valuesWithoutQualifiers.get(0);
        }
        
        return null;
    }
    
    public void replaceVariables(final ContextVariables variables) {
        if (!this.variablesReplaced) {
            // Get here orginal values because, in this point, you already have the final list of values
            this.originalValues = cloneList(this.values);
        } else {
            // Start the process with the list that has the original values
            this.values = cloneList(this.originalValues);
        }
        
        for (final FieldValue fieldValue : this.values) {
            fieldValue.replaceVariables(variables);
        }
        this.variablesReplaced = true;
    }
    
    public List<String> findVariables() {
        List<String> variablesList = new ArrayList<>();
        
        for (final FieldValue fieldValue : this.values) {
            variablesList.addAll(fieldValue.findVariables());
        }
        
        return variablesList;
    }
    
    private static List<FieldValue> cloneList(List<FieldValue> list) {
        List<FieldValue> clone = new ArrayList<>(list.size());
        for(FieldValue item: list) {
            clone.add((FieldValue) item.clone());
        }
        return clone;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
        result = prime * result + ((this.values == null) ? 0 : this.values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Field other = (Field) obj;
        if (this.name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!this.name.equals(other.name)) {
            return false;
        }
        if (this.values == null) {
            return other.values == null;
        } else {
            return this.values.equals(other.values);
        }
    }

    @Override
    public String toString() {
        return "[name=" + this.name + ", values=" + this.values + "]";
    }
    
}