/*
 * =============================================================================
 *
 *   This software is part of the DenodoConnect component collection.
 *
 *   Copyright (c) 2014-2015, denodo technologies (http://www.denodo.com)
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 * =============================================================================
 */
package com.denodo.connect.testing.testable;

import java.util.List;

import org.apache.commons.lang.Validate;

public class TestSequence implements ITestable {

    private final String resourceName;
    private final List<ITestable> testables;
    
    public TestSequence(final String resourceName, final List<ITestable> testables) {
        super();
        
        Validate.notNull(resourceName, "Resource name cannot be null");
        
        this.resourceName = resourceName;
        this.testables = testables;
        
    }

    @Override
    public String getResourceName() {
        return this.resourceName;
    }

    public List<ITestable> getTestables() {
        return this.testables;
    }
    
    @Override
    public int getSize() {
        
        int size = 0;
        for (final ITestable testable : this.testables) {
            size += testable.getSize();
        }
        
        return size;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((this.testables == null) ? 0 : this.testables.hashCode());
        result = prime * result + ((this.resourceName == null) ? 0 : this.resourceName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        TestSequence other = (TestSequence) obj;
        if (this.testables == null) {
            if (other.testables != null) {
                return false;
            }
        } else if (!this.testables.equals(other.testables)) {
            return false;
        }
        if (this.resourceName == null) {
            return other.resourceName == null;
        } else {
            return this.resourceName.equals(other.resourceName);
        }
    }
    
    @Override
    public String toString() {
        return "[resourceName=" + this.resourceName + ", testables=" + this.testables + "]";
    }
    
    
}
